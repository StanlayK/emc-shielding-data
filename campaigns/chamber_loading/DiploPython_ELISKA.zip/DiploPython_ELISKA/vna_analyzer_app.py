"""
VNA CSV Analyzer - GUI aplikace pro zpracovani a vizualizaci VNA dat.

Nacte CSV exportovany z VNA Data Recorderu a zobrazi:
  1. Vsechny sweepy prekryte
  2. Heatmapu (frekvence x cas)
  3. Statistiku s detekci rezonanci
  4. Analyzu stability mereni
  5. CDF / Gumbel statistickou analyzu (nova zalozka)

Spusteni:
    python vna_analyzer_app.py
"""

import os
import sys
import io
import numpy as np
import customtkinter as ctk
import matplotlib
matplotlib.use("TkAgg")
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk
from matplotlib.figure import Figure
from matplotlib.gridspec import GridSpec
from matplotlib.ticker import FuncFormatter
from tkinter import filedialog

try:
    from scipy.signal import find_peaks
    SCIPY_AVAILABLE = True
except ImportError:
    SCIPY_AVAILABLE = False

# Import CDF/Gumbel vypocetniho modulu
from cdf_gumbel import (
    ANALYSIS_MODES,
    extract_series_for_mode,
    compute_empirical_cdf,
    fit_gumbel,
    compute_statistics,
    format_statistics_text,
    plot_cdf_and_gumbel,
    export_cdf_results,
)


# ---------------------------------------------------------------------------
# Konstanty
# ---------------------------------------------------------------------------
APP_TITLE = "VNA CSV Analyzer"
APP_VERSION = "1.1"
WINDOW_SIZE = "1400x900"

# Barvy (dark theme)
COLOR_BG_DARK       = "#1a1a2e"
COLOR_BG_CARD       = "#16213e"
COLOR_ACCENT_BLUE   = "#0f3460"
COLOR_ACCENT_CYAN   = "#00d2ff"
COLOR_GREEN         = "#00e676"
COLOR_RED           = "#ff1744"
COLOR_ORANGE        = "#ff9100"
COLOR_TEXT_PRIMARY   = "#e0e0e0"
COLOR_TEXT_SECONDARY = "#9e9e9e"
COLOR_PLOT_BG       = "#0d1117"
COLOR_PLOT_GRID     = "#21262d"
COLOR_PLOT_LINE     = "#58a6ff"


# ---------------------------------------------------------------------------
# Pomocne funkce
# ---------------------------------------------------------------------------

def freq_formatter(x, _):
    """Formatuje frekvenci do citelne podoby."""
    if x >= 1e9:
        return f"{x / 1e9:.2f} GHz"
    elif x >= 1e6:
        return f"{x / 1e6:.0f} MHz"
    else:
        return f"{x / 1e3:.0f} kHz"


def load_vna_csv(filepath: str) -> tuple:
    """
    Nacte VNA export CSV.
    Vraci: (freqs, data, sweep_numbers)
    """
    with open(filepath, "r", encoding="utf-8") as f:
        header_line = f.readline().strip()

    headers = [h.strip() for h in header_line.split(",")]

    # Detekce formatu: "Sweep_Nr,freq1..." / "Timestamp,Sweep_Nr,freq1..." / "Timestamp,Sweep_Nr,Format,freq1..."
    has_format_col = False
    if headers[0].lower() in ("sweep_nr", "sweep nr"):
        freq_start_col = 1
        sweep_col = 0
    elif headers[1].lower() in ("sweep_nr", "sweep nr"):
        sweep_col = 1
        if len(headers) > 2 and headers[2].lower() in ("format", "trace_format", "trace format"):
            freq_start_col = 3
            has_format_col = True
        else:
            freq_start_col = 2
    else:
        freq_start_col = 1  # fallback
        sweep_col = 0

    freqs = np.array([float(h) for h in headers[freq_start_col:]])

    if has_format_col:
        # Col 2 contains format string (e.g. "dB Mag", "Phase")
        fmt_col_data = np.loadtxt(filepath, delimiter=",", skiprows=1, usecols=(2,), dtype=str)
        if fmt_col_data.ndim == 0:
            fmt_col_data = np.array([str(fmt_col_data)])
        
        target_fmt = "dB Mag" if "dB Mag" in fmt_col_data else fmt_col_data[0]
        mask = (fmt_col_data == target_fmt)

        raw_data = np.loadtxt(filepath, delimiter=",", skiprows=1,
                              usecols=range(freq_start_col, freq_start_col + len(freqs)))
        if raw_data.ndim == 1:
            raw_data = raw_data.reshape(1, -1)
        raw_data = raw_data[mask]

        sweep_col_data = np.loadtxt(filepath, delimiter=",", skiprows=1,
                                    usecols=(sweep_col,))
        if sweep_col_data.ndim == 0:
            sweep_numbers = np.array([int(sweep_col_data)])
        else:
            sweep_numbers = sweep_col_data.astype(int)[mask]
    else:
        raw_data = np.loadtxt(filepath, delimiter=",", skiprows=1,
                              usecols=range(freq_start_col, freq_start_col + len(freqs)))
        if raw_data.ndim == 1:
            raw_data = raw_data.reshape(1, -1)

        sweep_col_data = np.loadtxt(filepath, delimiter=",", skiprows=1,
                                    usecols=(sweep_col,))
        if sweep_col_data.ndim == 0:
            sweep_numbers = np.array([int(sweep_col_data)])
        else:
            sweep_numbers = sweep_col_data.astype(int)

    return freqs, raw_data, sweep_numbers


def find_resonances(freqs, trace, prominence=5.0, min_depth=-20.0):
    """Najde rezonancni frekvence (minima S11)."""
    if not SCIPY_AVAILABLE:
        return []

    peaks, _ = find_peaks(-trace, prominence=prominence, height=-min_depth)

    resonances = []
    for idx in peaks:
        resonances.append({
            "freq_hz": freqs[idx],
            "freq_ghz": freqs[idx] / 1e9,
            "value_db": trace[idx],
            "index": idx,
        })

    resonances.sort(key=lambda r: r["value_db"])
    return resonances


# ---------------------------------------------------------------------------
# Hlavni aplikace
# ---------------------------------------------------------------------------

class VNAAnalyzerApp(ctk.CTk):
    """GUI aplikace pro analyzu VNA CSV dat."""

    def __init__(self):
        super().__init__()

        self.title(f"{APP_TITLE}  v{APP_VERSION}")
        self.geometry(WINDOW_SIZE)
        self.minsize(1100, 700)

        ctk.set_appearance_mode("dark")
        ctk.set_default_color_theme("blue")

        # Data
        self._freqs = None
        self._data = None
        self._sweep_numbers = None
        self._filepath = None
        self._resonances = []

        # CDF/Gumbel stav
        self._cdf_stats = None
        self._cdf_values = None

        # UI
        self._build_ui()
        self.protocol("WM_DELETE_WINDOW", self._on_close)

    # =====================================================================
    # UI
    # =====================================================================

    def _build_ui(self):
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(1, weight=1)

        # Header
        self._build_header()

        # Hlavni oblast
        main_frame = ctk.CTkFrame(self, fg_color="transparent")
        main_frame.grid(row=1, column=0, sticky="nsew", padx=10, pady=(0, 5))
        main_frame.grid_columnconfigure(1, weight=1)
        main_frame.grid_rowconfigure(0, weight=1)

        # Levy panel
        self._build_left_panel(main_frame)

        # Plot oblast se zalozkami
        self._build_tabbed_plot_area(main_frame)

        # Statusbar
        self._build_statusbar()

    def _build_header(self):
        header = ctk.CTkFrame(self, height=56, corner_radius=0,
                              fg_color=COLOR_ACCENT_BLUE)
        header.grid(row=0, column=0, sticky="ew")
        header.grid_columnconfigure(1, weight=1)

        title = ctk.CTkLabel(
            header, text="  VNA CSV Analyzer",
            font=ctk.CTkFont(family="Segoe UI", size=20, weight="bold"),
            text_color="#ffffff",
        )
        title.grid(row=0, column=0, padx=15, pady=10, sticky="w")

        ver = ctk.CTkLabel(
            header, text=f"v{APP_VERSION}",
            font=ctk.CTkFont(size=12),
            text_color=COLOR_TEXT_SECONDARY,
        )
        ver.grid(row=0, column=2, padx=15, pady=10, sticky="e")

    def _build_left_panel(self, parent):
        panel = ctk.CTkFrame(parent, width=300, fg_color=COLOR_BG_CARD,
                             corner_radius=12)
        panel.grid(row=0, column=0, sticky="ns", padx=(0, 8))
        panel.grid_propagate(False)

        # -- Soubor --
        self._section_label(panel, "Nacist CSV soubor", 0)

        self._load_btn = ctk.CTkButton(
            panel, text="Vybrat CSV soubor...", width=260, height=40,
            font=ctk.CTkFont(size=14, weight="bold"),
            fg_color=COLOR_ACCENT_CYAN, text_color="#000000",
            hover_color="#00b8d4",
            command=self._load_file,
        )
        self._load_btn.grid(row=1, column=0, padx=15, pady=(8, 5), sticky="w")

        self._file_label = ctk.CTkLabel(
            panel, text="Zadny soubor",
            font=ctk.CTkFont(size=11), text_color=COLOR_TEXT_SECONDARY,
            wraplength=250, justify="left",
        )
        self._file_label.grid(row=2, column=0, padx=15, pady=(0, 5), sticky="w")

        # Separator
        sep = ctk.CTkFrame(panel, height=2, fg_color=COLOR_ACCENT_BLUE)
        sep.grid(row=3, column=0, sticky="ew", padx=15, pady=8)

        # -- Info --
        self._section_label(panel, "Informace o datech", 4)

        self._info_text = ctk.CTkTextbox(
            panel, width=260, height=160,
            font=ctk.CTkFont(family="Consolas", size=11),
            fg_color="#0d1117", text_color=COLOR_TEXT_PRIMARY,
            corner_radius=8,
        )
        self._info_text.grid(row=5, column=0, padx=15, pady=(5, 5), sticky="w")
        self._info_text.insert("1.0", "Nacti CSV soubor pro zobrazeni info...")
        self._info_text.configure(state="disabled")

        # Separator
        sep2 = ctk.CTkFrame(panel, height=2, fg_color=COLOR_ACCENT_BLUE)
        sep2.grid(row=6, column=0, sticky="ew", padx=15, pady=8)

        # -- Rezonance --
        self._section_label(panel, "Rezonancni frekvence", 7)

        self._res_text = ctk.CTkTextbox(
            panel, width=260, height=200,
            font=ctk.CTkFont(family="Consolas", size=11),
            fg_color="#0d1117", text_color=COLOR_ACCENT_CYAN,
            corner_radius=8,
        )
        self._res_text.grid(row=8, column=0, padx=15, pady=(5, 5), sticky="w")
        self._res_text.insert("1.0", "Rezonance se zobrazi po nacteni dat...")
        self._res_text.configure(state="disabled")

        # Separator
        sep3 = ctk.CTkFrame(panel, height=2, fg_color=COLOR_ACCENT_BLUE)
        sep3.grid(row=9, column=0, sticky="ew", padx=15, pady=8)

        # -- Export --
        self._export_btn = ctk.CTkButton(
            panel, text="Ulozit graf jako PNG", width=260, height=36,
            font=ctk.CTkFont(size=12, weight="bold"),
            fg_color=COLOR_ACCENT_BLUE, hover_color="#1a4a8a",
            command=self._export_png,
            state="disabled",
        )
        self._export_btn.grid(row=10, column=0, padx=15, pady=(5, 10), sticky="w")

    # -- Zalozkovy system pro grafy ------------------------------------------

    def _build_tabbed_plot_area(self, parent):
        """Oblast s grafy - zalozkovy system (Analyza + CDF/Gumbel)."""
        # Hlavni ramec pro tabview
        plot_container = ctk.CTkFrame(parent, fg_color=COLOR_BG_CARD,
                                      corner_radius=12)
        plot_container.grid(row=0, column=1, sticky="nsew")
        plot_container.grid_columnconfigure(0, weight=1)
        plot_container.grid_rowconfigure(0, weight=1)

        # CTkTabview
        self._tabview = ctk.CTkTabview(
            plot_container,
            fg_color=COLOR_BG_CARD,
            segmented_button_fg_color=COLOR_ACCENT_BLUE,
            segmented_button_selected_color=COLOR_ACCENT_CYAN,
            segmented_button_selected_hover_color="#00b8d4",
            segmented_button_unselected_color=COLOR_ACCENT_BLUE,
            segmented_button_unselected_hover_color="#1a4a8a",
            text_color="#000000",
            text_color_disabled=COLOR_TEXT_SECONDARY,
            corner_radius=10,
        )
        self._tabview.grid(row=0, column=0, sticky="nsew", padx=4, pady=4)

        # Zalozka 1: Analyza (stavajici 4-panelovy graf)
        tab_analysis = self._tabview.add("Analyza")
        self._build_analysis_tab(tab_analysis)

        # Zalozka 2: CDF / Gumbel (nova)
        tab_cdf = self._tabview.add("CDF / Gumbel")
        self._build_cdf_tab(tab_cdf)

    def _build_analysis_tab(self, tab):
        """Stavajici analyticky graf - presunuty do zalozky."""
        tab.grid_columnconfigure(0, weight=1)
        tab.grid_rowconfigure(0, weight=1)

        plt.style.use("dark_background")

        self._fig = Figure(figsize=(12, 8), dpi=100, facecolor=COLOR_PLOT_BG)
        self._show_welcome()

        self._canvas = FigureCanvasTkAgg(self._fig, master=tab)
        self._canvas.draw()
        canvas_widget = self._canvas.get_tk_widget()
        canvas_widget.grid(row=0, column=0, sticky="nsew", padx=4, pady=(4, 0))

        # Toolbar
        toolbar_frame = ctk.CTkFrame(tab, fg_color="transparent", height=36)
        toolbar_frame.grid(row=1, column=0, sticky="ew", padx=4, pady=(0, 4))
        self._toolbar = NavigationToolbar2Tk(self._canvas, toolbar_frame)
        self._toolbar.update()

    def _build_cdf_tab(self, tab):
        """Nova zalozka CDF / Gumbel s ovladanim a grafy."""
        tab.grid_columnconfigure(1, weight=1)
        tab.grid_rowconfigure(0, weight=1)

        # -- Levy ovladaci panel uvnitr zalozky --
        ctrl_panel = ctk.CTkFrame(tab, width=260, fg_color=COLOR_BG_DARK,
                                  corner_radius=10)
        ctrl_panel.grid(row=0, column=0, sticky="ns", padx=(4, 6), pady=4)
        ctrl_panel.grid_propagate(False)

        row = 0

        # Sekce: Nastaveni analyzy
        self._section_label(ctrl_panel, "Nastaveni CDF", row)
        row += 1

        # Rezim analyzy
        ctk.CTkLabel(ctrl_panel, text="Rezim analyzy:",
                     font=ctk.CTkFont(size=11),
                     text_color=COLOR_TEXT_SECONDARY).grid(
            row=row, column=0, padx=12, pady=(8, 0), sticky="w")
        row += 1

        mode_keys = list(ANALYSIS_MODES.keys())
        self._cdf_mode_var = ctk.StringVar(value=mode_keys[0])
        self._cdf_mode_menu = ctk.CTkOptionMenu(
            ctrl_panel, values=mode_keys, variable=self._cdf_mode_var,
            width=230, height=30,
            fg_color=COLOR_ACCENT_BLUE, button_color=COLOR_ACCENT_CYAN,
            button_hover_color="#00b8d4",
            command=self._on_cdf_mode_change,
        )
        self._cdf_mode_menu.grid(row=row, column=0, padx=12, pady=(2, 5), sticky="w")
        row += 1

        # Frekvence (rezim A)
        ctk.CTkLabel(ctrl_panel, text="Frekvence [GHz]:",
                     font=ctk.CTkFont(size=11),
                     text_color=COLOR_TEXT_SECONDARY).grid(
            row=row, column=0, padx=12, pady=(5, 0), sticky="w")
        row += 1

        self._cdf_freq_entry = ctk.CTkEntry(
            ctrl_panel, width=230, height=28, placeholder_text="2.45")
        self._cdf_freq_entry.grid(row=row, column=0, padx=12, pady=(2, 5), sticky="w")
        self._cdf_freq_entry.insert(0, "2.45")
        row += 1

        # Pasmo start (rezimy B/C/D)
        ctk.CTkLabel(ctrl_panel, text="Pasmo - start [GHz]:",
                     font=ctk.CTkFont(size=11),
                     text_color=COLOR_TEXT_SECONDARY).grid(
            row=row, column=0, padx=12, pady=(5, 0), sticky="w")
        row += 1

        self._cdf_band_start_entry = ctk.CTkEntry(
            ctrl_panel, width=230, height=28, placeholder_text="1.12")
        self._cdf_band_start_entry.grid(row=row, column=0, padx=12, pady=(2, 5), sticky="w")
        self._cdf_band_start_entry.insert(0, "1.12")
        self._cdf_band_start_entry.configure(state="disabled")
        row += 1

        # Pasmo stop
        ctk.CTkLabel(ctrl_panel, text="Pasmo - stop [GHz]:",
                     font=ctk.CTkFont(size=11),
                     text_color=COLOR_TEXT_SECONDARY).grid(
            row=row, column=0, padx=12, pady=(5, 0), sticky="w")
        row += 1

        self._cdf_band_stop_entry = ctk.CTkEntry(
            ctrl_panel, width=230, height=28, placeholder_text="4.12")
        self._cdf_band_stop_entry.grid(row=row, column=0, padx=12, pady=(2, 5), sticky="w")
        self._cdf_band_stop_entry.insert(0, "4.12")
        self._cdf_band_stop_entry.configure(state="disabled")
        row += 1

        # Min. sweepu pro fit
        ctk.CTkLabel(ctrl_panel, text="Min. sweepu pro fit:",
                     font=ctk.CTkFont(size=11),
                     text_color=COLOR_TEXT_SECONDARY).grid(
            row=row, column=0, padx=12, pady=(5, 0), sticky="w")
        row += 1

        self._cdf_min_sweeps_entry = ctk.CTkEntry(
            ctrl_panel, width=230, height=28, placeholder_text="20")
        self._cdf_min_sweeps_entry.grid(row=row, column=0, padx=12, pady=(2, 8), sticky="w")
        self._cdf_min_sweeps_entry.insert(0, "20")
        row += 1

        # Separator
        sep = ctk.CTkFrame(ctrl_panel, height=2, fg_color=COLOR_ACCENT_BLUE)
        sep.grid(row=row, column=0, sticky="ew", padx=12, pady=6)
        row += 1

        # Tlacitko Spocitat
        self._cdf_compute_btn = ctk.CTkButton(
            ctrl_panel, text="Spocitat", width=230, height=40,
            font=ctk.CTkFont(size=13, weight="bold"),
            fg_color=COLOR_ACCENT_CYAN, text_color="#000000",
            hover_color="#00b8d4",
            command=self._compute_cdf_gumbel,
            state="disabled",
        )
        self._cdf_compute_btn.grid(row=row, column=0, padx=12, pady=(5, 5), sticky="w")
        row += 1

        # Separator
        sep2 = ctk.CTkFrame(ctrl_panel, height=2, fg_color=COLOR_ACCENT_BLUE)
        sep2.grid(row=row, column=0, sticky="ew", padx=12, pady=6)
        row += 1

        # Export tlacitka
        self._cdf_export_png_btn = ctk.CTkButton(
            ctrl_panel, text="Export PNG", width=230, height=32,
            font=ctk.CTkFont(size=11, weight="bold"),
            fg_color=COLOR_ACCENT_BLUE, hover_color="#1a4a8a",
            command=self._export_cdf_png,
            state="disabled",
        )
        self._cdf_export_png_btn.grid(row=row, column=0, padx=12, pady=(5, 3), sticky="w")
        row += 1

        self._cdf_export_csv_btn = ctk.CTkButton(
            ctrl_panel, text="Export CSV", width=230, height=32,
            font=ctk.CTkFont(size=11, weight="bold"),
            fg_color=COLOR_ACCENT_BLUE, hover_color="#1a4a8a",
            command=lambda: self._export_cdf_data("csv"),
            state="disabled",
        )
        self._cdf_export_csv_btn.grid(row=row, column=0, padx=12, pady=(0, 3), sticky="w")
        row += 1

        self._cdf_export_xlsx_btn = ctk.CTkButton(
            ctrl_panel, text="Export XLSX", width=230, height=32,
            font=ctk.CTkFont(size=11, weight="bold"),
            fg_color=COLOR_ACCENT_BLUE, hover_color="#1a4a8a",
            command=lambda: self._export_cdf_data("xlsx"),
            state="disabled",
        )
        self._cdf_export_xlsx_btn.grid(row=row, column=0, padx=12, pady=(0, 5), sticky="w")
        row += 1

        # -- Prava oblast: grafy + vysledky --
        right_frame = ctk.CTkFrame(tab, fg_color="transparent")
        right_frame.grid(row=0, column=1, sticky="nsew", padx=(0, 4), pady=4)
        right_frame.grid_columnconfigure(0, weight=1)
        right_frame.grid_rowconfigure(0, weight=3)   # grafy
        right_frame.grid_rowconfigure(1, weight=0)   # toolbar
        right_frame.grid_rowconfigure(2, weight=1)   # vysledky

        # CDF graf
        self._cdf_fig = Figure(figsize=(10, 6), dpi=100, facecolor=COLOR_PLOT_BG)
        self._show_cdf_welcome()

        self._cdf_canvas = FigureCanvasTkAgg(self._cdf_fig, master=right_frame)
        self._cdf_canvas.draw()
        self._cdf_canvas.get_tk_widget().grid(row=0, column=0, sticky="nsew",
                                               padx=0, pady=(0, 0))

        # Toolbar pro CDF graf
        cdf_toolbar_frame = ctk.CTkFrame(right_frame, fg_color="transparent",
                                          height=36)
        cdf_toolbar_frame.grid(row=1, column=0, sticky="ew", padx=0, pady=(0, 2))
        self._cdf_toolbar = NavigationToolbar2Tk(self._cdf_canvas,
                                                  cdf_toolbar_frame)
        self._cdf_toolbar.update()

        # Panel s vysledky
        results_frame = ctk.CTkFrame(right_frame, fg_color=COLOR_BG_DARK,
                                      corner_radius=10, height=180)
        results_frame.grid(row=2, column=0, sticky="nsew", padx=0, pady=(2, 0))
        results_frame.grid_columnconfigure(0, weight=1)
        results_frame.grid_rowconfigure(0, weight=1)

        self._cdf_results_text = ctk.CTkTextbox(
            results_frame, width=600, height=150,
            font=ctk.CTkFont(family="Consolas", size=11),
            fg_color="#0d1117", text_color=COLOR_TEXT_PRIMARY,
            corner_radius=8,
        )
        self._cdf_results_text.grid(row=0, column=0, sticky="nsew",
                                     padx=8, pady=8)
        self._cdf_results_text.insert("1.0",
            'Nacti CSV a klikni "Spocitat" pro CDF / Gumbel analyzu...')
        self._cdf_results_text.configure(state="disabled")

    # -- Pomocne metody pro CDF zalozku --------------------------------------

    def _on_cdf_mode_change(self, value):
        """Prepina dostupnost poli podle zvoleneho rezimu."""
        mode_key = ANALYSIS_MODES.get(value, "single_freq")

        if mode_key == "single_freq":
            self._cdf_freq_entry.configure(state="normal")
            self._cdf_band_start_entry.configure(state="disabled")
            self._cdf_band_stop_entry.configure(state="disabled")
        else:
            self._cdf_freq_entry.configure(state="disabled")
            self._cdf_band_start_entry.configure(state="normal")
            self._cdf_band_stop_entry.configure(state="normal")

    def _show_cdf_welcome(self):
        """Uvitaci text v CDF grafu."""
        self._cdf_fig.clear()
        ax = self._cdf_fig.add_subplot(111)
        ax.set_facecolor(COLOR_PLOT_BG)
        ax.text(0.5, 0.55, "CDF / Gumbel analyza",
                transform=ax.transAxes, ha="center", va="center",
                fontsize=24, fontweight="bold", color=COLOR_ACCENT_CYAN,
                fontfamily="Segoe UI")
        ax.text(0.5, 0.40, 'Nacti CSV soubor -> zvol rezim -> klikni "Spocitat"',
                transform=ax.transAxes, ha="center", va="center",
                fontsize=12, color=COLOR_TEXT_SECONDARY,
                fontfamily="Segoe UI")
        ax.set_xticks([])
        ax.set_yticks([])
        for spine in ax.spines.values():
            spine.set_visible(False)

    def _compute_cdf_gumbel(self):
        """Hlavni vypocet CDF/Gumbel po kliknuti na tlacitko."""
        if self._data is None or self._freqs is None:
            self._set_status("Nejdriv nacti CSV soubor!", COLOR_RED)
            return

        try:
            # Ziskani parametru z UI
            mode_label = self._cdf_mode_var.get()
            mode_key = ANALYSIS_MODES[mode_label]

            min_sweeps = int(self._cdf_min_sweeps_entry.get().strip())

            freq_value_hz = None
            band_start_hz = None
            band_stop_hz = None

            if mode_key == "single_freq":
                freq_ghz = float(self._cdf_freq_entry.get().strip())
                freq_value_hz = freq_ghz * 1e9
            else:
                band_start_hz = float(self._cdf_band_start_entry.get().strip()) * 1e9
                band_stop_hz = float(self._cdf_band_stop_entry.get().strip()) * 1e9

            # Extrakce datove rady
            self._cdf_values = extract_series_for_mode(
                self._data, self._freqs, mode_key,
                freq_value_hz=freq_value_hz,
                band_start_hz=band_start_hz,
                band_stop_hz=band_stop_hz,
            )

            n = len(self._cdf_values[~np.isnan(self._cdf_values)])

            # Vykresleni
            self._cdf_stats = plot_cdf_and_gumbel(
                self._cdf_fig, self._cdf_values, mode_key,
                mode_label=mode_label, min_sweeps=min_sweeps,
            )
            self._cdf_canvas.draw_idle()

            # Zobrazeni vysledku
            if self._cdf_stats:
                stats_text = format_statistics_text(self._cdf_stats, mode_label)
            else:
                stats_text = "Vypocet se nezdaril - zkontroluj nastaveni."

            self._cdf_results_text.configure(state="normal")
            self._cdf_results_text.delete("1.0", "end")
            self._cdf_results_text.insert("1.0", stats_text)
            self._cdf_results_text.configure(state="disabled")

            # Aktivace export tlacitek
            self._cdf_export_png_btn.configure(state="normal")
            self._cdf_export_csv_btn.configure(state="normal")
            self._cdf_export_xlsx_btn.configure(state="normal")

            self._set_status(
                f"CDF/Gumbel: {n} vzorku, rezim {mode_label}",
                COLOR_GREEN,
            )

        except ValueError as e:
            self._set_status(f"Chyba: {e}", COLOR_RED)
        except Exception as e:
            self._set_status(f"Neocekavana chyba: {e}", COLOR_RED)

    def _export_cdf_png(self):
        """Ulozi CDF/Gumbel graf jako PNG."""
        if self._cdf_stats is None:
            return

        default_name = "cdf_gumbel_analysis.png"
        if self._filepath:
            base = os.path.splitext(os.path.basename(self._filepath))[0]
            default_name = f"{base}_cdf_gumbel.png"

        filepath = filedialog.asksaveasfilename(
            defaultextension=".png",
            filetypes=[("PNG obrazek", "*.png"), ("Vsechny soubory", "*.*")],
            initialfile=default_name,
        )
        if not filepath:
            return

        try:
            self._cdf_fig.savefig(filepath, dpi=150,
                                   facecolor=self._cdf_fig.get_facecolor())
            self._set_status(f"CDF graf ulozen: {filepath}", COLOR_GREEN)
        except Exception as e:
            self._set_status(f"Chyba exportu PNG: {e}", COLOR_RED)

    def _export_cdf_data(self, file_format: str):
        """Exportuje CDF/Gumbel vysledky do CSV nebo XLSX."""
        if self._cdf_stats is None or self._cdf_values is None:
            return

        if file_format == "xlsx":
            ext = ".xlsx"
            ftypes = [("Excel soubor", "*.xlsx"), ("Vsechny soubory", "*.*")]
        else:
            ext = ".csv"
            ftypes = [("CSV soubor", "*.csv"), ("Vsechny soubory", "*.*")]

        default_name = f"cdf_gumbel_results{ext}"
        if self._filepath:
            base = os.path.splitext(os.path.basename(self._filepath))[0]
            default_name = f"{base}_cdf_gumbel{ext}"

        filepath = filedialog.asksaveasfilename(
            defaultextension=ext,
            filetypes=ftypes,
            initialfile=default_name,
        )
        if not filepath:
            return

        try:
            export_cdf_results(self._cdf_stats, self._cdf_values,
                               filepath, file_format=file_format)
            self._set_status(f"Vysledky exportovany: {filepath}", COLOR_GREEN)
        except Exception as e:
            self._set_status(f"Chyba exportu: {e}", COLOR_RED)

    # =====================================================================
    # Stavajici funkce (beze zmeny)
    # =====================================================================

    def _build_statusbar(self):
        statusbar = ctk.CTkFrame(self, height=30, corner_radius=0,
                                 fg_color=COLOR_ACCENT_BLUE)
        statusbar.grid(row=2, column=0, sticky="ew")

        self._status_label = ctk.CTkLabel(
            statusbar, text="  Pripraveno - nacti CSV soubor",
            font=ctk.CTkFont(size=11), text_color=COLOR_TEXT_PRIMARY,
        )
        self._status_label.grid(row=0, column=0, padx=10, pady=3, sticky="w")

    # =====================================================================
    # Helpers
    # =====================================================================

    def _section_label(self, parent, text, row):
        label = ctk.CTkLabel(
            parent, text=text,
            font=ctk.CTkFont(size=14, weight="bold"),
            text_color=COLOR_TEXT_PRIMARY,
        )
        label.grid(row=row, column=0, padx=15, pady=(10, 0), sticky="w")

    def _set_status(self, text, color=COLOR_TEXT_PRIMARY):
        self._status_label.configure(text=f"  {text}", text_color=color)

    def _show_welcome(self):
        """Zobrazi uvitaci text v grafu."""
        self._fig.clear()
        ax = self._fig.add_subplot(111)
        ax.set_facecolor(COLOR_PLOT_BG)
        ax.text(0.5, 0.55, "VNA CSV Analyzer",
                transform=ax.transAxes, ha="center", va="center",
                fontsize=28, fontweight="bold", color=COLOR_ACCENT_CYAN,
                fontfamily="Segoe UI")
        ax.text(0.5, 0.42, "Nacti CSV soubor pro zobrazeni analyzy",
                transform=ax.transAxes, ha="center", va="center",
                fontsize=14, color=COLOR_TEXT_SECONDARY,
                fontfamily="Segoe UI")
        ax.set_xticks([])
        ax.set_yticks([])
        for spine in ax.spines.values():
            spine.set_visible(False)

    # =====================================================================
    # Load CSV
    # =====================================================================

    def _load_file(self):
        filepath = filedialog.askopenfilename(
            title="Vyber VNA CSV soubor",
            filetypes=[("CSV soubory", "*.csv"), ("Vsechny soubory", "*.*")],
        )
        if not filepath:
            return

        self._set_status(f"Nacitam {os.path.basename(filepath)}...", COLOR_ORANGE)
        self.update_idletasks()

        try:
            self._freqs, self._data, self._sweep_numbers = load_vna_csv(filepath)
            self._filepath = filepath

            n_sweeps, n_points = self._data.shape

            # Info panel
            self._info_text.configure(state="normal")
            self._info_text.delete("1.0", "end")
            info_lines = [
                f"Soubor: {os.path.basename(filepath)}",
                f"",
                f"Sweepu:    {n_sweeps}",
                f"Bodu/sweep: {n_points}",
                f"",
                f"F start: {freq_formatter(self._freqs[0], None)}",
                f"F stop:  {freq_formatter(self._freqs[-1], None)}",
                f"F krok:  {(self._freqs[1]-self._freqs[0])/1e3:.1f} kHz",
                f"",
                f"S21 min: {np.min(self._data):.2f} dB",
                f"S21 max: {np.max(self._data):.2f} dB",
                f"S21 avg: {np.mean(self._data):.2f} dB",
            ]
            self._info_text.insert("1.0", "\n".join(info_lines))
            self._info_text.configure(state="disabled")

            # File label
            self._file_label.configure(
                text=f"{os.path.basename(filepath)}",
                text_color=COLOR_GREEN,
            )

            # Vykreslit grafy
            self._create_analysis_plots()

            # Rezonance report
            self._show_resonance_report()

            # Enable export a CDF tlacitko
            self._export_btn.configure(state="normal")
            self._cdf_compute_btn.configure(state="normal")

            # Automaticky nastavit frekvencni rozsah pro CDF podle dat
            f_start_ghz = self._freqs[0] / 1e9
            f_stop_ghz = self._freqs[-1] / 1e9
            # Update band entries
            self._cdf_band_start_entry.configure(state="normal")
            self._cdf_band_start_entry.delete(0, "end")
            self._cdf_band_start_entry.insert(0, f"{f_start_ghz:.3f}")
            self._cdf_band_stop_entry.configure(state="normal")
            self._cdf_band_stop_entry.delete(0, "end")
            self._cdf_band_stop_entry.insert(0, f"{f_stop_ghz:.3f}")
            # Restore state based on current mode
            self._on_cdf_mode_change(self._cdf_mode_var.get())

            self._set_status(
                f"Nacteno: {n_sweeps} sweepu, {n_points} bodu - "
                f"{freq_formatter(self._freqs[0], None)} az {freq_formatter(self._freqs[-1], None)}",
                COLOR_GREEN,
            )

        except Exception as e:
            self._set_status(f"Chyba: {e}", COLOR_RED)
            self._file_label.configure(text=f"Chyba: {e}", text_color=COLOR_RED)

    # =====================================================================
    # Analysis Plots (stavajici - beze zmeny)
    # =====================================================================

    def _create_analysis_plots(self):
        """Vykresli 4-panelovy analyticky graf."""
        freqs = self._freqs
        data = self._data
        sweep_numbers = self._sweep_numbers

        self._fig.clear()

        gs = GridSpec(2, 2, figure=self._fig, hspace=0.35, wspace=0.28,
                      left=0.06, right=0.96, top=0.93, bottom=0.08)

        self._fig.suptitle("VNA Data Analysis", fontsize=16, fontweight="bold",
                           color=COLOR_ACCENT_CYAN, y=0.98)

        # Barvy pro cary
        cmap = plt.cm.viridis
        n = len(sweep_numbers)
        colors = [cmap(i / max(n - 1, 1)) for i in range(n)]

        # ---- Panel 1: Vsechny sweepy ----
        ax1 = self._fig.add_subplot(gs[0, 0])
        ax1.set_facecolor(COLOR_PLOT_BG)

        for i, (snr, trace) in enumerate(zip(sweep_numbers, data)):
            alpha = 0.3 + 0.7 * (i / max(n - 1, 1))
            lbl = f"Sweep {snr}" if i in [0, n - 1] else None
            ax1.plot(freqs, trace, color=colors[i], linewidth=0.8,
                     alpha=alpha, label=lbl)

        ax1.set_xlabel("Frekvence", fontsize=9)
        ax1.set_ylabel("S21 [dB]", fontsize=9)
        ax1.set_title("Vsechny sweepy (prekryte)", fontsize=11,
                       fontweight="bold", color="#e0e0e0", pad=6)
        ax1.xaxis.set_major_formatter(FuncFormatter(freq_formatter))
        ax1.grid(True, color=COLOR_PLOT_GRID, alpha=0.5, linewidth=0.5)
        ax1.legend(fontsize=7, loc="lower left", framealpha=0.3)
        plt.setp(ax1.xaxis.get_majorticklabels(), rotation=25, ha="right", fontsize=7)
        ax1.tick_params(labelsize=7)

        # ---- Panel 2: Heatmapa ----
        ax2 = self._fig.add_subplot(gs[0, 1])
        ax2.set_facecolor(COLOR_PLOT_BG)

        step = max(1, len(freqs) // 500)
        im = ax2.pcolormesh(freqs[::step], sweep_numbers, data[:, ::step],
                            cmap="inferno", shading="auto")
        cbar = self._fig.colorbar(im, ax=ax2, label="S21 [dB]", pad=0.02)
        cbar.ax.tick_params(labelsize=7)

        ax2.set_xlabel("Frekvence", fontsize=9)
        ax2.set_ylabel("Sweep #", fontsize=9)
        ax2.set_title("Heatmapa - vyvoj v case", fontsize=11,
                       fontweight="bold", color="#e0e0e0", pad=6)
        ax2.xaxis.set_major_formatter(FuncFormatter(freq_formatter))
        plt.setp(ax2.xaxis.get_majorticklabels(), rotation=25, ha="right", fontsize=7)
        ax2.tick_params(labelsize=7)

        # ---- Panel 3: Statistika + rezonance ----
        ax3 = self._fig.add_subplot(gs[1, 0])
        ax3.set_facecolor(COLOR_PLOT_BG)

        mean_trace = np.mean(data, axis=0)
        std_trace = np.std(data, axis=0)
        min_trace = np.min(data, axis=0)
        max_trace = np.max(data, axis=0)

        ax3.fill_between(freqs, min_trace, max_trace, alpha=0.15,
                         color=COLOR_PLOT_LINE, label="Min-Max")
        ax3.fill_between(freqs, mean_trace - std_trace, mean_trace + std_trace,
                         alpha=0.3, color=COLOR_PLOT_LINE, label="+/-1s")
        ax3.plot(freqs, mean_trace, color=COLOR_PLOT_LINE, linewidth=1.5,
                 label="Prumer")

        # Rezonance
        self._resonances = find_resonances(freqs, mean_trace)
        for res in self._resonances[:8]:
            ax3.axvline(res["freq_hz"], color="#ff6b6b", alpha=0.4,
                        linewidth=0.8, linestyle="--")
            ax3.annotate(
                f"{res['freq_ghz']:.3f} GHz\n{res['value_db']:.1f} dB",
                xy=(res["freq_hz"], res["value_db"]),
                xytext=(0, -22), textcoords="offset points",
                fontsize=6, color="#ff6b6b", fontweight="bold", ha="center",
                arrowprops=dict(arrowstyle="->", color="#ff6b6b", lw=0.7),
            )

        ax3.set_xlabel("Frekvence", fontsize=9)
        ax3.set_ylabel("S21 [dB]", fontsize=9)
        ax3.set_title("Statistika + rezonancni frekvence", fontsize=11,
                       fontweight="bold", color="#e0e0e0", pad=6)
        ax3.xaxis.set_major_formatter(FuncFormatter(freq_formatter))
        ax3.grid(True, color=COLOR_PLOT_GRID, alpha=0.5, linewidth=0.5)
        ax3.legend(fontsize=7, loc="lower left", framealpha=0.3)
        plt.setp(ax3.xaxis.get_majorticklabels(), rotation=25, ha="right", fontsize=7)
        ax3.tick_params(labelsize=7)

        # ---- Panel 4: Stabilita ----
        ax4 = self._fig.add_subplot(gs[1, 1])
        ax4.set_facecolor(COLOR_PLOT_BG)

        spread = max_trace - min_trace
        ax4.fill_between(freqs, 0, spread, alpha=0.4, color=COLOR_GREEN)
        ax4.plot(freqs, spread, color=COLOR_GREEN, linewidth=1.0)
        ax4.plot(freqs, std_trace, color=COLOR_ORANGE, linewidth=1.0, alpha=0.8,
                 label="Smerodatna odchylka")

        ax4.set_xlabel("Frekvence", fontsize=9)
        ax4.set_ylabel("Rozptyl [dB]", fontsize=9)
        ax4.set_title("Stabilita mereni (max-min)", fontsize=11,
                       fontweight="bold", color="#e0e0e0", pad=6)
        ax4.xaxis.set_major_formatter(FuncFormatter(freq_formatter))
        ax4.grid(True, color=COLOR_PLOT_GRID, alpha=0.5, linewidth=0.5)
        ax4.legend(fontsize=7, loc="upper right", framealpha=0.3)
        plt.setp(ax4.xaxis.get_majorticklabels(), rotation=25, ha="right", fontsize=7)
        ax4.tick_params(labelsize=7)

        self._canvas.draw_idle()

    # =====================================================================
    # Resonance Report (stavajici - beze zmeny)
    # =====================================================================

    def _show_resonance_report(self):
        self._res_text.configure(state="normal")
        self._res_text.delete("1.0", "end")

        if not self._resonances:
            self._res_text.insert("1.0", "Zadne rezonance\nnalezeny.")
            self._res_text.configure(state="disabled")
            return

        lines = [f"{'#':>2}  {'Frekvence':>12}  {'S21':>8}", "-" * 30]

        for i, res in enumerate(self._resonances[:10], start=1):
            lines.append(
                f"{i:>2}  {res['freq_ghz']:>8.4f} GHz  {res['value_db']:>7.1f} dB"
            )

        lines.append("")
        lines.append(f"Nalezeno {len(self._resonances)} rezonanci")

        self._res_text.insert("1.0", "\n".join(lines))
        self._res_text.configure(state="disabled")

    # =====================================================================
    # Export PNG (stavajici - beze zmeny)
    # =====================================================================

    def _export_png(self):
        if self._data is None:
            return

        default_name = os.path.splitext(os.path.basename(self._filepath))[0] + "_analysis.png"

        filepath = filedialog.asksaveasfilename(
            defaultextension=".png",
            filetypes=[("PNG obrazek", "*.png"), ("Vsechny soubory", "*.*")],
            initialfile=default_name,
        )
        if not filepath:
            return

        try:
            self._fig.savefig(filepath, dpi=150, facecolor=self._fig.get_facecolor())
            self._set_status(f"Graf ulozen: {filepath}", COLOR_GREEN)
        except Exception as e:
            self._set_status(f"Chyba exportu: {e}", COLOR_RED)

    # =====================================================================
    # Cleanup
    # =====================================================================

    def _on_close(self):
        self.quit()
        self.destroy()


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------
def main():
    app = VNAAnalyzerApp()
    app.mainloop()


if __name__ == "__main__":
    main()
