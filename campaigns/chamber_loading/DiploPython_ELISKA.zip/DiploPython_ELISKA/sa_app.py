"""
SA Data Recorder – GUI aplikace pro kontinuální sběr dat
z Rohde & Schwarz FSP (Spectrum Analyzer) a SMF 100A (Signal Generator).

Spuštění:
    python sa_app.py

Autor: DiploPython projekt
"""

import os
import sys
import csv
import time
import threading
import queue
from datetime import datetime

import numpy as np
import customtkinter as ctk
import matplotlib
matplotlib.use("TkAgg")
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk
from matplotlib.figure import Figure
import tkinter as tk

class ToolTip:
    """Jednoduchý tooltip pro nápovědu při najetí myší."""
    def __init__(self, widget, text, delay=500):
        self.widget = widget
        self.text = text
        self.delay = delay
        self.tooltip_window = None
        self.id = None
        self._bind_recursive(self.widget)

    def _bind_recursive(self, w):
        try:
            w.bind("<Enter>", self.enter, add="+")
            w.bind("<Leave>", self.leave, add="+")
            w.bind("<ButtonPress>", self.leave, add="+")
        except (NotImplementedError, Exception):
            pass
        if hasattr(w, "winfo_children"):
            for child in w.winfo_children():
                self._bind_recursive(child)

    def enter(self, event=None):
        self.schedule()

    def leave(self, event=None):
        self.unschedule()
        self.hide()

    def schedule(self):
        self.unschedule()
        self.id = self.widget.after(self.delay, self.show)

    def unschedule(self):
        id_ = self.id
        self.id = None
        if id_:
            self.widget.after_cancel(id_)

    def show(self):
        self.unschedule()
        if self.tooltip_window:
            return
        x = self.widget.winfo_rootx() + 20
        y = self.widget.winfo_rooty() + self.widget.winfo_height() + 5
        self.tooltip_window = tw = tk.Toplevel(self.widget)
        tw.wm_overrideredirect(True)
        tw.wm_geometry(f"+{x}+{y}")
        tw.attributes("-topmost", True)
        label = tk.Label(tw, text=self.text, justify="left",
                         background="#1a1a2e", foreground="#00d2ff",
                         relief="solid", borderwidth=1,
                         font=("Segoe UI", 9))
        label.pack(ipadx=6, ipady=4)

    def hide(self):
        tw = self.tooltip_window
        self.tooltip_window = None
        if tw:
            tw.destroy()

from sa_driver import (
    FSPDriver,
    SMF100ADriver,
    SASimulator,
    DETECTORS,
    RBW_VALUES,
    VBW_VALUES,
    REF_LEVELS,
    POWER_UNITS,
)

# Import CDF/Gumbel modulu pro live panel
from cdf_gumbel import (
    ANALYSIS_MODES,
    extract_series_for_mode,
    plot_cdf_mini,
)

# ---------------------------------------------------------------------------
# Konstanty
# ---------------------------------------------------------------------------
DEFAULT_FSP_VISA = "TCPIP0::10.56.11.6::inst0::INSTR"
DEFAULT_SMF_VISA = "TCPIP0::10.56.11.14::inst0::INSTR"
APP_TITLE = "SA Data Recorder"
APP_VERSION = "1.0"
WINDOW_SIZE = "1380x850"

# Barvy (dark theme)
COLOR_BG_DARK       = "#1a1a2e"
COLOR_BG_CARD       = "#16213e"
COLOR_ACCENT_BLUE   = "#0f3460"
COLOR_ACCENT_CYAN   = "#00d2ff"
COLOR_GREEN         = "#00e676"
COLOR_RED           = "#ff1744"
COLOR_ORANGE        = "#ff9100"
COLOR_TEXT_PRIMARY   = "#e0e0e0"
COLOR_TEXT_SECONDARY = "#9e9e9e"
COLOR_PLOT_BG       = "#0d1117"
COLOR_PLOT_GRID     = "#21262d"
COLOR_PLOT_LINE     = "#58a6ff"
COLOR_PLOT_LINE2    = "#f78166"


# ---------------------------------------------------------------------------
# Hlavní aplikace
# ---------------------------------------------------------------------------
class SAApp(ctk.CTk):
    """Hlavní okno GUI aplikace pro sběr SA dat."""

    def __init__(self):
        super().__init__()

        # -- Nastavení okna --
        self.title(f"{APP_TITLE}  v{APP_VERSION}")
        self.geometry(WINDOW_SIZE)
        self.minsize(1100, 750)

        # CustomTkinter appearance
        ctk.set_appearance_mode("dark")
        ctk.set_default_color_theme("blue")

        # -- Stav aplikace --
        self._driver_fsp = None       # FSPDriver | SASimulator
        self._driver_smf = None       # SMF100ADriver | SASimulator
        self._use_simulator = False

        self._is_recording = False
        self._sweep_count = 0
        self._data_queue = queue.Queue()
        self._stop_event = threading.Event()
        self._worker_thread = None
        self._csv_writer = None
        self._csv_file = None
        self._csv_filename = ""
        self._freq_axis = None
        self._history = []

        # -- Sestavení GUI --
        self._build_ui()

        # -- Periodická aktualizace grafu --
        self._schedule_plot_update()

        # -- Zavření okna --
        self.protocol("WM_DELETE_WINDOW", self._on_close)

    # =====================================================================
    # UI LAYOUT
    # =====================================================================

    def _build_ui(self):
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(1, weight=1)

        self._build_header()

        middle_frame = ctk.CTkFrame(self, fg_color="transparent")
        middle_frame.grid(row=1, column=0, sticky="nsew", padx=10, pady=(0, 5))
        middle_frame.grid_columnconfigure(1, weight=1)
        middle_frame.grid_rowconfigure(0, weight=1)

        # Levý panel je teď trochu širší kvůli více volbám a obalíme ho do ScrollableFrame
        left_scroll = ctk.CTkScrollableFrame(middle_frame, width=320, fg_color=COLOR_BG_CARD, corner_radius=12)
        left_scroll.grid(row=0, column=0, sticky="ns", padx=(0, 8), pady=0)

        self._build_left_panel(left_scroll)
        self._build_plot_area(middle_frame)

        self._build_statusbar()

    def _build_header(self):
        header = ctk.CTkFrame(self, height=56, corner_radius=0, fg_color=COLOR_ACCENT_BLUE)
        header.grid(row=0, column=0, sticky="ew")
        header.grid_columnconfigure(1, weight=1)

        title_label = ctk.CTkLabel(
            header, text="  📻  Spectrum Analyzer Data Recorder",
            font=ctk.CTkFont(family="Segoe UI", size=20, weight="bold"),
            text_color="#ffffff",
        )
        title_label.grid(row=0, column=0, padx=15, pady=10, sticky="w")

        ver_label = ctk.CTkLabel(
            header, text=f"R&S FSP & SMF100A  •  v{APP_VERSION}",
            font=ctk.CTkFont(size=12),
            text_color=COLOR_TEXT_SECONDARY,
        )
        ver_label.grid(row=0, column=2, padx=15, pady=10, sticky="e")

    def _build_left_panel(self, panel):
        row = 0

        # ----- Připojení -----
        self._build_section_label(panel, "📡  Připojení", row=row); row += 1

        ctk.CTkLabel(panel, text="FSP VISA adresa:", font=ctk.CTkFont(size=11), text_color=COLOR_TEXT_SECONDARY).grid(row=row, column=0, padx=15, pady=(5, 0), sticky="w"); row += 1
        self._fsp_visa_entry = ctk.CTkEntry(panel, width=280, placeholder_text=DEFAULT_FSP_VISA)
        self._fsp_visa_entry.grid(row=row, column=0, padx=15, pady=(2, 5), sticky="w"); row += 1
        self._fsp_visa_entry.insert(0, DEFAULT_FSP_VISA)
        ToolTip(self._fsp_visa_entry, "Adresa Spektrálního analyzátoru FSP.")

        ctk.CTkLabel(panel, text="SMF VISA adresa:", font=ctk.CTkFont(size=11), text_color=COLOR_TEXT_SECONDARY).grid(row=row, column=0, padx=15, pady=(2, 0), sticky="w"); row += 1
        self._smf_visa_entry = ctk.CTkEntry(panel, width=280, placeholder_text=DEFAULT_SMF_VISA)
        self._smf_visa_entry.grid(row=row, column=0, padx=15, pady=(2, 5), sticky="w"); row += 1
        self._smf_visa_entry.insert(0, DEFAULT_SMF_VISA)
        ToolTip(self._smf_visa_entry, "Adresa Signal Generátoru SMF 100A.")

        self._sim_var = ctk.BooleanVar(value=False)
        self._sim_check = ctk.CTkCheckBox(
            panel, text="Simulační mód (bez přístrojů)",
            variable=self._sim_var, font=ctk.CTkFont(size=12)
        )
        self._sim_check.grid(row=row, column=0, padx=15, pady=(5, 5), sticky="w"); row += 1
        ToolTip(self._sim_check, "Pro testování GUI aplikace nanečisto bez reálného hardwaru.")

        self._connect_btn = ctk.CTkButton(
            panel, text="Připojit", width=280, height=36,
            font=ctk.CTkFont(size=13, weight="bold"),
            fg_color=COLOR_ACCENT_CYAN, text_color="#000000", hover_color="#00b8d4",
            command=self._toggle_connection,
        )
        self._connect_btn.grid(row=row, column=0, padx=15, pady=(5, 5), sticky="w"); row += 1

        self._conn_info = ctk.CTkLabel(panel, text="Nepřipojeno", font=ctk.CTkFont(size=11), text_color=COLOR_TEXT_SECONDARY, wraplength=280, justify="left")
        self._conn_info.grid(row=row, column=0, padx=15, pady=(0, 5), sticky="w"); row += 1

        self._add_separator(panel, row); row += 1

        # ----- Ovládání SMF -----
        self._build_section_label(panel, "🎛️  Generátor (SMF)", row=row); row += 1

        smf_frame = ctk.CTkFrame(panel, fg_color="transparent")
        smf_frame.grid(row=row, column=0, padx=15, pady=0, sticky="w"); row += 1

        ctk.CTkLabel(smf_frame, text="Freq [GHz]:", font=ctk.CTkFont(size=11), text_color=COLOR_TEXT_SECONDARY).grid(row=0, column=0, padx=(0, 5), sticky="w")
        self._smf_freq_entry = ctk.CTkEntry(smf_frame, width=80)
        self._smf_freq_entry.grid(row=0, column=1, padx=(0, 10), sticky="w")
        self._smf_freq_entry.insert(0, "1.0")
        ToolTip(self._smf_freq_entry, "Frekvence generátoru v GHz.\nPro VIRC typicky uvnitř pásma testovací antény.")

        ctk.CTkLabel(smf_frame, text="Pow [dBm]:", font=ctk.CTkFont(size=11), text_color=COLOR_TEXT_SECONDARY).grid(row=0, column=2, padx=(0, 5), sticky="w")
        self._smf_pow_entry = ctk.CTkEntry(smf_frame, width=60)
        self._smf_pow_entry.grid(row=0, column=3, padx=(0, 0), sticky="w")
        self._smf_pow_entry.insert(0, "-30.0")
        ToolTip(self._smf_pow_entry, "Výkon generátoru v dBm.\nPOZOR: Začínejte na -30 dBm nebo méně,\naby rezonance komory nezničila vybavení!")

        self._smf_apply_btn = ctk.CTkButton(
            panel, text="Nastavit parametry SMF", width=280, height=28,
            command=self._apply_smf_settings, state="disabled"
        )
        self._smf_apply_btn.grid(row=row, column=0, padx=15, pady=(5, 5), sticky="w"); row += 1

        self._smf_rf_btn = ctk.CTkButton(
            panel, text="RF Výstup: VYP", width=280, height=32,
            fg_color=COLOR_ACCENT_BLUE, hover_color="#1a4a8a",
            command=self._toggle_smf_rf, state="disabled"
        )
        self._smf_rf_btn.grid(row=row, column=0, padx=15, pady=(0, 5), sticky="w"); row += 1

        self._add_separator(panel, row); row += 1

        # ----- Nastavení FSP -----
        self._build_section_label(panel, "⚙️  Analyzátor (FSP)", row=row); row += 1

        # Přepínač režimu frekvence
        self._freq_mode_var = ctk.StringVar(value="Start/Stop")
        freq_mode_frame = ctk.CTkFrame(panel, fg_color="transparent")
        freq_mode_frame.grid(row=row, column=0, padx=15, pady=(5, 0), sticky="ew"); row += 1
        ctk.CTkLabel(freq_mode_frame, text="Režim:", font=ctk.CTkFont(size=11), text_color=COLOR_TEXT_SECONDARY).grid(row=0, column=0, padx=(0, 5), sticky="w")
        self._freq_mode_btn = ctk.CTkSegmentedButton(
            freq_mode_frame, values=["Start/Stop", "Center/Span"],
            variable=self._freq_mode_var, command=self._on_freq_mode_change,
            width=200
        )
        self._freq_mode_btn.grid(row=0, column=1, sticky="w")
        ToolTip(freq_mode_frame, "Start/Stop: zadáváte krajní frekvence.\nCenter/Span: zadáváte střed a šířku pásma.")

        # Start/Stop řádek
        self._startstop_frame = ctk.CTkFrame(panel, fg_color="transparent")
        self._startstop_frame.grid(row=row, column=0, padx=15, pady=(5, 0), sticky="ew"); row += 1
        ctk.CTkLabel(self._startstop_frame, text="Start [GHz]:", font=ctk.CTkFont(size=11), text_color=COLOR_TEXT_SECONDARY).grid(row=0, column=0, padx=(0, 5), sticky="w")
        self._fsp_start_entry = ctk.CTkEntry(self._startstop_frame, width=60)
        self._fsp_start_entry.grid(row=0, column=1, padx=(0, 5), sticky="w")
        self._fsp_start_entry.insert(0, "0.5")
        ToolTip(self._fsp_start_entry, "Počáteční frekvence (min GHz).\nUžší pásmo výrazně zrychluje sweep.")
        ctk.CTkLabel(self._startstop_frame, text="Stop [GHz]:", font=ctk.CTkFont(size=11), text_color=COLOR_TEXT_SECONDARY).grid(row=0, column=2, padx=(5, 5), sticky="w")
        self._fsp_stop_entry = ctk.CTkEntry(self._startstop_frame, width=60)
        self._fsp_stop_entry.grid(row=0, column=3, padx=(0, 0), sticky="w")
        self._fsp_stop_entry.insert(0, "2.0")
        ToolTip(self._fsp_stop_entry, "Koncová frekvence (max GHz).\nUžší pásmo výrazně zrychluje sweep.")

        # Center/Span řádek (skrytý na začátku)
        self._centerspan_frame = ctk.CTkFrame(panel, fg_color="transparent")
        # Nechceme ho griddovat hned – schováme; grid row je sdílený se startstop
        ctk.CTkLabel(self._centerspan_frame, text="Center [GHz]:", font=ctk.CTkFont(size=11), text_color=COLOR_TEXT_SECONDARY).grid(row=0, column=0, padx=(0, 5), sticky="w")
        self._fsp_center_entry = ctk.CTkEntry(self._centerspan_frame, width=60)
        self._fsp_center_entry.grid(row=0, column=1, padx=(0, 5), sticky="w")
        self._fsp_center_entry.insert(0, "1.0")
        ToolTip(self._fsp_center_entry, "Středová frekvence v GHz.\nFSP bude měřit symetricky okolo tohoto bodu.")
        ctk.CTkLabel(self._centerspan_frame, text="Span [GHz]:", font=ctk.CTkFont(size=11), text_color=COLOR_TEXT_SECONDARY).grid(row=0, column=2, padx=(5, 5), sticky="w")
        self._fsp_span_entry = ctk.CTkEntry(self._centerspan_frame, width=60)
        self._fsp_span_entry.grid(row=0, column=3, padx=(0, 0), sticky="w")
        self._fsp_span_entry.insert(0, "1.5")
        ToolTip(self._fsp_span_entry, "Šířka pásma v GHz.\nMenší span = rychlejší sweep.")
        # Uložíme řádek pro přepínání
        self._freq_row = row - 1

        ref_lbl = ctk.CTkLabel(panel, text="Ref Level:", font=ctk.CTkFont(size=11), text_color=COLOR_TEXT_SECONDARY)
        ref_lbl.grid(row=row, column=0, padx=15, pady=(5,0), sticky="w"); row += 1
        self._ref_var = ctk.StringVar(value="0 dBm")
        self._ref_menu = ctk.CTkOptionMenu(panel, values=REF_LEVELS, variable=self._ref_var, width=280)
        self._ref_menu.grid(row=row, column=0, padx=15, pady=(2, 5), sticky="w"); row += 1
        ToolTip(self._ref_menu, "Nastavuje hardwarový útlum FSP.\nPro bezpečí začněte na 0 dBm a snižujte,\npokud je signál pod šumem.")

        rbw_lbl = ctk.CTkLabel(panel, text="RBW:", font=ctk.CTkFont(size=11), text_color=COLOR_TEXT_SECONDARY)
        rbw_lbl.grid(row=row, column=0, padx=15, pady=(2,0), sticky="w"); row += 1
        self._rbw_var = ctk.StringVar(value="Auto")
        self._rbw_menu = ctk.CTkOptionMenu(panel, values=RBW_VALUES, variable=self._rbw_var, width=280)
        self._rbw_menu.grid(row=row, column=0, padx=15, pady=(2, 5), sticky="w"); row += 1
        ToolTip(self._rbw_menu, "Resolution Bandwidth (šířka filtru).\nMenší RBW = menší šum podlahy, ale VELMI pomalý sweep.\nNa velké pásmo dejte Auto nebo velkou hodnotu.")

        ctk.CTkLabel(panel, text="VBW:", font=ctk.CTkFont(size=11), text_color=COLOR_TEXT_SECONDARY).grid(row=row, column=0, padx=15, pady=(2,0), sticky="w"); row += 1
        self._vbw_var = ctk.StringVar(value="Auto")
        self._vbw_menu = ctk.CTkOptionMenu(panel, values=VBW_VALUES, variable=self._vbw_var, width=280)
        self._vbw_menu.grid(row=row, column=0, padx=15, pady=(2, 5), sticky="w"); row += 1
        ToolTip(self._vbw_menu, "Video Bandwidth.\nVyhlazuje křivku detekovaného šumu.")

        ctk.CTkLabel(panel, text="Detector:", font=ctk.CTkFont(size=11), text_color=COLOR_TEXT_SECONDARY).grid(row=row, column=0, padx=15, pady=(2,0), sticky="w"); row += 1
        self._det_var = ctk.StringVar(value="RMS")
        self._det_menu = ctk.CTkOptionMenu(panel, values=DETECTORS, variable=self._det_var, width=280)
        self._det_menu.grid(row=row, column=0, padx=15, pady=(2, 5), sticky="w"); row += 1
        ToolTip(self._det_menu, "PEAK: bleskově zachytává špičky (doporučeno pro VIRC).\nRMS: přesný matematický průměr, ale pomalý.")

        ctk.CTkLabel(panel, text="Jednotky:", font=ctk.CTkFont(size=11), text_color=COLOR_TEXT_SECONDARY).grid(row=row, column=0, padx=15, pady=(2,0), sticky="w"); row += 1
        self._unit_var = ctk.StringVar(value="dBµV")
        self._unit_menu = ctk.CTkOptionMenu(panel, values=list(POWER_UNITS.keys()), variable=self._unit_var, width=280)
        self._unit_menu.grid(row=row, column=0, padx=15, pady=(2, 5), sticky="w"); row += 1
        ToolTip(self._unit_menu, "Jednotky osy Y na FSP.\ndBµV: běžné pro EMC měření\ndBm: výkon přijatý na vstupu\nV, W: lineární jednotky")

        self._add_separator(panel, row); row += 1

        # ----- Parametry sweepování -----
        self._build_section_label(panel, "🔄  Snímání", row=row); row += 1

        ctk.CTkLabel(panel, text="Interval:", font=ctk.CTkFont(size=11), text_color=COLOR_TEXT_SECONDARY).grid(row=row, column=0, padx=15, pady=(2,0), sticky="w"); row += 1
        self._interval_var = ctk.StringVar(value="Bez pauzy")
        self._interval_menu = ctk.CTkOptionMenu(panel, values=["Bez pauzy", "0.5 s", "1 s", "2 s", "5 s", "10 s"], variable=self._interval_var, width=280)
        self._interval_menu.grid(row=row, column=0, padx=15, pady=(2, 5), sticky="w"); row += 1

        sweep_limit_frame = ctk.CTkFrame(panel, fg_color="transparent")
        sweep_limit_frame.grid(row=row, column=0, padx=15, pady=(2, 0), sticky="w"); row += 1
        ctk.CTkLabel(sweep_limit_frame, text="Max. sweepů:", font=ctk.CTkFont(size=11), text_color=COLOR_TEXT_SECONDARY).grid(row=0, column=0, padx=(0, 5), sticky="w")
        self._sweep_limit_entry = ctk.CTkEntry(sweep_limit_frame, width=80, height=28)
        self._sweep_limit_entry.grid(row=0, column=1, padx=(0, 10), sticky="w")
        self._sweep_limit_entry.insert(0, "100")
        self._unlimited_var = ctk.BooleanVar(value=False)
        self._unlimited_check = ctk.CTkCheckBox(sweep_limit_frame, text="∞ bez limitu", variable=self._unlimited_var, font=ctk.CTkFont(size=11), command=self._toggle_sweep_limit)
        self._unlimited_check.grid(row=0, column=2, sticky="w")
        self._sweep_limit_entry.configure(state="normal")

        def _on_sa_entry_active(event=None):
            if self._unlimited_var.get():
                self._unlimited_var.set(False)

        self._sweep_limit_entry.bind("<FocusIn>", _on_sa_entry_active)
        self._sweep_limit_entry.bind("<KeyRelease>", _on_sa_entry_active)
        if hasattr(self._sweep_limit_entry, "_entry"):
            self._sweep_limit_entry._entry.bind("<FocusIn>", _on_sa_entry_active)
            self._sweep_limit_entry._entry.bind("<KeyRelease>", _on_sa_entry_active)
            self._sweep_limit_entry._entry.bind("<Button-1>", _on_sa_entry_active)

        self._start_btn = ctk.CTkButton(
            panel, text="▶  SPUSTIT SNÍMÁNÍ", width=280, height=44,
            font=ctk.CTkFont(size=14, weight="bold"),
            fg_color=COLOR_GREEN, text_color="#000000", hover_color="#00c853",
            command=self._toggle_recording, state="disabled",
        )
        self._start_btn.grid(row=row, column=0, padx=15, pady=(15, 5), sticky="w"); row += 1

        self._export_btn = ctk.CTkButton(
            panel, text="💾  Exportovat CSV", width=280, height=36,
            font=ctk.CTkFont(size=12, weight="bold"),
            fg_color=COLOR_ACCENT_BLUE, hover_color="#1a4a8a",
            command=self._export_csv, state="disabled",
        )
        self._export_btn.grid(row=row, column=0, padx=15, pady=(0, 5), sticky="w"); row += 1

        self._sweep_label = ctk.CTkLabel(panel, text="Sweepů: 0", font=ctk.CTkFont(size=12, weight="bold"), text_color=COLOR_ACCENT_CYAN)
        self._sweep_label.grid(row=row, column=0, padx=15, pady=(0, 2), sticky="w"); row += 1

        self._sweep_progress = ctk.CTkProgressBar(panel, width=280, height=8, progress_color=COLOR_ACCENT_CYAN, fg_color=COLOR_ACCENT_BLUE)
        self._sweep_progress.grid(row=row, column=0, padx=15, pady=(0, 10), sticky="w"); row += 1
        self._sweep_progress.set(0)

        self._add_separator(panel, row); row += 1

        # ----- Live CDF -----
        self._build_section_label(panel, "📊  Live CDF", row=row); row += 1
        
        ctk.CTkLabel(panel, text="Režim:", font=ctk.CTkFont(size=11), text_color=COLOR_TEXT_SECONDARY).grid(row=row, column=0, padx=15, pady=(5,0), sticky="w"); row += 1
        cdf_mode_keys = list(ANALYSIS_MODES.keys())
        self._live_cdf_mode_var = ctk.StringVar(value=cdf_mode_keys[1])
        self._live_cdf_mode_menu = ctk.CTkOptionMenu(panel, values=cdf_mode_keys, variable=self._live_cdf_mode_var, width=280, font=ctk.CTkFont(size=11))
        self._live_cdf_mode_menu.grid(row=row, column=0, padx=15, pady=(2, 3), sticky="w"); row += 1

        freq_band_frame = ctk.CTkFrame(panel, fg_color="transparent")
        freq_band_frame.grid(row=row, column=0, padx=15, pady=(0, 3), sticky="w"); row += 1
        ctk.CTkLabel(freq_band_frame, text="f [GHz]:", font=ctk.CTkFont(size=10), text_color=COLOR_TEXT_SECONDARY).grid(row=0, column=0, padx=(0, 4), sticky="w")
        self._live_cdf_freq_entry = ctk.CTkEntry(freq_band_frame, width=65, height=24, placeholder_text="1.0", font=ctk.CTkFont(size=10))
        self._live_cdf_freq_entry.grid(row=0, column=1, padx=(0, 6), sticky="w")
        self._live_cdf_freq_entry.insert(0, "1.0")
        ctk.CTkLabel(freq_band_frame, text="–", font=ctk.CTkFont(size=10), text_color=COLOR_TEXT_SECONDARY).grid(row=0, column=2, padx=2, sticky="w")
        self._live_cdf_freq_end_entry = ctk.CTkEntry(freq_band_frame, width=65, height=24, placeholder_text="2.0", font=ctk.CTkFont(size=10))
        self._live_cdf_freq_end_entry.grid(row=0, column=3, padx=(0, 4), sticky="w")
        self._live_cdf_freq_end_entry.insert(0, "2.0")

        min_sw_frame = ctk.CTkFrame(panel, fg_color="transparent")
        min_sw_frame.grid(row=row, column=0, padx=15, pady=(0, 15), sticky="w"); row += 1
        ctk.CTkLabel(min_sw_frame, text="Min. sweepů:", font=ctk.CTkFont(size=10), text_color=COLOR_TEXT_SECONDARY).grid(row=0, column=0, padx=(0, 4), sticky="w")
        self._live_cdf_min_sweeps_entry = ctk.CTkEntry(min_sw_frame, width=50, height=24, font=ctk.CTkFont(size=10))
        self._live_cdf_min_sweeps_entry.grid(row=0, column=1, sticky="w")
        self._live_cdf_min_sweeps_entry.insert(0, "20")

    def _add_separator(self, panel, row):
        sep = ctk.CTkFrame(panel, height=2, fg_color=COLOR_ACCENT_BLUE)
        sep.grid(row=row, column=0, sticky="ew", padx=15, pady=8)

    def _build_plot_area(self, parent):
        plot_frame = ctk.CTkFrame(parent, fg_color=COLOR_BG_CARD, corner_radius=12)
        plot_frame.grid(row=0, column=1, sticky="nsew", padx=0, pady=0)
        plot_frame.grid_columnconfigure(0, weight=1)
        plot_frame.grid_rowconfigure(0, weight=3)
        plot_frame.grid_rowconfigure(2, weight=1)

        plt.style.use("dark_background")

        self._fig = Figure(figsize=(8, 5), dpi=100, facecolor=COLOR_PLOT_BG)
        self._ax = self._fig.add_subplot(111)
        self._configure_axes()

        self._line, = self._ax.plot([], [], color=COLOR_PLOT_LINE, linewidth=1.5, antialiased=True)
        self._line_min, = self._ax.plot([], [], color=COLOR_PLOT_LINE2, linewidth=0.8, alpha=0.4, linestyle="--", label="Min")
        self._line_max, = self._ax.plot([], [], color=COLOR_GREEN, linewidth=0.8, alpha=0.4, linestyle="--", label="Max")

        self._canvas = FigureCanvasTkAgg(self._fig, master=plot_frame)
        self._canvas.draw()
        self._canvas.get_tk_widget().grid(row=0, column=0, sticky="nsew", padx=8, pady=(8, 0))

        toolbar_frame = ctk.CTkFrame(plot_frame, fg_color="transparent", height=36)
        toolbar_frame.grid(row=1, column=0, sticky="ew", padx=8, pady=(0, 4))
        self._toolbar = NavigationToolbar2Tk(self._canvas, toolbar_frame)
        self._toolbar.update()

        # Live CDF mini-graf
        self._cdf_fig = Figure(figsize=(8, 2), dpi=100, facecolor=COLOR_PLOT_BG)
        self._cdf_ax = self._cdf_fig.add_subplot(111)
        self._cdf_ax.set_facecolor(COLOR_PLOT_BG)
        self._cdf_ax.text(0.5, 0.5, "Live CDF – čekám na data...",
                          transform=self._cdf_ax.transAxes, ha="center",
                          va="center", fontsize=10, color=COLOR_TEXT_SECONDARY)
        self._cdf_ax.set_xticks([])
        self._cdf_ax.set_yticks([])
        for spine in self._cdf_ax.spines.values():
            spine.set_color(COLOR_PLOT_GRID)
        self._cdf_fig.tight_layout(pad=1.0)

        self._cdf_canvas = FigureCanvasTkAgg(self._cdf_fig, master=plot_frame)
        self._cdf_canvas.draw()
        self._cdf_canvas.get_tk_widget().grid(row=2, column=0, sticky="nsew", padx=8, pady=(0, 8))

    def _configure_axes(self):
        self._ax.set_facecolor(COLOR_PLOT_BG)
        self._ax.set_xlabel("Frekvence [Hz]", color=COLOR_TEXT_PRIMARY, fontsize=11, fontfamily="Segoe UI")
        self._ax.set_ylabel("Výkon [dBµV]", color=COLOR_TEXT_PRIMARY, fontsize=11, fontfamily="Segoe UI")
        self._ax.set_title("Čekám na data…", color=COLOR_ACCENT_CYAN, fontsize=13, fontweight="bold", fontfamily="Segoe UI", pad=10)
        self._ax.tick_params(colors=COLOR_TEXT_SECONDARY, labelsize=9)
        self._ax.grid(True, color=COLOR_PLOT_GRID, alpha=0.5, linewidth=0.5)
        for spine in self._ax.spines.values():
            spine.set_color(COLOR_PLOT_GRID)
        self._fig.tight_layout(pad=1.5)

    def _build_statusbar(self):
        statusbar = ctk.CTkFrame(self, height=30, corner_radius=0, fg_color=COLOR_ACCENT_BLUE)
        statusbar.grid(row=2, column=0, sticky="ew")
        statusbar.grid_columnconfigure(1, weight=1)

        self._status_label = ctk.CTkLabel(statusbar, text="  Připraveno", font=ctk.CTkFont(size=11), text_color=COLOR_TEXT_PRIMARY)
        self._status_label.grid(row=0, column=0, padx=10, pady=3, sticky="w")

        self._clock_label = ctk.CTkLabel(statusbar, text="", font=ctk.CTkFont(size=11), text_color=COLOR_TEXT_SECONDARY)
        self._clock_label.grid(row=0, column=2, padx=10, pady=3, sticky="e")
        self._update_clock()

    # =====================================================================
    # HELPERS
    # =====================================================================

    def _build_section_label(self, parent, text, row):
        label = ctk.CTkLabel(parent, text=text, font=ctk.CTkFont(size=14, weight="bold"), text_color=COLOR_TEXT_PRIMARY)
        label.grid(row=row, column=0, padx=15, pady=(10, 0), sticky="w")

    def _set_status(self, text: str, color: str = COLOR_TEXT_PRIMARY):
        self._status_label.configure(text=f"  {text}", text_color=color)

    def _update_clock(self):
        now = datetime.now().strftime("%H:%M:%S")
        self._clock_label.configure(text=now)
        self.after(1000, self._update_clock)

    def _get_interval_seconds(self) -> float:
        val = self._interval_var.get()
        if val == "Bez pauzy": return 0.0
        return float(val.replace(" s", ""))

    def _get_sweep_limit(self) -> int:
        if self._unlimited_var.get(): return 0
        try:
            val = int(self._sweep_limit_entry.get().strip())
            return max(val, 1)
        except:
            return 0

    def _toggle_sweep_limit(self):
        if not self._unlimited_var.get():
            self._sweep_limit_entry.focus()

    def _on_freq_mode_change(self, value):
        """Přepíná zobrazení Start/Stop vs Center/Span polí."""
        if value == "Start/Stop":
            self._centerspan_frame.grid_forget()
            self._startstop_frame.grid(row=self._freq_row, column=0, padx=15, pady=(5, 0), sticky="ew")
        else:
            self._startstop_frame.grid_forget()
            self._centerspan_frame.grid(row=self._freq_row, column=0, padx=15, pady=(5, 0), sticky="ew")

    # =====================================================================
    # CONNECTION
    # =====================================================================

    def _toggle_connection(self):
        if (self._driver_fsp and self._driver_fsp.is_connected) or (self._driver_smf and getattr(self._driver_smf, "smf_is_connected", False) or getattr(self._driver_smf, "is_connected", False)):
            self._disconnect()
        else:
            self._do_connect()

    def _do_connect(self):
        fsp_visa = self._fsp_visa_entry.get().strip() or DEFAULT_FSP_VISA
        smf_visa = self._smf_visa_entry.get().strip() or DEFAULT_SMF_VISA
        use_sim = self._sim_var.get()

        try:
            if use_sim:
                sim = SASimulator()
                self._driver_fsp = sim
                self._driver_smf = sim
                fsp_idn = self._driver_fsp.connect(fsp_visa)
                smf_idn = self._driver_smf.smf_connect(smf_visa)
            else:
                self._driver_fsp = FSPDriver()
                fsp_idn = self._driver_fsp.connect(fsp_visa)
                
                self._driver_smf = SMF100ADriver()
                smf_idn = self._driver_smf.connect(smf_visa)

            sim_tag = " [SIMULACE]" if use_sim else ""
            self._use_simulator = use_sim

            self._conn_info.configure(
                text=f"FSP: {fsp_idn}\nSMF: {smf_idn}",
                text_color=COLOR_GREEN,
            )
            self._connect_btn.configure(text="Odpojit", fg_color=COLOR_RED, hover_color="#d50000")
            self._start_btn.configure(state="normal")
            
            self._smf_apply_btn.configure(state="normal")
            self._smf_rf_btn.configure(state="normal")
            
            self._fsp_visa_entry.configure(state="disabled")
            self._smf_visa_entry.configure(state="disabled")
            self._sim_check.configure(state="disabled")
            
            self._set_status(f"Připojeno{sim_tag}", COLOR_GREEN)
            
            # Bezpečnostní pojistka: Ihned po připojení vnutíme generátoru 
            # bezpečné hodnoty z GUI (např. -30 dBm), aby nedošlo k odpálení
            # vybavení, pokud byl generátor z minula nastaven na vysoký výkon.
            if self._driver_smf:
                self._apply_smf_settings()
            
            # Přečteme aktuální stav SMF a updatujeme UI
            self._read_smf_state()

        except Exception as e:
            self._conn_info.configure(text=f"❌ {e}", text_color=COLOR_RED)
            self._set_status("Chyba připojení", COLOR_RED)
            self._disconnect()

    def _disconnect(self):
        if self._is_recording:
            self._stop_recording()

        if self._driver_smf:
            if hasattr(self._driver_smf, "smf_disconnect"):
                self._driver_smf.smf_disconnect()
            else:
                self._driver_smf.disconnect()
            self._driver_smf = None
            
        if self._driver_fsp:
            self._driver_fsp.disconnect()
            self._driver_fsp = None

        self._conn_info.configure(text="Nepřipojeno", text_color=COLOR_TEXT_SECONDARY)
        self._connect_btn.configure(text="Připojit", fg_color=COLOR_ACCENT_CYAN, hover_color="#00b8d4")
        self._start_btn.configure(state="disabled")
        
        self._smf_apply_btn.configure(state="disabled")
        self._smf_rf_btn.configure(state="disabled")
        self._smf_rf_btn.configure(text="RF Výstup: VYP", fg_color=COLOR_ACCENT_BLUE)
        
        self._fsp_visa_entry.configure(state="normal")
        self._smf_visa_entry.configure(state="normal")
        self._sim_check.configure(state="normal")
        self._set_status("Odpojeno", COLOR_TEXT_SECONDARY)

    # =====================================================================
    # SMF CONTROL
    # =====================================================================
    
    def _read_smf_state(self):
        if not self._driver_smf: return
        try:
            freq_hz = self._driver_smf.get_frequency()
            pow_dbm = self._driver_smf.get_power()
            state = self._driver_smf.get_output_state()
            
            self._smf_freq_entry.delete(0, "end")
            self._smf_freq_entry.insert(0, str(freq_hz / 1e9))
            
            self._smf_pow_entry.delete(0, "end")
            self._smf_pow_entry.insert(0, str(pow_dbm))
            
            self._update_smf_rf_btn(state)
        except Exception as e:
            self._set_status(f"Nelze přečíst SMF stav: {e}", COLOR_ORANGE)

    def _apply_smf_settings(self):
        if not self._driver_smf: return
        try:
            freq_ghz = float(self._smf_freq_entry.get().strip())
            pow_dbm = float(self._smf_pow_entry.get().strip())
            self._driver_smf.set_frequency(freq_ghz * 1e9)
            self._driver_smf.set_power(pow_dbm)
            self._set_status(f"SMF nastaveno na {freq_ghz} GHz, {pow_dbm} dBm", COLOR_GREEN)
        except Exception as e:
            self._set_status(f"Chyba nastavení SMF: {e}", COLOR_RED)

    def _toggle_smf_rf(self):
        if not self._driver_smf: return
        try:
            current = self._driver_smf.get_output_state()
            new_state = not current
            self._driver_smf.set_output(new_state)
            self._update_smf_rf_btn(new_state)
            self._set_status(f"SMF RF Výstup: {'ZAPNUTO' if new_state else 'VYPNUTO'}", COLOR_GREEN if new_state else COLOR_ORANGE)
        except Exception as e:
            self._set_status(f"Chyba při přepínání RF: {e}", COLOR_RED)

    def _update_smf_rf_btn(self, state: bool):
        if state:
            self._smf_rf_btn.configure(text="RF Výstup: ZAP", fg_color=COLOR_GREEN, hover_color="#00c853")
        else:
            self._smf_rf_btn.configure(text="RF Výstup: VYP", fg_color=COLOR_ACCENT_BLUE, hover_color="#1a4a8a")


    # =====================================================================
    # RECORDING
    # =====================================================================

    def _toggle_recording(self):
        if self._is_recording:
            self._stop_recording()
        else:
            self._start_recording()

    def _start_recording(self):
        if not self._driver_fsp: return

        ref_lvl = self._ref_var.get()
        rbw = self._rbw_var.get()
        vbw = self._vbw_var.get()
        det = self._det_var.get()
        unit = self._unit_var.get()
        freq_mode = self._freq_mode_var.get()
        self._sweep_limit = self._get_sweep_limit()
        self._current_unit = unit

        try:
            # Parsování frekvencí podle zvoleného režimu
            if freq_mode == "Center/Span":
                center_ghz = float(self._fsp_center_entry.get().strip())
                span_ghz = float(self._fsp_span_entry.get().strip())
            else:
                f_start_ghz = float(self._fsp_start_entry.get().strip())
                f_stop_ghz = float(self._fsp_stop_entry.get().strip())
        except ValueError:
            self._set_status("Neplatná frekvence!", COLOR_RED)
            return

        try:
            self._driver_fsp.configure_measurement(ref_level=ref_lvl, rbw=rbw, vbw=vbw, detector=det, unit=unit)

            if freq_mode == "Center/Span":
                self._driver_fsp.set_center_span(center_ghz * 1e9, span_ghz * 1e9)
            else:
                self._driver_fsp.set_frequency_range(f_start_ghz * 1e9, f_stop_ghz * 1e9)

            self._freq_axis = self._driver_fsp.get_frequency_axis()

            self._sweep_count = 0
            self._history.clear()
            self._data_queue = queue.Queue()
            self._stop_event.clear()

            self._ax.set_xlim(self._freq_axis[0], self._freq_axis[-1])
            self._ax.set_ylabel(f"Výkon [{unit}]", color=COLOR_TEXT_PRIMARY, fontsize=11, fontfamily="Segoe UI")

            self._csv_filename = f"sa_data_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
            self._csv_file = open(self._csv_filename, "w", newline="", encoding="utf-8")
            self._csv_writer = csv.writer(self._csv_file)
            freq_headers = [f"{f:.0f}" for f in self._freq_axis]
            self._csv_writer.writerow(["Timestamp", "Sweep_Nr"] + freq_headers)

            self._is_recording = True
            self._start_btn.configure(text="⏹  ZASTAVIT SNÍMÁNÍ", fg_color=COLOR_RED, hover_color="#d50000")
            
            self._ref_menu.configure(state="disabled")
            self._rbw_menu.configure(state="disabled")
            self._vbw_menu.configure(state="disabled")
            self._det_menu.configure(state="disabled")
            self._interval_menu.configure(state="disabled")
            self._sweep_limit_entry.configure(state="disabled")
            self._unlimited_check.configure(state="disabled")
            self._connect_btn.configure(state="disabled")

            limit_info = f" (limit: {self._sweep_limit})" if self._sweep_limit > 0 else " (bez limitu)"
            self._set_status(f"Snímání Spectrum ({ref_lvl}){limit_info} – {self._csv_filename}", COLOR_GREEN)
            self._sweep_progress.set(0)

            self._worker_thread = threading.Thread(target=self._worker_loop, daemon=True)
            self._worker_thread.start()

        except Exception as e:
            self._set_status(f"Chyba při startu: {e}", COLOR_RED)

    def _stop_recording(self, auto_stopped: bool = False, is_error: bool = False):
        self._stop_event.set()
        self._is_recording = False

        if self._worker_thread and self._worker_thread.is_alive():
            self._worker_thread.join(timeout=5.0)

        if self._csv_file:
            self._csv_file.close()
            self._csv_file = None
            self._csv_writer = None

        self._start_btn.configure(text="▶  SPUSTIT SNÍMÁNÍ", fg_color=COLOR_GREEN, hover_color="#00c853")
        self._ref_menu.configure(state="normal")
        self._rbw_menu.configure(state="normal")
        self._vbw_menu.configure(state="normal")
        self._det_menu.configure(state="normal")
        self._interval_menu.configure(state="normal")
        self._connect_btn.configure(state="normal")

        self._sweep_limit_entry.configure(state="normal")
        self._unlimited_check.configure(state="normal")

        if self._sweep_count > 0:
            self._export_btn.configure(state="normal")

        if auto_stopped:
            self._set_status(f"✅ Dokončeno! {self._sweep_count}/{self._sweep_limit} sweepů. Data: {self._csv_filename}", COLOR_GREEN)
        elif not is_error:
            self._set_status(f"Zastaveno po {self._sweep_count} sweepech. Data uložena: {self._csv_filename}", COLOR_ORANGE)

    def _worker_loop(self):
        interval = self._get_interval_seconds()
        sweep_limit = self._sweep_limit

        while not self._stop_event.is_set():
            try:
                data = self._driver_fsp.single_sweep()
                self._sweep_count += 1
                timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]

                if self._csv_writer:
                    row = [timestamp, self._sweep_count] + [f"{v:.6f}" for v in data]
                    self._csv_writer.writerow(row)
                    if self._csv_file:
                        self._csv_file.flush()

                self._data_queue.put((self._sweep_count, data))

                if sweep_limit > 0 and self._sweep_count >= sweep_limit:
                    self._data_queue.put(("AUTO_STOP", None))
                    break

                if interval > 0 and not self._stop_event.is_set():
                    self._stop_event.wait(timeout=interval)

            except Exception as e:
                self._data_queue.put(("ERROR", str(e)))
                break

    # =====================================================================
    # PLOT UPDATE
    # =====================================================================

    def _schedule_plot_update(self):
        updated = False
        auto_stop = False
        
        while not self._data_queue.empty():
            try:
                item = self._data_queue.get_nowait()
                if item[0] == "ERROR":
                    self._stop_recording(is_error=True)
                    self._set_status(f"Chyba měření: {item[1]}", COLOR_RED)
                    print(f"ERROR: {item[1]}") # Log do konzole pro jistotu
                    break
                if item[0] == "AUTO_STOP":
                    auto_stop = True
                    break

                sw_idx, data = item
                self._history.append(data)
                self._sweep_label.configure(text=f"Sweepů: {sw_idx}")

                if self._sweep_limit > 0:
                    prog = min(1.0, sw_idx / self._sweep_limit)
                    self._sweep_progress.set(prog)

                updated = True

            except queue.Empty:
                break

        if updated and len(self._history) > 0:
            hist_arr = np.array(self._history)
            last_data = hist_arr[-1]
            min_data = np.min(hist_arr, axis=0)
            max_data = np.max(hist_arr, axis=0)

            self._line.set_data(self._freq_axis, last_data)
            self._line_min.set_data(self._freq_axis, min_data)
            self._line_max.set_data(self._freq_axis, max_data)

            self._ax.set_ylim(min_data.min() - 10, max_data.max() + 10)
            unit_label = getattr(self, '_current_unit', 'dBµV')
            self._ax.set_title(f"Sweep {self._sweep_count} | Výkon: {np.mean(last_data):.2f} {unit_label} avg")

            self._canvas.draw_idle()
            self._update_live_cdf()

        if auto_stop:
            self._stop_recording(auto_stopped=True)

        self.after(200, self._schedule_plot_update)

    def _update_live_cdf(self):
        if len(self._history) == 0: return

        mode_label = self._live_cdf_mode_var.get()
        mode_key = ANALYSIS_MODES.get(mode_label, "single_freq")

        try:
            min_sw = int(self._live_cdf_min_sweeps_entry.get().strip())
        except:
            min_sw = 10

        if len(self._history) < min_sw:
            self._cdf_ax.clear()
            self._cdf_ax.set_facecolor(COLOR_PLOT_BG)
            self._cdf_ax.text(0.5, 0.5, f"Live CDF – čekám na data ({len(self._history)}/{min_sw})...",
                              transform=self._cdf_ax.transAxes, ha="center", va="center",
                              fontsize=10, color=COLOR_TEXT_SECONDARY)
            self._cdf_ax.set_xticks([])
            self._cdf_ax.set_yticks([])
            for spine in self._cdf_ax.spines.values():
                spine.set_color(COLOR_PLOT_GRID)
            self._cdf_canvas.draw_idle()
            return

        try:
            freq_value_hz = float(self._live_cdf_freq_entry.get().strip()) * 1e9
            band_start_hz = freq_value_hz
            band_stop_hz = float(self._live_cdf_freq_end_entry.get().strip()) * 1e9
        except:
            return

        data_2d = np.array(self._history)

        try:
            cdf_vals = extract_series_for_mode(
                data_matrix=data_2d,
                freqs=self._freq_axis,
                mode=mode_key,
                freq_value_hz=freq_value_hz,
                band_start_hz=band_start_hz,
                band_stop_hz=band_stop_hz
            )
            plot_cdf_mini(self._cdf_fig, cdf_vals, mode_label)
            self._cdf_canvas.draw_idle()
        except Exception as e:
            pass

    def _export_csv(self):
        if not self._history: return
        import tkinter.filedialog as fd
        default_name = f"export_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
        path = fd.asksaveasfilename(defaultextension=".csv", filetypes=[("CSV", "*.csv")], initialfile=default_name)
        if not path: return

        try:
            with open(path, "w", newline="", encoding="utf-8") as f:
                writer = csv.writer(f)
                headers = ["Sweep_Nr"] + [f"{f:.0f}" for f in self._freq_axis]
                writer.writerow(headers)
                for i, row in enumerate(self._history):
                    writer.writerow([i+1] + [f"{v:.6f}" for v in row])
            self._set_status(f"Exportováno: {path}", COLOR_GREEN)
        except Exception as e:
            self._set_status(f"Chyba exportu: {e}", COLOR_RED)

    def _on_close(self):
        if self._is_recording:
            self._stop_recording()
        if self._driver_smf:
            if hasattr(self._driver_smf, "smf_disconnect"):
                self._driver_smf.smf_disconnect()
            else:
                self._driver_smf.disconnect()
        if self._driver_fsp:
            self._driver_fsp.disconnect()
        self.destroy()
        sys.exit(0)


if __name__ == "__main__":
    app = SAApp()
    app.mainloop()
