"""
Spectrum Analyzer CSV Analyzer - GUI aplikace pro zpracovani a vizualizaci SA dat.

Nacte CSV exportovany z SA Data Recorderu a zobrazi:
  1. Vsechny sweepy prekryte
  2. Heatmapu (frekvence x cas)
  3. Statistiku s detekci maxim (peaks)
  4. Analyzu stability mereni
  5. CDF / Gumbel statistickou analyzu

Spusteni:
    python sa_analyzer_app.py
"""

import os
import sys
import io
import numpy as np
import customtkinter as ctk
import matplotlib
matplotlib.use("TkAgg")
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk
from matplotlib.figure import Figure
from matplotlib.gridspec import GridSpec
from matplotlib.ticker import FuncFormatter
from tkinter import filedialog

try:
    from scipy.signal import find_peaks
    SCIPY_AVAILABLE = True
except ImportError:
    SCIPY_AVAILABLE = False

# Import CDF/Gumbel vypocetniho modulu
from cdf_gumbel import (
    ANALYSIS_MODES,
    extract_series_for_mode,
    compute_empirical_cdf,
    fit_gumbel,
    compute_statistics,
    format_statistics_text,
    plot_cdf_and_gumbel,
    export_cdf_results,
)

# ---------------------------------------------------------------------------
# Konstanty
# ---------------------------------------------------------------------------
APP_TITLE = "SA CSV Analyzer"
APP_VERSION = "1.1"
WINDOW_SIZE = "1400x900"

# Barvy (dark theme)
COLOR_BG_DARK       = "#1a1a2e"
COLOR_BG_CARD       = "#16213e"
COLOR_ACCENT_BLUE   = "#0f3460"
COLOR_ACCENT_CYAN   = "#00d2ff"
COLOR_GREEN         = "#00e676"
COLOR_RED           = "#ff1744"
COLOR_ORANGE        = "#ff9100"
COLOR_TEXT_PRIMARY   = "#e0e0e0"
COLOR_TEXT_SECONDARY = "#9e9e9e"
COLOR_PLOT_BG       = "#0d1117"
COLOR_PLOT_GRID     = "#21262d"
COLOR_PLOT_LINE     = "#58a6ff"

# ---------------------------------------------------------------------------
# Pomocne funkce
# ---------------------------------------------------------------------------

def freq_formatter(x, _):
    """Formatuje frekvenci do citelne podoby."""
    if x >= 1e9:
        return f"{x / 1e9:.2f} GHz"
    elif x >= 1e6:
        return f"{x / 1e6:.0f} MHz"
    else:
        return f"{x / 1e3:.0f} kHz"

def load_sa_csv(filepath: str) -> tuple:
    """Nacte SA export CSV. Vraci: (freqs, data, sweep_numbers)"""
    with open(filepath, "r", encoding="utf-8") as f:
        header_line = f.readline().strip()

    headers = header_line.split(",")

    if headers[0].lower() in ("sweep_nr", "sweep nr"):
        freq_start_col = 1
    elif headers[1].lower() in ("sweep_nr", "sweep nr"):
        freq_start_col = 2
    else:
        freq_start_col = 1  # fallback

    freqs = np.array([float(h) for h in headers[freq_start_col:]])
    raw_data = np.loadtxt(filepath, delimiter=",", skiprows=1, usecols=range(freq_start_col, freq_start_col + len(freqs)))

    if raw_data.ndim == 1:
        raw_data = raw_data.reshape(1, -1)

    sweep_col_data = np.loadtxt(filepath, delimiter=",", skiprows=1, usecols=(freq_start_col - 1,))
    if sweep_col_data.ndim == 0:
        sweep_numbers = np.array([int(sweep_col_data)])
    else:
        sweep_numbers = sweep_col_data.astype(int)

    return freqs, raw_data, sweep_numbers

def find_max_peaks(freqs, trace, prominence=5.0, min_height=-100.0):
    """Najde maximalni frekvence (peaks) pro spektralni analyzator."""
    if not SCIPY_AVAILABLE:
        return []

    # Pro SA hledame maxima, takze trace je kladny (jako takovy), find_peaks bere signaly nad height.
    peaks, _ = find_peaks(trace, prominence=prominence, height=min_height)

    resonances = []
    for idx in peaks:
        resonances.append({
            "freq_hz": freqs[idx],
            "freq_ghz": freqs[idx] / 1e9,
            "value_dbm": trace[idx],
            "index": idx,
        })

    # Seradime podle sily signalu sestupne
    resonances.sort(key=lambda r: r["value_dbm"], reverse=True)
    return resonances

# ---------------------------------------------------------------------------
# Hlavni aplikace
# ---------------------------------------------------------------------------

class SAAnalyzerApp(ctk.CTk):
    """GUI aplikace pro analyzu SA CSV dat."""

    def __init__(self):
        super().__init__()

        self.title(f"{APP_TITLE}  v{APP_VERSION}")
        self.geometry(WINDOW_SIZE)
        self.minsize(1100, 700)

        ctk.set_appearance_mode("dark")
        ctk.set_default_color_theme("blue")

        self._freqs = None
        self._data = None
        self._sweep_numbers = None
        self._filepath = None
        self._resonances = []

        self._cdf_stats = None
        self._cdf_values = None

        self._build_ui()
        self.protocol("WM_DELETE_WINDOW", self._on_close)

    def _build_ui(self):
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(1, weight=1)

        self._build_header()

        main_frame = ctk.CTkFrame(self, fg_color="transparent")
        main_frame.grid(row=1, column=0, sticky="nsew", padx=10, pady=(0, 5))
        main_frame.grid_columnconfigure(1, weight=1)
        main_frame.grid_rowconfigure(0, weight=1)

        self._build_left_panel(main_frame)
        self._build_tabbed_plot_area(main_frame)
        self._build_statusbar()

    def _build_header(self):
        header = ctk.CTkFrame(self, height=56, corner_radius=0, fg_color=COLOR_ACCENT_BLUE)
        header.grid(row=0, column=0, sticky="ew")
        header.grid_columnconfigure(1, weight=1)

        title = ctk.CTkLabel(
            header, text="  📻  SA CSV Analyzer",
            font=ctk.CTkFont(family="Segoe UI", size=20, weight="bold"),
            text_color="#ffffff",
        )
        title.grid(row=0, column=0, padx=15, pady=10, sticky="w")

        ver = ctk.CTkLabel(
            header, text=f"v{APP_VERSION}", font=ctk.CTkFont(size=12), text_color=COLOR_TEXT_SECONDARY,
        )
        ver.grid(row=0, column=2, padx=15, pady=10, sticky="e")

    def _build_left_panel(self, parent):
        panel = ctk.CTkFrame(parent, width=300, fg_color=COLOR_BG_CARD, corner_radius=12)
        panel.grid(row=0, column=0, sticky="ns", padx=(0, 8))
        panel.grid_propagate(False)

        self._section_label(panel, "Nacist CSV soubor", 0)

        self._load_btn = ctk.CTkButton(
            panel, text="Vybrat CSV soubor...", width=260, height=40,
            font=ctk.CTkFont(size=14, weight="bold"),
            fg_color=COLOR_ACCENT_CYAN, text_color="#000000", hover_color="#00b8d4",
            command=self._load_file,
        )
        self._load_btn.grid(row=1, column=0, padx=15, pady=(8, 5), sticky="w")

        self._file_label = ctk.CTkLabel(panel, text="Zadny soubor", font=ctk.CTkFont(size=11), text_color=COLOR_TEXT_SECONDARY, wraplength=250, justify="left")
        self._file_label.grid(row=2, column=0, padx=15, pady=(0, 5), sticky="w")

        sep = ctk.CTkFrame(panel, height=2, fg_color=COLOR_ACCENT_BLUE)
        sep.grid(row=3, column=0, sticky="ew", padx=15, pady=8)

        self._section_label(panel, "Informace o datech", 4)

        self._info_text = ctk.CTkTextbox(
            panel, width=260, height=160, font=ctk.CTkFont(family="Consolas", size=11),
            fg_color="#0d1117", text_color=COLOR_TEXT_PRIMARY, corner_radius=8,
        )
        self._info_text.grid(row=5, column=0, padx=15, pady=(5, 5), sticky="w")
        self._info_text.insert("1.0", "Nacti CSV soubor pro zobrazeni info...")
        self._info_text.configure(state="disabled")

        sep2 = ctk.CTkFrame(panel, height=2, fg_color=COLOR_ACCENT_BLUE)
        sep2.grid(row=6, column=0, sticky="ew", padx=15, pady=8)

        self._section_label(panel, "Hlavní píky (Peaks)", 7)

        self._res_text = ctk.CTkTextbox(
            panel, width=260, height=200, font=ctk.CTkFont(family="Consolas", size=11),
            fg_color="#0d1117", text_color=COLOR_ACCENT_CYAN, corner_radius=8,
        )
        self._res_text.grid(row=8, column=0, padx=15, pady=(5, 5), sticky="w")
        self._res_text.insert("1.0", "Píky se zobrazi po nacteni dat...")
        self._res_text.configure(state="disabled")

        sep3 = ctk.CTkFrame(panel, height=2, fg_color=COLOR_ACCENT_BLUE)
        sep3.grid(row=9, column=0, sticky="ew", padx=15, pady=8)

        self._export_btn = ctk.CTkButton(
            panel, text="Ulozit graf jako PNG", width=260, height=36,
            font=ctk.CTkFont(size=12, weight="bold"),
            fg_color=COLOR_ACCENT_BLUE, hover_color="#1a4a8a",
            command=self._export_png, state="disabled",
        )
        self._export_btn.grid(row=10, column=0, padx=15, pady=(5, 10), sticky="w")

    def _build_tabbed_plot_area(self, parent):
        plot_container = ctk.CTkFrame(parent, fg_color=COLOR_BG_CARD, corner_radius=12)
        plot_container.grid(row=0, column=1, sticky="nsew")
        plot_container.grid_columnconfigure(0, weight=1)
        plot_container.grid_rowconfigure(0, weight=1)

        self._tabview = ctk.CTkTabview(
            plot_container, fg_color=COLOR_BG_CARD,
            segmented_button_fg_color=COLOR_ACCENT_BLUE,
            segmented_button_selected_color=COLOR_ACCENT_CYAN,
            segmented_button_selected_hover_color="#00b8d4",
            segmented_button_unselected_color=COLOR_ACCENT_BLUE,
            segmented_button_unselected_hover_color="#1a4a8a",
            text_color="#000000", text_color_disabled=COLOR_TEXT_SECONDARY,
            corner_radius=10,
        )
        self._tabview.grid(row=0, column=0, sticky="nsew", padx=4, pady=4)

        tab_analysis = self._tabview.add("Analýza")
        self._build_analysis_tab(tab_analysis)

        tab_cdf = self._tabview.add("CDF / Gumbel")
        self._build_cdf_tab(tab_cdf)

    def _build_analysis_tab(self, tab):
        tab.grid_columnconfigure(0, weight=1)
        tab.grid_rowconfigure(0, weight=1)

        plt.style.use("dark_background")

        self._fig = Figure(figsize=(12, 8), dpi=100, facecolor=COLOR_PLOT_BG)
        self._show_welcome()

        self._canvas = FigureCanvasTkAgg(self._fig, master=tab)
        self._canvas.draw()
        canvas_widget = self._canvas.get_tk_widget()
        canvas_widget.grid(row=0, column=0, sticky="nsew", padx=4, pady=(4, 0))

        toolbar_frame = ctk.CTkFrame(tab, fg_color="transparent", height=36)
        toolbar_frame.grid(row=1, column=0, sticky="ew", padx=4, pady=(0, 4))
        self._toolbar = NavigationToolbar2Tk(self._canvas, toolbar_frame)
        self._toolbar.update()

    def _build_cdf_tab(self, tab):
        tab.grid_columnconfigure(1, weight=1)
        tab.grid_rowconfigure(0, weight=1)

        ctrl_panel = ctk.CTkFrame(tab, width=260, fg_color=COLOR_BG_DARK, corner_radius=10)
        ctrl_panel.grid(row=0, column=0, sticky="ns", padx=(4, 6), pady=4)
        ctrl_panel.grid_propagate(False)

        row = 0
        self._section_label(ctrl_panel, "Nastaveni CDF", row); row += 1

        ctk.CTkLabel(ctrl_panel, text="Rezim analyzy:", font=ctk.CTkFont(size=11), text_color=COLOR_TEXT_SECONDARY).grid(row=row, column=0, padx=12, pady=(8, 0), sticky="w"); row += 1

        mode_keys = list(ANALYSIS_MODES.keys())
        self._cdf_mode_var = ctk.StringVar(value=mode_keys[0])
        self._cdf_mode_menu = ctk.CTkOptionMenu(
            ctrl_panel, values=mode_keys, variable=self._cdf_mode_var, width=230, height=30,
            fg_color=COLOR_ACCENT_BLUE, button_color=COLOR_ACCENT_CYAN, button_hover_color="#00b8d4",
            command=self._on_cdf_mode_change,
        )
        self._cdf_mode_menu.grid(row=row, column=0, padx=12, pady=(2, 5), sticky="w"); row += 1

        ctk.CTkLabel(ctrl_panel, text="Frekvence [GHz]:", font=ctk.CTkFont(size=11), text_color=COLOR_TEXT_SECONDARY).grid(row=row, column=0, padx=12, pady=(5, 0), sticky="w"); row += 1
        self._cdf_freq_entry = ctk.CTkEntry(ctrl_panel, width=230, height=28, placeholder_text="1.0")
        self._cdf_freq_entry.grid(row=row, column=0, padx=12, pady=(2, 5), sticky="w"); row += 1
        self._cdf_freq_entry.insert(0, "1.0")

        ctk.CTkLabel(ctrl_panel, text="Pasmo - start [GHz]:", font=ctk.CTkFont(size=11), text_color=COLOR_TEXT_SECONDARY).grid(row=row, column=0, padx=12, pady=(5, 0), sticky="w"); row += 1
        self._cdf_band_start_entry = ctk.CTkEntry(ctrl_panel, width=230, height=28, placeholder_text="1.0")
        self._cdf_band_start_entry.grid(row=row, column=0, padx=12, pady=(2, 5), sticky="w"); row += 1
        self._cdf_band_start_entry.insert(0, "1.0")
        self._cdf_band_start_entry.configure(state="disabled")

        ctk.CTkLabel(ctrl_panel, text="Pasmo - stop [GHz]:", font=ctk.CTkFont(size=11), text_color=COLOR_TEXT_SECONDARY).grid(row=row, column=0, padx=12, pady=(5, 0), sticky="w"); row += 1
        self._cdf_band_stop_entry = ctk.CTkEntry(ctrl_panel, width=230, height=28, placeholder_text="2.0")
        self._cdf_band_stop_entry.grid(row=row, column=0, padx=12, pady=(2, 5), sticky="w"); row += 1
        self._cdf_band_stop_entry.insert(0, "2.0")
        self._cdf_band_stop_entry.configure(state="disabled")

        ctk.CTkLabel(ctrl_panel, text="Min. sweepu pro fit:", font=ctk.CTkFont(size=11), text_color=COLOR_TEXT_SECONDARY).grid(row=row, column=0, padx=12, pady=(5, 0), sticky="w"); row += 1
        self._cdf_min_sweeps_entry = ctk.CTkEntry(ctrl_panel, width=230, height=28, placeholder_text="20")
        self._cdf_min_sweeps_entry.grid(row=row, column=0, padx=12, pady=(2, 8), sticky="w"); row += 1
        self._cdf_min_sweeps_entry.insert(0, "20")

        sep = ctk.CTkFrame(ctrl_panel, height=2, fg_color=COLOR_ACCENT_BLUE)
        sep.grid(row=row, column=0, sticky="ew", padx=12, pady=6); row += 1

        self._cdf_compute_btn = ctk.CTkButton(
            ctrl_panel, text="Spocitat", width=230, height=40, font=ctk.CTkFont(size=13, weight="bold"),
            fg_color=COLOR_ACCENT_CYAN, text_color="#000000", hover_color="#00b8d4",
            command=self._compute_cdf_gumbel, state="disabled",
        )
        self._cdf_compute_btn.grid(row=row, column=0, padx=12, pady=(5, 5), sticky="w"); row += 1

        sep2 = ctk.CTkFrame(ctrl_panel, height=2, fg_color=COLOR_ACCENT_BLUE)
        sep2.grid(row=row, column=0, sticky="ew", padx=12, pady=6); row += 1

        self._cdf_export_png_btn = ctk.CTkButton(
            ctrl_panel, text="Export PNG", width=230, height=32, font=ctk.CTkFont(size=11, weight="bold"),
            fg_color=COLOR_ACCENT_BLUE, hover_color="#1a4a8a", command=self._export_cdf_png, state="disabled",
        )
        self._cdf_export_png_btn.grid(row=row, column=0, padx=12, pady=(5, 3), sticky="w"); row += 1

        self._cdf_export_csv_btn = ctk.CTkButton(
            ctrl_panel, text="Export CSV", width=230, height=32, font=ctk.CTkFont(size=11, weight="bold"),
            fg_color=COLOR_ACCENT_BLUE, hover_color="#1a4a8a", command=lambda: self._export_cdf_data("csv"), state="disabled",
        )
        self._cdf_export_csv_btn.grid(row=row, column=0, padx=12, pady=(0, 3), sticky="w"); row += 1

        self._cdf_export_xlsx_btn = ctk.CTkButton(
            ctrl_panel, text="Export XLSX", width=230, height=32, font=ctk.CTkFont(size=11, weight="bold"),
            fg_color=COLOR_ACCENT_BLUE, hover_color="#1a4a8a", command=lambda: self._export_cdf_data("xlsx"), state="disabled",
        )
        self._cdf_export_xlsx_btn.grid(row=row, column=0, padx=12, pady=(0, 5), sticky="w"); row += 1

        right_frame = ctk.CTkFrame(tab, fg_color="transparent")
        right_frame.grid(row=0, column=1, sticky="nsew", padx=(0, 4), pady=4)
        right_frame.grid_columnconfigure(0, weight=1)
        right_frame.grid_rowconfigure(0, weight=3)
        right_frame.grid_rowconfigure(1, weight=0)
        right_frame.grid_rowconfigure(2, weight=1)

        self._cdf_fig = Figure(figsize=(10, 6), dpi=100, facecolor=COLOR_PLOT_BG)
        self._show_cdf_welcome()

        self._cdf_canvas = FigureCanvasTkAgg(self._cdf_fig, master=right_frame)
        self._cdf_canvas.draw()
        self._cdf_canvas.get_tk_widget().grid(row=0, column=0, sticky="nsew", padx=0, pady=(0, 0))

        cdf_toolbar_frame = ctk.CTkFrame(right_frame, fg_color="transparent", height=36)
        cdf_toolbar_frame.grid(row=1, column=0, sticky="ew", padx=0, pady=(0, 2))
        self._cdf_toolbar = NavigationToolbar2Tk(self._cdf_canvas, cdf_toolbar_frame)
        self._cdf_toolbar.update()

        results_frame = ctk.CTkFrame(right_frame, fg_color=COLOR_BG_DARK, corner_radius=10, height=180)
        results_frame.grid(row=2, column=0, sticky="nsew", padx=0, pady=(2, 0))
        results_frame.grid_columnconfigure(0, weight=1)
        results_frame.grid_rowconfigure(0, weight=1)

        self._cdf_results_text = ctk.CTkTextbox(
            results_frame, width=600, height=150, font=ctk.CTkFont(family="Consolas", size=11),
            fg_color="#0d1117", text_color=COLOR_TEXT_PRIMARY, corner_radius=8,
        )
        self._cdf_results_text.grid(row=0, column=0, sticky="nsew", padx=8, pady=8)
        self._cdf_results_text.insert("1.0", 'Nacti CSV a klikni "Spocitat" pro CDF / Gumbel analyzu...')
        self._cdf_results_text.configure(state="disabled")

    def _on_cdf_mode_change(self, value):
        mode_key = ANALYSIS_MODES.get(value, "single_freq")
        if mode_key == "single_freq":
            self._cdf_freq_entry.configure(state="normal")
            self._cdf_band_start_entry.configure(state="disabled")
            self._cdf_band_stop_entry.configure(state="disabled")
        else:
            self._cdf_freq_entry.configure(state="disabled")
            self._cdf_band_start_entry.configure(state="normal")
            self._cdf_band_stop_entry.configure(state="normal")

    def _show_cdf_welcome(self):
        self._cdf_fig.clear()
        ax = self._cdf_fig.add_subplot(111)
        ax.set_facecolor(COLOR_PLOT_BG)
        ax.text(0.5, 0.55, "CDF / Gumbel analyza", transform=ax.transAxes, ha="center", va="center", fontsize=24, fontweight="bold", color=COLOR_ACCENT_CYAN, fontfamily="Segoe UI")
        ax.text(0.5, 0.40, 'Nacti CSV soubor -> zvol rezim -> klikni "Spocitat"', transform=ax.transAxes, ha="center", va="center", fontsize=12, color=COLOR_TEXT_SECONDARY, fontfamily="Segoe UI")
        ax.set_xticks([])
        ax.set_yticks([])
        for spine in ax.spines.values():
            spine.set_visible(False)

    def _compute_cdf_gumbel(self):
        if self._data is None or self._freqs is None:
            self._set_status("Nejdriv nacti CSV soubor!", COLOR_RED)
            return

        try:
            mode_label = self._cdf_mode_var.get()
            mode_key = ANALYSIS_MODES[mode_label]
            min_sweeps = int(self._cdf_min_sweeps_entry.get().strip())
            freq_value_hz = None
            band_start_hz = None
            band_stop_hz = None

            if mode_key == "single_freq":
                freq_ghz = float(self._cdf_freq_entry.get().strip())
                freq_value_hz = freq_ghz * 1e9
            else:
                band_start_hz = float(self._cdf_band_start_entry.get().strip()) * 1e9
                band_stop_hz = float(self._cdf_band_stop_entry.get().strip()) * 1e9

            self._cdf_values = extract_series_for_mode(
                self._data, self._freqs, mode_key,
                freq_value_hz=freq_value_hz, band_start_hz=band_start_hz, band_stop_hz=band_stop_hz,
            )

            n = len(self._cdf_values[~np.isnan(self._cdf_values)])

            self._cdf_stats = plot_cdf_and_gumbel(
                self._cdf_fig, self._cdf_values, mode_key,
                mode_label=mode_label, min_sweeps=min_sweeps,
            )
            self._cdf_canvas.draw_idle()

            if self._cdf_stats:
                stats_text = format_statistics_text(self._cdf_stats, mode_label)
                # nahradit db za dBµV kde dává smysl:
                stats_text = stats_text.replace("dB", "dBµV")
            else:
                stats_text = "Vypocet se nezdaril - zkontroluj nastaveni."

            self._cdf_results_text.configure(state="normal")
            self._cdf_results_text.delete("1.0", "end")
            self._cdf_results_text.insert("1.0", stats_text)
            self._cdf_results_text.configure(state="disabled")

            self._cdf_export_png_btn.configure(state="normal")
            self._cdf_export_csv_btn.configure(state="normal")
            self._cdf_export_xlsx_btn.configure(state="normal")

            self._set_status(f"CDF/Gumbel: {n} vzorku, rezim {mode_label}", COLOR_GREEN)

        except ValueError as e:
            self._set_status(f"Chyba: {e}", COLOR_RED)
        except Exception as e:
            self._set_status(f"Neocekavana chyba: {e}", COLOR_RED)

    def _export_cdf_png(self):
        if self._cdf_stats is None: return
        default_name = "cdf_gumbel_analysis.png"
        if self._filepath:
            base = os.path.splitext(os.path.basename(self._filepath))[0]
            default_name = f"{base}_cdf_gumbel.png"

        filepath = filedialog.asksaveasfilename(defaultextension=".png", filetypes=[("PNG obrazek", "*.png"), ("Vsechny soubory", "*.*")], initialfile=default_name)
        if not filepath: return
        try:
            self._cdf_fig.savefig(filepath, dpi=150, facecolor=self._cdf_fig.get_facecolor())
            self._set_status(f"CDF graf ulozen: {filepath}", COLOR_GREEN)
        except Exception as e:
            self._set_status(f"Chyba exportu PNG: {e}", COLOR_RED)

    def _export_cdf_data(self, file_format: str):
        if self._cdf_stats is None or self._cdf_values is None: return
        ext = ".xlsx" if file_format == "xlsx" else ".csv"
        ftypes = [("Excel soubor", "*.xlsx"), ("Vsechny soubory", "*.*")] if file_format == "xlsx" else [("CSV soubor", "*.csv"), ("Vsechny soubory", "*.*")]

        default_name = f"cdf_gumbel_results{ext}"
        if self._filepath:
            base = os.path.splitext(os.path.basename(self._filepath))[0]
            default_name = f"{base}_cdf_gumbel{ext}"

        filepath = filedialog.asksaveasfilename(defaultextension=ext, filetypes=ftypes, initialfile=default_name)
        if not filepath: return

        try:
            export_cdf_results(self._cdf_stats, self._cdf_values, filepath, file_format=file_format)
            self._set_status(f"Vysledky exportovany: {filepath}", COLOR_GREEN)
        except Exception as e:
            self._set_status(f"Chyba exportu: {e}", COLOR_RED)

    def _build_statusbar(self):
        statusbar = ctk.CTkFrame(self, height=30, corner_radius=0, fg_color=COLOR_ACCENT_BLUE)
        statusbar.grid(row=2, column=0, sticky="ew")
        self._status_label = ctk.CTkLabel(statusbar, text="  Pripraveno - nacti CSV soubor", font=ctk.CTkFont(size=11), text_color=COLOR_TEXT_PRIMARY)
        self._status_label.grid(row=0, column=0, padx=10, pady=3, sticky="w")

    def _section_label(self, parent, text, row):
        label = ctk.CTkLabel(parent, text=text, font=ctk.CTkFont(size=14, weight="bold"), text_color=COLOR_TEXT_PRIMARY)
        label.grid(row=row, column=0, padx=15, pady=(10, 0), sticky="w")

    def _set_status(self, text, color=COLOR_TEXT_PRIMARY):
        self._status_label.configure(text=f"  {text}", text_color=color)

    def _show_welcome(self):
        self._fig.clear()
        ax = self._fig.add_subplot(111)
        ax.set_facecolor(COLOR_PLOT_BG)
        ax.text(0.5, 0.55, "SA CSV Analyzer", transform=ax.transAxes, ha="center", va="center", fontsize=28, fontweight="bold", color=COLOR_ACCENT_CYAN, fontfamily="Segoe UI")
        ax.text(0.5, 0.42, "Nacti CSV soubor pro zobrazeni analyzy", transform=ax.transAxes, ha="center", va="center", fontsize=14, color=COLOR_TEXT_SECONDARY, fontfamily="Segoe UI")
        ax.set_xticks([])
        ax.set_yticks([])
        for spine in ax.spines.values():
            spine.set_visible(False)

    def _load_file(self):
        filepath = filedialog.askopenfilename(title="Vyber SA CSV soubor", filetypes=[("CSV soubory", "*.csv"), ("Vsechny soubory", "*.*")])
        if not filepath: return
        self._set_status(f"Nacitam {os.path.basename(filepath)}...", COLOR_ORANGE)
        self.update_idletasks()

        try:
            self._freqs, self._data, self._sweep_numbers = load_sa_csv(filepath)
            self._filepath = filepath

            n_sweeps, n_points = self._data.shape

            self._info_text.configure(state="normal")
            self._info_text.delete("1.0", "end")
            info_lines = [
                f"Soubor: {os.path.basename(filepath)}", "",
                f"Sweepu:    {n_sweeps}", f"Bodu/sweep: {n_points}", "",
                f"F start: {freq_formatter(self._freqs[0], None)}",
                f"F stop:  {freq_formatter(self._freqs[-1], None)}",
                f"F krok:  {(self._freqs[1]-self._freqs[0])/1e3:.1f} kHz", "",
                f"Power min: {np.min(self._data):.2f} dBµV",
                f"Power max: {np.max(self._data):.2f} dBµV",
                f"Power avg: {np.mean(self._data):.2f} dBµV",
            ]
            self._info_text.insert("1.0", "\n".join(info_lines))
            self._info_text.configure(state="disabled")

            self._file_label.configure(text=f"{os.path.basename(filepath)}", text_color=COLOR_GREEN)

            self._create_analysis_plots()
            self._show_resonance_report()

            self._export_btn.configure(state="normal")
            self._cdf_compute_btn.configure(state="normal")

            f_start_ghz = self._freqs[0] / 1e9
            f_stop_ghz = self._freqs[-1] / 1e9
            self._cdf_band_start_entry.configure(state="normal")
            self._cdf_band_start_entry.delete(0, "end")
            self._cdf_band_start_entry.insert(0, f"{f_start_ghz:.3f}")
            self._cdf_band_start_entry.configure(state="disabled" if self._cdf_mode_var.get() == "single_freq" else "normal")

            self._cdf_band_stop_entry.configure(state="normal")
            self._cdf_band_stop_entry.delete(0, "end")
            self._cdf_band_stop_entry.insert(0, f"{f_stop_ghz:.3f}")
            self._cdf_band_stop_entry.configure(state="disabled" if self._cdf_mode_var.get() == "single_freq" else "normal")

            self._set_status(f"Nacteno: {n_sweeps} sweepu", COLOR_GREEN)
        except Exception as e:
            self._set_status(f"Chyba pri nacitani: {e}", COLOR_RED)

    def _show_resonance_report(self):
        if self._data is None or self._freqs is None: return
        mean_trace = np.mean(self._data, axis=0)
        self._resonances = find_max_peaks(self._freqs, mean_trace, prominence=3.0, min_height=-80.0)

        self._res_text.configure(state="normal")
        self._res_text.delete("1.0", "end")

        if not SCIPY_AVAILABLE:
            self._res_text.insert("1.0", "Scipy neni k dispozici.\nDetekce piku vypnuta.")
        elif not self._resonances:
            self._res_text.insert("1.0", "Nenalezeny zadne vyrazne piky.")
        else:
            lines = ["Nalezene piky (z prumeru):", ""]
            for i, r in enumerate(self._resonances[:10]):
                lines.append(f"{i+1}. {r['freq_ghz']:.3f} GHz: {r['value_dbm']:.2f} dBµV")
            if len(self._resonances) > 10:
                lines.append("...")
            self._res_text.insert("1.0", "\n".join(lines))
        self._res_text.configure(state="disabled")

    def _create_analysis_plots(self):
        self._fig.clear()
        gs = GridSpec(2, 2, figure=self._fig, wspace=0.2, hspace=0.3)

        ax_all = self._fig.add_subplot(gs[0, 0])
        ax_heat = self._fig.add_subplot(gs[0, 1])
        ax_stat = self._fig.add_subplot(gs[1, 0])
        ax_hist = self._fig.add_subplot(gs[1, 1])

        freqs_ghz = self._freqs / 1e9

        ax_all.set_facecolor(COLOR_PLOT_BG)
        n_sweeps = self._data.shape[0]
        step = max(1, n_sweeps // 50)
        for i in range(0, n_sweeps, step):
            ax_all.plot(freqs_ghz, self._data[i], color=COLOR_PLOT_LINE, alpha=0.15, linewidth=0.5)
        ax_all.set_title(f"Prekryv sweepu (vykreslen kazdy {step}.)", color=COLOR_ACCENT_CYAN, fontfamily="Segoe UI")
        ax_all.set_xlabel("Frekvence [GHz]")
        ax_all.set_ylabel("Power [dBµV]")
        ax_all.grid(True, color=COLOR_PLOT_GRID, alpha=0.5)

        vmax = np.percentile(self._data, 99)
        vmin = np.percentile(self._data, 1)
        im = ax_heat.imshow(self._data, aspect="auto", cmap="viridis", origin="upper",
                            extent=[freqs_ghz[0], freqs_ghz[-1], self._sweep_numbers[-1], self._sweep_numbers[0]],
                            vmin=vmin, vmax=vmax)
        ax_heat.set_title("Heatmapa: Power v case", color=COLOR_ACCENT_CYAN, fontfamily="Segoe UI")
        ax_heat.set_xlabel("Frekvence [GHz]")
        ax_heat.set_ylabel("Sweep_Nr")
        cbar = self._fig.colorbar(im, ax=ax_heat)
        cbar.set_label("Power [dBµV]")

        ax_stat.set_facecolor(COLOR_PLOT_BG)
        mean_trace = np.mean(self._data, axis=0)
        min_trace = np.min(self._data, axis=0)
        max_trace = np.max(self._data, axis=0)
        std_trace = np.std(self._data, axis=0)

        ax_stat.fill_between(freqs_ghz, min_trace, max_trace, color=COLOR_PLOT_LINE, alpha=0.2, label="Min/Max spread")
        ax_stat.plot(freqs_ghz, mean_trace, color=COLOR_ACCENT_CYAN, linewidth=1.5, label="Mean")

        for r in self._resonances[:5]:
            ax_stat.plot(r["freq_ghz"], r["value_dbm"], "ro", markersize=6)
            ax_stat.annotate(f"{r['freq_ghz']:.2f}GHz", (r["freq_ghz"], r["value_dbm"]),
                             textcoords="offset points", xytext=(0, 10), ha='center', color=COLOR_TEXT_PRIMARY, fontsize=8)

        ax_stat.set_title("Statistika", color=COLOR_ACCENT_CYAN, fontfamily="Segoe UI")
        ax_stat.set_xlabel("Frekvence [GHz]")
        ax_stat.set_ylabel("Power [dBµV]")
        ax_stat.grid(True, color=COLOR_PLOT_GRID, alpha=0.5)
        ax_stat.legend(loc="best", fontsize=8, facecolor=COLOR_BG_CARD, edgecolor=COLOR_PLOT_GRID)

        ax_hist.set_facecolor(COLOR_PLOT_BG)
        ax_hist.plot(freqs_ghz, std_trace, color=COLOR_ORANGE, linewidth=1.5)
        ax_hist.set_title("Smerodatna odchylka (Stabilita)", color=COLOR_ACCENT_CYAN, fontfamily="Segoe UI")
        ax_hist.set_xlabel("Frekvence [GHz]")
        ax_hist.set_ylabel("Std Dev [dBµV]")
        ax_hist.grid(True, color=COLOR_PLOT_GRID, alpha=0.5)

        for ax in [ax_all, ax_heat, ax_stat, ax_hist]:
            for spine in ax.spines.values():
                spine.set_color(COLOR_PLOT_GRID)
            ax.tick_params(colors=COLOR_TEXT_SECONDARY, labelsize=9)

        self._fig.tight_layout()
        self._canvas.draw_idle()

    def _export_png(self):
        if self._data is None: return
        default_name = "sa_analysis.png"
        if self._filepath:
            default_name = os.path.splitext(os.path.basename(self._filepath))[0] + ".png"

        filepath = filedialog.asksaveasfilename(defaultextension=".png", filetypes=[("PNG obrazek", "*.png"), ("Vsechny soubory", "*.*")], initialfile=default_name)
        if not filepath: return
        try:
            self._fig.savefig(filepath, dpi=150, facecolor=self._fig.get_facecolor())
            self._set_status(f"Ulozeno: {filepath}", COLOR_GREEN)
        except Exception as e:
            self._set_status(f"Chyba ukladani: {e}", COLOR_RED)

    def _on_close(self):
        self.destroy()
        sys.exit(0)

if __name__ == "__main__":
    app = SAAnalyzerApp()
    app.mainloop()
