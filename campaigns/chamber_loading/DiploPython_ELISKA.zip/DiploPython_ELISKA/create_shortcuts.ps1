$WshShell = New-Object -ComObject WScript.Shell
$Desktop = [Environment]::GetFolderPath('Desktop')

# Shortcut 1: VNA Data Recorder
$Shortcut1 = $WshShell.CreateShortcut("$Desktop\VNA Data Recorder.lnk")
$Shortcut1.TargetPath = "C:\Python311\pythonw.exe"
$Shortcut1.Arguments = "vna_app.py"
$Shortcut1.WorkingDirectory = "C:\Users\j_hoffmann\DiploPython"
$Shortcut1.Description = "VNA Data Recorder - kontinualni sber dat"
$Shortcut1.Save()
Write-Host "Vytvoreno: VNA Data Recorder.lnk"

# Shortcut 2: VNA CSV Analyzer
$Shortcut2 = $WshShell.CreateShortcut("$Desktop\VNA CSV Analyzer.lnk")
$Shortcut2.TargetPath = "C:\Python311\pythonw.exe"
$Shortcut2.Arguments = "vna_analyzer_app.py"
$Shortcut2.WorkingDirectory = "C:\Users\j_hoffmann\DiploPython"
$Shortcut2.Description = "VNA CSV Analyzer - analyza exportovanych dat"
$Shortcut2.Save()
Write-Host "Vytvoreno: VNA CSV Analyzer.lnk"

Write-Host ""
Write-Host "Oba zastupce byly vytvoreny na plose!"
$Shortcut3.TargetPath = "C:\Python311\pythonw.exe"
$Shortcut3.Arguments = "sa_app.py"
$Shortcut3.WorkingDirectory = "C:\Users\j_hoffmann\DiploPython"
$Shortcut3.Description = "SA Data Recorder - kontinualni sber dat ze Spectrum Analyzer"
$Shortcut3.Save()
Write-Host "Vytvoreno: SA Data Recorder.lnk"

# Shortcut 4: SA CSV Analyzer
$Shortcut4 = $WshShell.CreateShortcut("$Desktop\SA CSV Analyzer.lnk")
$Shortcut4.TargetPath = "C:\Python311\pythonw.exe"
$Shortcut4.Arguments = "sa_analyzer_app.py"
$Shortcut4.WorkingDirectory = "C:\Users\j_hoffmann\DiploPython"
$Shortcut4.Description = "SA CSV Analyzer - analyza exportovanych dat"
$Shortcut4.Save()
Write-Host "Vytvoreno: SA CSV Analyzer.lnk"

Write-Host ""
Write-Host "Vsechny zastupce byly vytvoreny na plose!"
