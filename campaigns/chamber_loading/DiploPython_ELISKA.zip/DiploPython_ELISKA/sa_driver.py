"""
SA Driver – abstrakční vrstva pro komunikaci s Rohde & Schwarz přístroji:
  - FSP Spectrum Analyzer (měření spektra)
  - SMF 100A Signal Generator (generování signálu)

Obsahuje:
  - FSPDriver:      reálná komunikace se spektrálním analyzátorem přes VISA/SCPI
  - SMF100ADriver:  reálná komunikace se signálovým generátorem přes VISA/SCPI
  - SASimulator:    simulátor obou přístrojů pro testování bez hardwaru
"""

import time
import numpy as np

try:
    import pyvisa
    PYVISA_AVAILABLE = True
except ImportError:
    PYVISA_AVAILABLE = False


# ---------------------------------------------------------------------------
# Podporované parametry FSP
# ---------------------------------------------------------------------------
DETECTORS = ["RMS", "AVER", "PEAK", "SAMP", "QPE"]

RBW_VALUES = [
    "Auto", "10 Hz", "30 Hz", "100 Hz", "300 Hz",
    "1 kHz", "3 kHz", "10 kHz", "30 kHz", "100 kHz",
    "300 kHz", "1 MHz", "3 MHz",
]

VBW_VALUES = [
    "Auto", "10 Hz", "30 Hz", "100 Hz", "300 Hz",
    "1 kHz", "3 kHz", "10 kHz", "30 kHz", "100 kHz",
    "300 kHz", "1 MHz", "3 MHz",
]

REF_LEVELS = [
    "-40 dBm", "-30 dBm", "-20 dBm", "-10 dBm", "0 dBm",
    "+10 dBm", "+20 dBm", "+30 dBm",
]

# Jednotky osy Y – klíč = popisek v GUI, hodnota = SCPI příkaz
POWER_UNITS = {
    "dBm":    "DBM",
    "dBµV":   "DBUV",
    "dBmV":   "DBMV",
    "dBpW":   "DBPW",
    "W":      "W",
    "V":      "V",
}


def _parse_bw_value(val_str: str) -> float | None:
    """Parsuje hodnotu šířky pásma (např. '10 kHz') na Hz. None = auto."""
    if val_str.lower() == "auto":
        return None
    val_str = val_str.strip()
    if "MHz" in val_str:
        return float(val_str.replace("MHz", "").strip()) * 1e6
    elif "kHz" in val_str:
        return float(val_str.replace("kHz", "").strip()) * 1e3
    elif "Hz" in val_str:
        return float(val_str.replace("Hz", "").strip())
    return float(val_str)


def _parse_ref_level(val_str: str) -> float:
    """Parsuje referenční úroveň (např. '+10 dBm') na číslo."""
    return float(val_str.replace("dBm", "").strip())


# ===========================================================================
# FSP Spectrum Analyzer Driver
# ===========================================================================

class FSPDriver:
    """Ovladač pro Rohde & Schwarz FSP Spectrum Analyzer přes VISA (SCPI)."""

    def __init__(self):
        self._instrument = None
        self._rm = None
        self._idn = ""
        self._visa_address = ""

    # -- Properties ----------------------------------------------------------

    @property
    def is_connected(self) -> bool:
        return self._instrument is not None

    @property
    def idn(self) -> str:
        return self._idn

    # -- Connection ----------------------------------------------------------

    def connect(self, visa_address: str, timeout_ms: int = 10000) -> str:
        """
        Připojí se k FSP na dané VISA adrese.
        Vrátí IDN string přístroje.
        """
        if not PYVISA_AVAILABLE:
            raise RuntimeError(
                "Knihovna 'pyvisa' není nainstalovaná.\n"
                "Nainstaluj ji příkazem:  pip install pyvisa pyvisa-py"
            )

        try:
            self._rm = pyvisa.ResourceManager("@py")
            self._instrument = self._rm.open_resource(visa_address)
            self._instrument.timeout = timeout_ms
            self._visa_address = visa_address

            # Ověření identity přístroje
            self._idn = self._instrument.query("*IDN?").strip()

            # Vyčištění chyb a nastavení ASCII formátu
            self._instrument.write("*CLS")
            self._instrument.write("FORMAT:DATA ASCii")

            return self._idn

        except Exception as e:
            self._instrument = None
            self._rm = None
            raise RuntimeError(f"Nepodařilo se připojit k {visa_address}:\n{e}")

    def disconnect(self):
        """Odpojí se od FSP a vrátí ho do kontinuálního módu."""
        if self._instrument is not None:
            try:
                self._instrument.write("INIT:CONT ON")
            except Exception:
                pass
            try:
                self._instrument.close()
            except Exception:
                pass
            self._instrument = None

        if self._rm is not None:
            try:
                self._rm.close()
            except Exception:
                pass
            self._rm = None

        self._idn = ""

    # -- Measurement configuration -------------------------------------------

    def configure_measurement(self, ref_level: str = "0 dBm",
                              rbw: str = "Auto", vbw: str = "Auto",
                              detector: str = "RMS",
                              unit: str = "dBµV"):
        """
        Konfiguruje parametry měření FSP.

        ref_level:  referenční úroveň (např. '0 dBm')
        rbw:        resolution bandwidth (např. '10 kHz' nebo 'Auto')
        vbw:        video bandwidth (např. '10 kHz' nebo 'Auto')
        detector:   typ detektoru ('RMS', 'AVER', 'PEAK', 'SAMP', 'QPE')
        unit:       jednotka osy Y (klíč z POWER_UNITS)
        """
        self._check_connected()
        self._instrument.write("*CLS")

        # Jednotky osy Y
        scpi_unit = POWER_UNITS.get(unit, "DBUV")
        self._instrument.write(f"CALC:UNIT:POW {scpi_unit}")

        # Referenční úroveň
        ref_val = _parse_ref_level(ref_level)
        self._instrument.write(f"DISP:WIND:TRAC:Y:RLEV {ref_val}")

        # RBW
        rbw_val = _parse_bw_value(rbw)
        if rbw_val is None:
            self._instrument.write("BAND:AUTO ON")
        else:
            self._instrument.write("BAND:AUTO OFF")
            self._instrument.write(f"BAND {rbw_val}")

        # VBW
        vbw_val = _parse_bw_value(vbw)
        if vbw_val is None:
            self._instrument.write("BAND:VID:AUTO ON")
        else:
            self._instrument.write("BAND:VID:AUTO OFF")
            self._instrument.write(f"BAND:VID {vbw_val}")

        # Detektor
        det_scpi = detector.upper()
        self._instrument.write(f"DET {det_scpi}")

        # Single sweep mód
        self._instrument.write("INIT:CONT OFF")

    # -- Frequency axis ------------------------------------------------------

    def set_frequency_range(self, start_hz: float, stop_hz: float):
        """Nastaví počáteční a koncovou frekvenci sweepu [Hz]."""
        self._check_connected()
        self._instrument.write(f"SENS:FREQ:STAR {start_hz} HZ")
        self._instrument.write(f"SENS:FREQ:STOP {stop_hz} HZ")

    def set_center_span(self, center_hz: float, span_hz: float):
        """Nastaví středovou frekvenci a šířku pásma [Hz]."""
        self._check_connected()
        self._instrument.write(f"SENS:FREQ:CENT {center_hz} HZ")
        self._instrument.write(f"SENS:FREQ:SPAN {span_hz} HZ")

    def get_frequency_axis(self) -> np.ndarray:
        """
        Vyčte frekvenční nastavení z FSP a vrátí pole frekvencí [Hz].
        """
        self._check_connected()

        f_start = float(self._instrument.query("SENS:FREQ:STAR?").strip())
        f_stop = float(self._instrument.query("SENS:FREQ:STOP?").strip())
        n_points = int(float(self._instrument.query("SWE:POIN?").strip()))

        return np.linspace(f_start, f_stop, n_points)

    # -- Single sweep --------------------------------------------------------

    def single_sweep(self) -> np.ndarray:
        """
        Spustí jeden sweep, počká na dokončení a vrátí naměřená data.
        Vrací 1D numpy pole (amplituda v dBm).
        """
        self._check_connected()

        # Zjistíme předpokládanou dobu sweepu (v sekundách)
        try:
            sweep_time = float(self._instrument.query("SWE:TIME?").strip())
        except Exception:
            sweep_time = 10.0 # Fallback
        
        # Nastavíme štědrý timeout (sweep time + 15 sekund rezerva)
        original_timeout = self._instrument.timeout
        needed_timeout = int((sweep_time + 15.0) * 1000)
        
        if needed_timeout > original_timeout:
            self._instrument.timeout = needed_timeout

        try:
            # Spuštění sweepu a vyčkání pomocí *WAI přímo v přístroji
            self._instrument.write("INIT:IMM; *WAI")

            # Vyčtení dat z TRACE1
            raw = self._instrument.query("TRAC:DATA? TRACE1")
            values = np.array([float(x) for x in raw.strip().split(",")])
            
        finally:
            # Vrátíme původní timeout
            self._instrument.timeout = original_timeout

        return values

    # -- Helpers -------------------------------------------------------------

    def _check_connected(self):
        if self._instrument is None:
            raise RuntimeError("FSP není připojeno.")


# ===========================================================================
# SMF 100A Signal Generator Driver
# ===========================================================================

class SMF100ADriver:
    """Ovladač pro Rohde & Schwarz SMF 100A Signal Generator přes VISA (SCPI)."""

    def __init__(self):
        self._instrument = None
        self._rm = None
        self._idn = ""
        self._visa_address = ""

    # -- Properties ----------------------------------------------------------

    @property
    def is_connected(self) -> bool:
        return self._instrument is not None

    @property
    def idn(self) -> str:
        return self._idn

    # -- Connection ----------------------------------------------------------

    def connect(self, visa_address: str, timeout_ms: int = 10000) -> str:
        """
        Připojí se k SMF 100A na dané VISA adrese.
        Vrátí IDN string přístroje.
        """
        if not PYVISA_AVAILABLE:
            raise RuntimeError(
                "Knihovna 'pyvisa' není nainstalovaná.\n"
                "Nainstaluj ji příkazem:  pip install pyvisa pyvisa-py"
            )

        try:
            self._rm = pyvisa.ResourceManager("@py")
            self._instrument = self._rm.open_resource(visa_address)
            self._instrument.timeout = timeout_ms
            self._visa_address = visa_address

            # Ověření identity přístroje
            self._idn = self._instrument.query("*IDN?").strip()

            # Vynutíme bezpečné a předvídatelné jednotky (dBm)
            self._instrument.write("*CLS")
            self._instrument.write("UNIT:POW DBM")

            return self._idn

        except Exception as e:
            self._instrument = None
            self._rm = None
            raise RuntimeError(f"Nepodařilo se připojit k {visa_address}:\n{e}")

    def disconnect(self):
        """Odpojí se od generátoru – vypne RF výstup."""
        if self._instrument is not None:
            try:
                self._instrument.write("OUTP:STAT OFF")
            except Exception:
                pass
            try:
                self._instrument.close()
            except Exception:
                pass
            self._instrument = None

        if self._rm is not None:
            try:
                self._rm.close()
            except Exception:
                pass
            self._rm = None

        self._idn = ""

    # -- Frequency control ---------------------------------------------------

    def set_frequency(self, freq_hz: float):
        """Nastaví výstupní frekvenci generátoru [Hz]."""
        self._check_connected()
        self._instrument.write(f"SOUR:FREQ {freq_hz} HZ")

    def get_frequency(self) -> float:
        """Vrátí aktuální frekvenci generátoru [Hz]."""
        self._check_connected()
        return float(self._instrument.query("SOUR:FREQ?").strip())

    # -- Power control -------------------------------------------------------

    def set_power(self, power_dbm: float):
        """Nastaví výstupní výkon generátoru [dBm]."""
        self._check_connected()
        self._instrument.write(f"SOUR:POW {power_dbm} DBM")

    def get_power(self) -> float:
        """Vrátí aktuální výkon generátoru [dBm]."""
        self._check_connected()
        return float(self._instrument.query("SOUR:POW?").strip())

    # -- RF Output control ---------------------------------------------------

    def set_output(self, on: bool):
        """Zapne/vypne RF výstup."""
        self._check_connected()
        state = "ON" if on else "OFF"
        self._instrument.write(f"OUTP:STAT {state}")

    def get_output_state(self) -> bool:
        """Vrátí stav RF výstupu."""
        self._check_connected()
        resp = self._instrument.query("OUTP:STAT?").strip()
        return resp in ("1", "ON")

    # -- Helpers -------------------------------------------------------------

    def _check_connected(self):
        if self._instrument is None:
            raise RuntimeError("SMF 100A není připojeno.")


# ===========================================================================
# Simulátor – generuje falešná data pro testování
# ===========================================================================

class SASimulator:
    """
    Simuluje rozhraní FSPDriver + SMF100ADriver pro testování GUI
    bez fyzických přístrojů.
    """

    def __init__(self):
        # FSP stav
        self._fsp_connected = False
        self._fsp_idn = ""

        # SMF stav
        self._smf_connected = False
        self._smf_idn = ""
        self._smf_freq = 1.0e9     # 1 GHz
        self._smf_power = -10.0    # -10 dBm
        self._smf_output = False

        # Parametry měření FSP
        self._ref_level = 0.0
        self._detector = "RMS"
        self._f_start = 100e3      # 100 kHz
        self._f_stop = 6.0e9       # 6 GHz
        self._n_points = 501

        # Interní stav pro variace dat
        self._sweep_count = 0

    # -----------------------------------------------------------------------
    # FSP interface
    # -----------------------------------------------------------------------

    @property
    def is_connected(self) -> bool:
        """Stav připojení FSP (pro kompatibilitu s hlavní aplikací)."""
        return self._fsp_connected

    @property
    def idn(self) -> str:
        return self._fsp_idn

    def connect(self, visa_address: str, timeout_ms: int = 10000) -> str:
        """Simuluje připojení FSP."""
        time.sleep(0.3)
        self._fsp_connected = True
        self._fsp_idn = "Rohde&Schwarz,FSP,100001,4.75 (SIMULACE)"
        return self._fsp_idn

    def disconnect(self):
        """Simuluje odpojení FSP."""
        self._fsp_connected = False
        self._fsp_idn = ""

    def configure_measurement(self, ref_level: str = "0 dBm",
                              rbw: str = "Auto", vbw: str = "Auto",
                              detector: str = "RMS", unit: str = "dBµV"):
        """Uloží konfiguraci."""
        self._ref_level = _parse_ref_level(ref_level)
        self._detector = detector

    def set_frequency_range(self, start_hz: float, stop_hz: float):
        """Simulace nastavení Start/Stop."""
        self._f_start = start_hz
        self._f_stop = stop_hz

    def set_center_span(self, center_hz: float, span_hz: float):
        """Simulace nastavení Center/Span."""
        self._f_start = center_hz - span_hz / 2
        self._f_stop = center_hz + span_hz / 2

    def get_frequency_axis(self) -> np.ndarray:
        """Vrátí simulovanou frekvenční osu."""
        return np.linspace(self._f_start, self._f_stop, self._n_points)

    def single_sweep(self) -> np.ndarray:
        """
        Generuje simulovaná spektrální data.
        Obsahují šumovou podlahu, signálový peak od generátoru a variace.
        """
        self._sweep_count += 1
        freqs = self.get_frequency_axis()
        n = len(freqs)

        # Šumová podlaha (kolem -80 dBm s variací)
        noise_floor = -80.0 + np.random.normal(0, 2.0, n)

        # Tvarování šumové podlahy – mírný nárůst na vyšších frekvencích
        noise_floor += 5.0 * (freqs / freqs[-1])

        data = noise_floor.copy()

        # Signálový peak od generátoru (pokud je zapnutý)
        if self._smf_output:
            sig_freq = self._smf_freq
            sig_power = self._smf_power
            # Hlavní peak
            sigma = 5e6  # šířka peaku ~5 MHz
            peak = (sig_power - noise_floor.mean()) * np.exp(
                -0.5 * ((freqs - sig_freq) / sigma) ** 2
            )
            data += peak

            # Harmonická (2×)
            harm_freq = 2 * sig_freq
            if harm_freq <= freqs[-1]:
                harm_peak = (sig_power - 30 - noise_floor.mean()) * np.exp(
                    -0.5 * ((freqs - harm_freq) / sigma) ** 2
                )
                data += harm_peak

        # Spurious signály (interferencí)
        for spur_freq, spur_level in [
            (0.9e9, -65), (2.4e9, -55), (5.0e9, -70),
        ]:
            spur = (spur_level - noise_floor.mean()) * np.exp(
                -0.5 * ((freqs - spur_freq) / 3e6) ** 2
            )
            data += spur

        # Variace mezi sweepy (drift + šum)
        drift = 0.3 * np.sin(self._sweep_count * 0.15)
        noise_var = np.random.normal(0, 0.5, n)
        data += drift + noise_var

        # Simulace doby sweepu
        time.sleep(0.15)

        return data

    # -----------------------------------------------------------------------
    # SMF 100A interface
    # -----------------------------------------------------------------------

    @property
    def smf_is_connected(self) -> bool:
        return self._smf_connected

    @property
    def smf_idn(self) -> str:
        return self._smf_idn

    def smf_connect(self, visa_address: str, timeout_ms: int = 10000) -> str:
        """Simuluje připojení SMF 100A."""
        time.sleep(0.2)
        self._smf_connected = True
        self._smf_idn = "Rohde&Schwarz,SMF100A,200001,3.20 (SIMULACE)"
        return self._smf_idn

    def smf_disconnect(self):
        """Simuluje odpojení SMF 100A."""
        self._smf_output = False
        self._smf_connected = False
        self._smf_idn = ""

    def set_frequency(self, freq_hz: float):
        self._smf_freq = freq_hz

    def get_frequency(self) -> float:
        return self._smf_freq

    def set_power(self, power_dbm: float):
        self._smf_power = power_dbm

    def get_power(self) -> float:
        return self._smf_power

    def set_output(self, on: bool):
        self._smf_output = on

    def get_output_state(self) -> bool:
        return self._smf_output
