"""
VNA Driver – abstrakční vrstva pro komunikaci s Rohde & Schwarz ZND VNA.

Obsahuje:
  - VNADriver: reálná komunikace přes VISA/SCPI
  - VNASimulator: generuje simulovaná data pro testování bez přístroje
"""

import time
import numpy as np

try:
    import pyvisa
    PYVISA_AVAILABLE = True
except ImportError:
    PYVISA_AVAILABLE = False


# ---------------------------------------------------------------------------
# Podporované S-parametry a formáty
# ---------------------------------------------------------------------------
S_PARAMETERS = ["S11", "S12", "S21", "S22"]

TRACE_FORMATS = {
    "dB Mag":   "MLOG",   # Magnitude in dB
    "Phase":    "PHAS",   # Phase in degrees
    "Lin Mag":  "MLIN",   # Linear magnitude
    "Real":     "REAL",   # Real part
    "Imag":     "IMAG",   # Imaginary part
    "SWR":      "SWR",    # Standing wave ratio
    "Smith":    "SMIT",   # Smith chart (Re/Im)
}

TRACE_FORMAT_UNITS = {
    "dB Mag":   "dB",
    "Phase":    "°",
    "Lin Mag":  "",
    "Real":     "",
    "Imag":     "",
    "SWR":      "",
    "Smith":    "",
}


class VNADriver:
    """Ovladač pro Rohde & Schwarz ZND VNA přes VISA (SCPI)."""

    def __init__(self):
        self._instrument = None
        self._rm = None
        self._idn = ""
        self._visa_address = ""

    # -- Properties ----------------------------------------------------------

    @property
    def is_connected(self) -> bool:
        return self._instrument is not None

    @property
    def idn(self) -> str:
        return self._idn

    # -- Connection ----------------------------------------------------------

    def connect(self, visa_address: str, timeout_ms: int = 10000) -> str:
        """
        Připojí se k VNA na dané VISA adrese.
        Vrátí IDN string přístroje.
        Raises RuntimeError při selhání.
        """
        if not PYVISA_AVAILABLE:
            raise RuntimeError(
                "Knihovna 'pyvisa' není nainstalovaná.\n"
                "Nainstaluj ji příkazem:  pip install pyvisa pyvisa-py"
            )

        try:
            self._rm = pyvisa.ResourceManager("@py")
            self._instrument = self._rm.open_resource(visa_address)
            self._instrument.timeout = timeout_ms
            self._visa_address = visa_address

            # Ověření identity přístroje
            self._idn = self._instrument.query("*IDN?").strip()

            # Nastavení formátu přenosu dat na ASCII (jednoduché parsování)
            self._instrument.write("FORMat:DATA ASCii")

            return self._idn

        except Exception as e:
            self._instrument = None
            self._rm = None
            raise RuntimeError(f"Nepodařilo se připojit k {visa_address}:\n{e}")

    def disconnect(self):
        """Odpojí se od VNA a vrátí ho do kontinuálního módu."""
        if self._instrument is not None:
            try:
                self._instrument.write("INIT1:CONT ON")
            except Exception:
                pass
            try:
                self._instrument.close()
            except Exception:
                pass
            self._instrument = None

        if self._rm is not None:
            try:
                self._rm.close()
            except Exception:
                pass
            self._rm = None

        self._idn = ""

    # -- Measurement configuration -------------------------------------------

    def configure_measurement(self, s_param: str = "S11", trace_formats: list[str] | str = "dB Mag"):
        """
        Konfiguruje měření na kanálu 1 / trace 1.
        s_param:       'S11', 'S21', ...
        trace_formats:  klíč nebo seznam klíčů z TRACE_FORMATS ('dB Mag', 'Phase', ...)
        """
        self._check_connected()

        # Nastavení S-parametru  (CALC1:PAR:MEAS 'Trc1', 'S11')
        self._instrument.write(f"CALC1:PAR:MEAS 'Trc1', '{s_param}'")

        if isinstance(trace_formats, str):
            trace_formats = [trace_formats]

        # Nastavení formátu zobrazení (výchozí první)
        fmt_scpi = TRACE_FORMATS.get(trace_formats[0], "MLOG")
        self._instrument.write(f"CALC1:FORM {fmt_scpi}")

        # Přepnutí do single-sweep módu
        self._instrument.write("INIT1:CONT OFF")

    # -- Frequency axis ------------------------------------------------------

    def set_frequency_range(self, start_hz: float, stop_hz: float):
        """Nastaví počáteční a koncovou frekvenci sweepu [Hz]."""
        self._check_connected()
        self._instrument.write(f"SENS1:FREQ:STAR {start_hz} HZ")
        self._instrument.write(f"SENS1:FREQ:STOP {stop_hz} HZ")

    def get_frequency_axis(self) -> np.ndarray:
        """
        Vyčte frekvenční nastavení z VNA a vrátí pole frekvencí [Hz].
        """
        self._check_connected()

        f_start = float(self._instrument.query("SENS1:FREQ:STAR?").strip())
        f_stop = float(self._instrument.query("SENS1:FREQ:STOP?").strip())
        n_points = int(float(self._instrument.query("SENS1:SWE:POIN?").strip()))

        return np.linspace(f_start, f_stop, n_points)

    # -- Single sweep --------------------------------------------------------

    def single_sweep(self, trace_formats: list[str] | str = "dB Mag") -> dict[str, np.ndarray] | np.ndarray:
        """
        Spustí jeden sweep, počká na dokončení a vrátí naměřená data.
        Pokud je trace_formats seznam, vrací slovník {format_name: 1D numpy pole}.
        Pokud je trace_formats řetězec, vrací 1D numpy pole.
        """
        self._check_connected()

        # Spuštění sweepu a čekání na dokončení
        self._instrument.write("INIT1:IMM; *OPC")

        # Čekáme na OPC bit v STB/ESR
        self._instrument.query("*OPC?")

        if isinstance(trace_formats, str):
            fmt_scpi = TRACE_FORMATS.get(trace_formats, "MLOG")
            self._instrument.write(f"CALC1:FORM {fmt_scpi}")
            raw = self._instrument.query("CALC1:DATA? FDAT")
            return np.array([float(x) for x in raw.strip().split(",")])

        results = {}
        for fmt in trace_formats:
            fmt_scpi = TRACE_FORMATS.get(fmt, "MLOG")
            self._instrument.write(f"CALC1:FORM {fmt_scpi}")
            raw = self._instrument.query("CALC1:DATA? FDAT")
            values = np.array([float(x) for x in raw.strip().split(",")])
            results[fmt] = values

        return results

    # -- Helpers -------------------------------------------------------------

    def _check_connected(self):
        if self._instrument is None:
            raise RuntimeError("VNA není připojeno.")


# ===========================================================================
# Simulátor – generuje falešná data pro testování
# ===========================================================================

class VNASimulator:
    """
    Simuluje rozhraní VNADriver pro testování GUI bez fyzického přístroje.
    Generuje realisticky vypadající S-parametrová data.
    """

    def __init__(self):
        self._connected = False
        self._idn = ""
        self._s_param = "S11"
        self._trace_formats = ["dB Mag"]

        # Simulované parametry sweepu
        self._f_start = 100e3      # 100 kHz
        self._f_stop = 4.5e9       # 4.5 GHz
        self._n_points = 201

        # Interní stav pro variace dat
        self._sweep_count = 0

    @property
    def is_connected(self) -> bool:
        return self._connected

    @property
    def idn(self) -> str:
        return self._idn

    def connect(self, visa_address: str, timeout_ms: int = 10000) -> str:
        """Simuluje připojení – vždy uspěje."""
        time.sleep(0.3)  # Simulace zpoždění
        self._connected = True
        self._idn = "Rohde&Schwarz,ZND-2Port,1328517092101219,2.90 (SIMULACE)"
        return self._idn

    def disconnect(self):
        """Simuluje odpojení."""
        self._connected = False
        self._idn = ""

    def configure_measurement(self, s_param: str = "S11", trace_formats: list[str] | str = "dB Mag"):
        """Uloží konfiguraci pro generování dat."""
        self._s_param = s_param
        if isinstance(trace_formats, str):
            self._trace_formats = [trace_formats]
        else:
            self._trace_formats = list(trace_formats)

    def set_frequency_range(self, start_hz: float, stop_hz: float):
        """Simulace nastavení frekvenčního rozsahu."""
        self._f_start = start_hz
        self._f_stop = stop_hz

    def get_frequency_axis(self) -> np.ndarray:
        """Vrátí simulovanou frekvenční osu."""
        return np.linspace(self._f_start, self._f_stop, self._n_points)

    def _generate_simulated_data_for_format(self, fmt: str, freqs: np.ndarray, n: int) -> np.ndarray:
        if fmt == "Phase":
            data = np.linspace(-180, 180, n) + np.random.normal(0, 5, n)
        elif fmt in ("Real", "Imag"):
            data = np.sin(np.linspace(0, 6 * np.pi, n)) * 0.5 + np.random.normal(0, 0.05, n)
            if fmt == "Imag":
                data = np.cos(np.linspace(0, 6 * np.pi, n)) * 0.5 + np.random.normal(0, 0.05, n)
        else:
            if self._s_param in ("S11", "S22"):
                data = np.full(n, -8.0)
                for freq_center, depth, width in [
                    (0.9e9,  -25, 80e6),
                    (1.8e9,  -30, 50e6),
                    (2.45e9, -35, 60e6),
                    (3.5e9,  -20, 100e6),
                ]:
                    gaussian = depth * np.exp(-0.5 * ((freqs - freq_center) / width) ** 2)
                    data += gaussian
            else:
                data = np.full(n, -1.5)
                for freq_center, depth, width in [
                    (1.2e9,  -15, 60e6),
                    (3.0e9,  -10, 80e6),
                ]:
                    gaussian = depth * np.exp(-0.5 * ((freqs - freq_center) / width) ** 2)
                    data += gaussian

            noise = np.random.normal(0, 0.3, n)
            drift = 0.5 * np.sin(self._sweep_count * 0.1)
            data += noise + drift

            if fmt == "Lin Mag":
                data = 10 ** (data / 20.0)
            elif fmt == "SWR":
                lin = 10 ** (data / 20.0)
                data = (1 + lin) / (1 - lin + 1e-9)
                data = np.clip(data, 1, 100)

        return data

    def single_sweep(self, trace_formats: list[str] | str | None = None) -> dict[str, np.ndarray] | np.ndarray:
        """
        Generuje simulovaná data pro zadané nebo nakonfigurované formáty.
        """
        self._sweep_count += 1
        freqs = self.get_frequency_axis()
        n = len(freqs)

        if trace_formats is None:
            formats_input = getattr(self, "_trace_formats", ["dB Mag"])
        else:
            formats_input = trace_formats

        if isinstance(formats_input, str):
            data = self._generate_simulated_data_for_format(formats_input, freqs, n)
            time.sleep(0.15)
            return data

        results = {}
        for fmt in formats_input:
            results[fmt] = self._generate_simulated_data_for_format(fmt, freqs, n)

        time.sleep(0.15)
        return results
