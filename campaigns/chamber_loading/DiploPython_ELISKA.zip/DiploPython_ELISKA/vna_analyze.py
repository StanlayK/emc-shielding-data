"""
VNA CSV Analyzer – zpracování a vizualizace exportovaných VNA dat.

Načte CSV soubor exportovaný z VNA Data Recorderu a vytvoří:
  1. Přehledný graf všech sweepů (překryté čáry)
  2. Heatmapu (frekvence × čas) ukazující vývoj S-parametrů
  3. Statistický souhrn (průměr, min, max, rozptyl)
  4. Detekci rezonančních frekvencí (minima S11)

Spuštění:
    python vna_analyze.py                                # zpracuje poslední CSV
    python vna_analyze.py vna_export_20260409_091007.csv  # konkrétní soubor
"""

import sys
import os
import io
import glob

# Fix Windows console encoding
if sys.stdout.encoding != 'utf-8':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
import numpy as np
import matplotlib
matplotlib.use("TkAgg")
import matplotlib.pyplot as plt
from matplotlib.gridspec import GridSpec
from matplotlib.ticker import FuncFormatter
from scipy.signal import find_peaks

# ---------------------------------------------------------------------------
# Formátovací pomocníky
# ---------------------------------------------------------------------------

def freq_formatter(x, _):
    """Formátuje frekvenci do čitelné podoby (MHz / GHz)."""
    if x >= 1e9:
        return f"{x / 1e9:.2f} GHz"
    elif x >= 1e6:
        return f"{x / 1e6:.0f} MHz"
    else:
        return f"{x / 1e3:.0f} kHz"


def load_vna_csv(filepath: str) -> tuple:
    """
    Načte VNA export CSV.
    
    Vrací:
        freqs: np.ndarray – frekvenční osa [Hz]
        data:  np.ndarray – 2D matice [sweepy × frekvenční body], hodnoty v dB
        sweep_numbers: np.ndarray – čísla sweepů
    """
    print(f"[LOAD] Nacitam soubor: {filepath}")
    
    # Načtení hlavičky
    with open(filepath, "r", encoding="utf-8") as f:
        header_line = f.readline().strip()
    
    headers = header_line.split(",")
    
    # První sloupec je "Sweep_Nr", zbytek jsou frekvence
    freqs = np.array([float(h) for h in headers[1:]])
    
    # Načtení dat (přeskočíme hlavičku)
    raw_data = np.loadtxt(filepath, delimiter=",", skiprows=1)
    
    sweep_numbers = raw_data[:, 0].astype(int)
    data = raw_data[:, 1:]
    
    n_sweeps, n_points = data.shape
    print(f"   [OK] {n_sweeps} sweepu x {n_points} frekvencnich bodu")
    print(f"   [FREQ] Rozsah: {freq_formatter(freqs[0], None)} - {freq_formatter(freqs[-1], None)}")
    print(f"   [STEP] Krok: {(freqs[1] - freqs[0]) / 1e3:.1f} kHz")
    print(f"   [DATA] Rozsah hodnot: {np.min(data):.2f} dB ... {np.max(data):.2f} dB")
    print()
    
    return freqs, data, sweep_numbers


def find_resonances(freqs: np.ndarray, trace: np.ndarray, 
                    prominence: float = 5.0, min_depth: float = -20.0) -> list:
    """
    Najde rezonanční frekvence (minima) v S11 trace.
    
    Vrací seznam dict: {"freq_hz", "freq_ghz", "value_db", "index"}
    """
    # Invertujeme, protože hledáme minima (peaky v -trace)
    peaks, properties = find_peaks(-trace, prominence=prominence, height=-min_depth)
    
    resonances = []
    for idx in peaks:
        resonances.append({
            "freq_hz": freqs[idx],
            "freq_ghz": freqs[idx] / 1e9,
            "value_db": trace[idx],
            "index": idx,
        })
    
    # Seřadit podle hloubky (nejhlubší první)
    resonances.sort(key=lambda r: r["value_db"])
    
    return resonances


# ---------------------------------------------------------------------------
# Vizualizace
# ---------------------------------------------------------------------------

def create_analysis_figure(freqs, data, sweep_numbers, output_path=None):
    """
    Vytvoří kompletní analytický graf se 4 panely.
    """
    # Styl
    plt.style.use("dark_background")
    
    fig = plt.figure(figsize=(18, 12), facecolor="#0d1117")
    fig.suptitle("VNA Data Analysis", fontsize=18, fontweight="bold",
                 color="#58a6ff", y=0.98)
    
    gs = GridSpec(2, 2, figure=fig, hspace=0.32, wspace=0.25,
                  left=0.06, right=0.97, top=0.93, bottom=0.06)
    
    # Barvy
    cmap_lines = plt.cm.viridis
    colors = [cmap_lines(i / max(len(sweep_numbers) - 1, 1)) 
              for i in range(len(sweep_numbers))]

    # ========================================
    # Panel 1: Všechny sweepy překryté
    # ========================================
    ax1 = fig.add_subplot(gs[0, 0])
    ax1.set_facecolor("#0d1117")
    
    for i, (sweep_nr, trace) in enumerate(zip(sweep_numbers, data)):
        alpha = 0.3 + 0.7 * (i / max(len(sweep_numbers) - 1, 1))
        ax1.plot(freqs, trace, color=colors[i], linewidth=0.8, alpha=alpha,
                 label=f"Sweep {sweep_nr}" if i in [0, len(sweep_numbers) - 1] else None)
    
    ax1.set_xlabel("Frekvence", fontsize=10)
    ax1.set_ylabel("S11 [dB]", fontsize=10)
    ax1.set_title("Všechny sweepy (překryté)", fontsize=13, fontweight="bold",
                  color="#e0e0e0", pad=8)
    ax1.xaxis.set_major_formatter(FuncFormatter(freq_formatter))
    ax1.grid(True, color="#21262d", alpha=0.5, linewidth=0.5)
    ax1.legend(fontsize=8, loc="lower left", framealpha=0.3)
    plt.setp(ax1.xaxis.get_majorticklabels(), rotation=30, ha="right", fontsize=8)

    # ========================================
    # Panel 2: Heatmapa (frekvence × sweep)
    # ========================================
    ax2 = fig.add_subplot(gs[0, 1])
    ax2.set_facecolor("#0d1117")
    
    # Decimace pro lepší zobrazení (max ~500 sloupců)
    step = max(1, len(freqs) // 500)
    freqs_dec = freqs[::step]
    data_dec = data[:, ::step]
    
    im = ax2.pcolormesh(freqs_dec, sweep_numbers, data_dec,
                        cmap="inferno", shading="auto")
    cbar = fig.colorbar(im, ax=ax2, label="S11 [dB]", pad=0.02)
    cbar.ax.tick_params(labelsize=8)
    
    ax2.set_xlabel("Frekvence", fontsize=10)
    ax2.set_ylabel("Sweep #", fontsize=10)
    ax2.set_title("Heatmapa – vývoj v čase", fontsize=13, fontweight="bold",
                  color="#e0e0e0", pad=8)
    ax2.xaxis.set_major_formatter(FuncFormatter(freq_formatter))
    plt.setp(ax2.xaxis.get_majorticklabels(), rotation=30, ha="right", fontsize=8)

    # ========================================
    # Panel 3: Průměr ± rozptyl + rezonance
    # ========================================
    ax3 = fig.add_subplot(gs[1, 0])
    ax3.set_facecolor("#0d1117")
    
    mean_trace = np.mean(data, axis=0)
    std_trace = np.std(data, axis=0)
    min_trace = np.min(data, axis=0)
    max_trace = np.max(data, axis=0)
    
    ax3.fill_between(freqs, min_trace, max_trace, alpha=0.15, color="#58a6ff",
                     label="Min–Max")
    ax3.fill_between(freqs, mean_trace - std_trace, mean_trace + std_trace,
                     alpha=0.3, color="#58a6ff", label="±1σ")
    ax3.plot(freqs, mean_trace, color="#58a6ff", linewidth=1.5, label="Průměr")
    
    # Detekce a vyznačení rezonancí
    resonances = find_resonances(freqs, mean_trace)
    for res in resonances[:8]:  # max 8 rezonancí
        ax3.axvline(res["freq_hz"], color="#ff6b6b", alpha=0.4, linewidth=0.8,
                    linestyle="--")
        ax3.annotate(
            f"{res['freq_ghz']:.3f} GHz\n{res['value_db']:.1f} dB",
            xy=(res["freq_hz"], res["value_db"]),
            xytext=(0, -25), textcoords="offset points",
            fontsize=7, color="#ff6b6b", fontweight="bold",
            ha="center",
            arrowprops=dict(arrowstyle="->", color="#ff6b6b", lw=0.8),
        )
    
    ax3.set_xlabel("Frekvence", fontsize=10)
    ax3.set_ylabel("S11 [dB]", fontsize=10)
    ax3.set_title("Statistika + rezonanční frekvence", fontsize=13,
                  fontweight="bold", color="#e0e0e0", pad=8)
    ax3.xaxis.set_major_formatter(FuncFormatter(freq_formatter))
    ax3.grid(True, color="#21262d", alpha=0.5, linewidth=0.5)
    ax3.legend(fontsize=8, loc="lower left", framealpha=0.3)
    plt.setp(ax3.xaxis.get_majorticklabels(), rotation=30, ha="right", fontsize=8)

    # ========================================
    # Panel 4: Stabilita (rozptyl) po frekvenci
    # ========================================
    ax4 = fig.add_subplot(gs[1, 1])
    ax4.set_facecolor("#0d1117")
    
    # Rozptyl (max - min) pro každý frekvenční bod
    spread = max_trace - min_trace
    
    ax4.fill_between(freqs, 0, spread, alpha=0.4, color="#00e676")
    ax4.plot(freqs, spread, color="#00e676", linewidth=1.0)
    ax4.plot(freqs, std_trace, color="#ff9100", linewidth=1.0, alpha=0.8,
             label="Směrodatná odchylka (σ)")
    
    ax4.set_xlabel("Frekvence", fontsize=10)
    ax4.set_ylabel("Rozptyl [dB]", fontsize=10)
    ax4.set_title("Stabilita měření (max−min)", fontsize=13, fontweight="bold",
                  color="#e0e0e0", pad=8)
    ax4.xaxis.set_major_formatter(FuncFormatter(freq_formatter))
    ax4.grid(True, color="#21262d", alpha=0.5, linewidth=0.5)
    ax4.legend(fontsize=8, loc="upper right", framealpha=0.3)
    plt.setp(ax4.xaxis.get_majorticklabels(), rotation=30, ha="right", fontsize=8)
    
    # Uložení
    if output_path:
        fig.savefig(output_path, dpi=150, facecolor=fig.get_facecolor())
        print(f"[SAVE] Graf ulozen: {output_path}")
    
    return fig, resonances


def print_resonance_report(resonances, n_sweeps):
    """Vypíše přehled nalezených rezonancí."""
    print("=" * 60)
    print("  NALEZENE REZONANCNI FREKVENCE")
    print("=" * 60)
    
    if not resonances:
        print("   Zadne vyrazne rezonance nebyly nalezeny.")
        return
    
    print(f"{'#':>3}  {'Frekvence':>12}  {'S11 [dB]':>10}  {'Hloubka':>8}")
    print("-" * 45)
    
    for i, res in enumerate(resonances[:10], start=1):
        print(f"{i:>3}  {res['freq_ghz']:>9.4f} GHz  {res['value_db']:>10.2f}  {'#' * min(int(abs(res['value_db']) / 2), 25)}")
    
    print()
    print(f"   Analyzovano ze {n_sweeps} sweepu (prumerovana data)")
    print()


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    # Najdi CSV soubor
    if len(sys.argv) > 1:
        csv_path = sys.argv[1]
    else:
        # Najdi poslední vna_export soubor ve složce
        patterns = ["vna_export_*.csv", "vna_data_*.csv"]
        csv_files = []
        for pattern in patterns:
            csv_files.extend(glob.glob(pattern))
        
        if not csv_files:
            print("[ERROR] Nenalezen zadny VNA CSV soubor.")
            print("   Pouziti: python vna_analyze.py <soubor.csv>")
            sys.exit(1)
        
        csv_path = sorted(csv_files)[-1]  # Poslední podle názvu
    
    if not os.path.exists(csv_path):
        print(f"[ERROR] Soubor neexistuje: {csv_path}")
        sys.exit(1)
    
    # Načtení dat
    freqs, data, sweep_numbers = load_vna_csv(csv_path)
    
    # Analýza a vizualizace
    base_name = os.path.splitext(csv_path)[0]
    output_png = f"{base_name}_analysis.png"
    
    fig, resonances = create_analysis_figure(freqs, data, sweep_numbers, 
                                              output_path=output_png)
    
    # Report
    print_resonance_report(resonances, len(sweep_numbers))
    
    # Zobrazení
    print("[PLOT] Zobrazuji graf... (zavri okno pro ukonceni)")
    plt.show()


if __name__ == "__main__":
    main()
