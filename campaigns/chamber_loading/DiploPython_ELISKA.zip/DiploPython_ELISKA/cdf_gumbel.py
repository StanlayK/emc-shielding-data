"""
CDF & Gumbel – výpočetní modul pro statistickou analýzu VNA dat.

Obsahuje funkce pro:
  - Extrakci datové řady ze sweepů (volba frekvence / pásma)
  - Výpočet empirické CDF
  - Fit Gumbelova rozdělení (pro maxima i minima)
  - Vykreslení CDF + histogram grafů
  - Export výsledků do CSV / XLSX
  - Výpočet statistik (min, max, mean, std, percentily, KS test...)

Autor: DiploPython projekt
"""

import numpy as np

from scipy import stats as sp_stats


# ---------------------------------------------------------------------------
# Konstanty pro barvy (sdílené s hlavní aplikací)
# ---------------------------------------------------------------------------
COLOR_PLOT_BG       = "#0d1117"
COLOR_PLOT_GRID     = "#21262d"
COLOR_ACCENT_CYAN   = "#00d2ff"
COLOR_GREEN         = "#00e676"
COLOR_ORANGE        = "#ff9100"
COLOR_RED           = "#ff1744"
COLOR_TEXT_PRIMARY   = "#e0e0e0"
COLOR_TEXT_SECONDARY = "#9e9e9e"

# Barvy pro CDF/Gumbel grafy
COLOR_ECDF          = "#58a6ff"   # empirická CDF - modrá
COLOR_GUMBEL        = "#f78166"   # Gumbel fit    - oranžová
COLOR_HIST          = "#58a6ff"   # histogram     - modrá
COLOR_PDF           = "#f78166"   # PDF overlay   - oranžová


# ---------------------------------------------------------------------------
# Režimy analýzy
# ---------------------------------------------------------------------------
ANALYSIS_MODES = {
    "A: Jedna frekvence":   "single_freq",
    "B: Maximum v pásmu":   "band_max",
    "C: Minimum v pásmu":   "band_min",
    "D: Průměr v pásmu":    "band_mean",
}


# ---------------------------------------------------------------------------
# Pomocné funkce
# ---------------------------------------------------------------------------

def db_to_linear(values_db: np.ndarray) -> np.ndarray:
    """
    Převede hodnoty z dB na lineární magnitudu.
    linear = 10^(dB / 20)

    Připraveno pro budoucí použití – přepínání mezi dB a lineárním režimem.
    """
    return np.power(10.0, np.asarray(values_db, dtype=float) / 20.0)


def _find_nearest_freq_index(freqs: np.ndarray, target_hz: float) -> int:
    """Najde index nejbližší frekvence v poli frekvencí."""
    return int(np.argmin(np.abs(freqs - target_hz)))


def _get_band_mask(freqs: np.ndarray, band_start_hz: float,
                   band_stop_hz: float) -> np.ndarray:
    """Vrátí booleovskou masku pro frekvenční body uvnitř zadaného pásma."""
    return (freqs >= band_start_hz) & (freqs <= band_stop_hz)


# ---------------------------------------------------------------------------
# Extrakce datové řady
# ---------------------------------------------------------------------------

def extract_series_for_mode(data: np.ndarray, freqs: np.ndarray,
                            mode: str,
                            freq_value_hz: float = None,
                            band_start_hz: float = None,
                            band_stop_hz: float = None) -> np.ndarray:
    """
    Extrahuje 1D řadu hodnot (jednu hodnotu na sweep) ze 2D matice dat.

    Parametry:
        data:           2D matice [n_sweeps × n_freq_points], hodnoty v dB
        freqs:          1D pole frekvencí [Hz]
        mode:           'single_freq', 'band_max', 'band_min', 'band_mean'
        freq_value_hz:  frekvence pro režim A [Hz]
        band_start_hz:  začátek pásma pro režimy B/C/D [Hz]
        band_stop_hz:   konec pásma pro režimy B/C/D [Hz]

    Vrací:
        1D numpy pole délky n_sweeps
    """
    if data is None or len(data) == 0:
        raise ValueError("Data jsou prázdná.")

    if data.ndim == 1:
        data = data.reshape(1, -1)

    n_sweeps, n_points = data.shape

    if mode == "single_freq":
        # Režim A: jedna frekvence napříč sweepy
        if freq_value_hz is None:
            raise ValueError("Pro režim A je nutné zadat frekvenci.")
        idx = _find_nearest_freq_index(freqs, freq_value_hz)
        return data[:, idx].copy()

    elif mode in ("band_max", "band_min", "band_mean"):
        # Režimy B/C/D: operace v pásmu
        if band_start_hz is None or band_stop_hz is None:
            raise ValueError("Pro režim B/C/D je nutné zadat pásmo (start a stop).")

        mask = _get_band_mask(freqs, band_start_hz, band_stop_hz)
        if not np.any(mask):
            raise ValueError(
                f"Žádné frekvenční body v pásmu "
                f"{band_start_hz/1e9:.3f}–{band_stop_hz/1e9:.3f} GHz."
            )

        band_data = data[:, mask]

        if mode == "band_max":
            return np.nanmax(band_data, axis=1)
        elif mode == "band_min":
            return np.nanmin(band_data, axis=1)
        else:  # band_mean
            return np.nanmean(band_data, axis=1)

    else:
        raise ValueError(f"Neznámý režim: {mode}")


# ---------------------------------------------------------------------------
# Empirická CDF
# ---------------------------------------------------------------------------

def compute_empirical_cdf(values: np.ndarray):
    """
    Spočítá empirickou CDF (kumulativní distribuční funkci).

    Vrací:
        sorted_values:  seřazená data vzestupně
        ecdf_y:         pravděpodobnosti (0, 1) – stabilní varianta i/(n+1)
    """
    clean = values[~np.isnan(values)]
    if len(clean) == 0:
        return np.array([]), np.array([])

    sorted_vals = np.sort(clean)
    n = len(sorted_vals)
    ecdf_y = np.arange(1, n + 1) / (n + 1)

    return sorted_vals, ecdf_y


# ---------------------------------------------------------------------------
# Gumbel fit
# ---------------------------------------------------------------------------

def fit_gumbel(values: np.ndarray, mode: str = "band_max"):
    """
    Fituje Gumbelovo rozdělení na data.

    Pro maxima (režim A, B, D) → gumbel_r (Gumbel pro maxima / Type I).
    Pro minima (režim C) → fit na -values pomocí gumbel_r, pak transformace zpět.

    Vrací:
        mu:      lokalizační parametr (loc)
        beta:    škálovací parametr (scale)
        is_min:  True pokud jde o fit pro minima (inverzní transformace)
    """
    clean = values[~np.isnan(values)]
    if len(clean) < 3:
        return None, None, False

    is_min = (mode == "band_min")

    if is_min:
        # Pro minima: fitujeme -x pomocí gumbel_r
        fit_data = -clean
    else:
        fit_data = clean

    # MLE fit Gumbel pro maxima
    loc, scale = sp_stats.gumbel_r.fit(fit_data)

    if is_min:
        # Transformace zpět: mu' = -loc, beta zůstává
        return -loc, scale, True
    else:
        return loc, scale, False


def gumbel_cdf_values(x: np.ndarray, mu: float, beta: float,
                      is_min: bool = False) -> np.ndarray:
    """
    Spočítá teoretickou Gumbelovu CDF pro dané x.

    Pro maxima: F(x) = exp(-exp(-(x-mu)/beta))
    Pro minima: F(x) = 1 - exp(-exp((x-mu)/beta))  [Gumbel min = Weibull Type III]
    """
    if is_min:
        # Gumbel pro minima
        z = (x - mu) / beta
        return 1.0 - np.exp(-np.exp(z))
    else:
        # Gumbel pro maxima (gumbel_r)
        return sp_stats.gumbel_r.cdf(x, loc=mu, scale=beta)


def gumbel_pdf_values(x: np.ndarray, mu: float, beta: float,
                      is_min: bool = False) -> np.ndarray:
    """
    Spočítá teoretickou Gumbelovu PDF pro dané x.
    """
    if is_min:
        z = (x - mu) / beta
        return (1.0 / beta) * np.exp(z - np.exp(z))
    else:
        return sp_stats.gumbel_r.pdf(x, loc=mu, scale=beta)


# ---------------------------------------------------------------------------
# Statistiky
# ---------------------------------------------------------------------------

def compute_statistics(values: np.ndarray, mu: float, beta: float,
                       is_min: bool, ecdf_x: np.ndarray,
                       ecdf_y: np.ndarray) -> dict:
    """
    Spočítá souhrnné statistiky pro danou řadu.

    Vrací slovník s klíči:
        n, min, max, mean, std, median, p90, p95, p99,
        gumbel_mu, gumbel_beta, ks_statistic, ks_pvalue
    """
    clean = values[~np.isnan(values)]
    n = len(clean)

    result = {
        "n":        n,
        "min":      float(np.min(clean)) if n > 0 else None,
        "max":      float(np.max(clean)) if n > 0 else None,
        "mean":     float(np.mean(clean)) if n > 0 else None,
        "std":      float(np.std(clean, ddof=1)) if n > 1 else None,
        "median":   float(np.median(clean)) if n > 0 else None,
        "p90":      float(np.percentile(clean, 90)) if n > 0 else None,
        "p95":      float(np.percentile(clean, 95)) if n > 0 else None,
        "p99":      float(np.percentile(clean, 99)) if n > 0 else None,
        "gumbel_mu":    mu,
        "gumbel_beta":  beta,
    }

    # Kolmogorov–Smirnov test: porovnání empirické CDF s Gumbel fitem
    if mu is not None and beta is not None and n >= 5:
        if is_min:
            # Pro minima: KS test na -values vs gumbel_r(-mu, beta)
            ks_stat, ks_p = sp_stats.kstest(-clean, 'gumbel_r', args=(-mu, beta))
        else:
            ks_stat, ks_p = sp_stats.kstest(clean, 'gumbel_r', args=(mu, beta))

        result["ks_statistic"] = float(ks_stat)
        result["ks_pvalue"] = float(ks_p)
    else:
        result["ks_statistic"] = None
        result["ks_pvalue"] = None

    return result


def format_statistics_text(stats: dict, mode_label: str = "") -> str:
    """Formátuje statistiky do čitelného textového bloku."""
    lines = []
    if mode_label:
        lines.append(f"Režim: {mode_label}")
        lines.append("=" * 36)

    lines.append(f"  Počet vzorků:    {stats['n']}")
    lines.append(f"  Minimum:         {stats['min']:.4f} dB" if stats['min'] is not None else "  Minimum: N/A")
    lines.append(f"  Maximum:         {stats['max']:.4f} dB" if stats['max'] is not None else "  Maximum: N/A")
    lines.append(f"  Průměr:          {stats['mean']:.4f} dB" if stats['mean'] is not None else "  Průměr: N/A")
    lines.append(f"  Směr. odchylka:  {stats['std']:.4f} dB" if stats['std'] is not None else "  Směr. odchylka: N/A")
    lines.append(f"  Medián:          {stats['median']:.4f} dB" if stats['median'] is not None else "  Medián: N/A")
    lines.append("")
    lines.append(f"  P90:  {stats['p90']:.4f} dB" if stats['p90'] is not None else "  P90: N/A")
    lines.append(f"  P95:  {stats['p95']:.4f} dB" if stats['p95'] is not None else "  P95: N/A")
    lines.append(f"  P99:  {stats['p99']:.4f} dB" if stats['p99'] is not None else "  P99: N/A")
    lines.append("")
    lines.append("--- Gumbel fit ---")
    lines.append(f"  μ (loc):   {stats['gumbel_mu']:.4f}" if stats['gumbel_mu'] is not None else "  μ (loc): N/A")
    lines.append(f"  β (scale): {stats['gumbel_beta']:.4f}" if stats['gumbel_beta'] is not None else "  β (scale): N/A")
    lines.append("")

    if stats.get("ks_statistic") is not None:
        lines.append("--- Goodness of fit ---")
        lines.append(f"  KS statistika: {stats['ks_statistic']:.4f}")
        lines.append(f"  KS p-hodnota:  {stats['ks_pvalue']:.4f}")
        if stats['ks_pvalue'] < 0.05:
            lines.append("  ⚠ Fit zamítnut (p < 0.05)")
        else:
            lines.append("  ✅ Fit nelze zamítnout")
    else:
        lines.append("  Goodness-of-fit: N/A (málo dat)")

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Vykreslení grafů
# ---------------------------------------------------------------------------

def plot_cdf_and_gumbel(fig, values: np.ndarray, mode: str,
                        mode_label: str = "",
                        min_sweeps: int = 20):
    """
    Vykreslí do matplotlib Figure:
      - Horní subplot: empirická CDF + teoretická Gumbel CDF
      - Dolní subplot: histogram + Gumbel PDF

    Parametry:
        fig:         matplotlib Figure (bude vyčištěna)
        values:      1D pole hodnot [dB]
        mode:        režim analýzy ('single_freq', 'band_max', ...)
        mode_label:  popisný text režimu pro titulek
        min_sweeps:  min. počet sweepů pro aktivaci Gumbel fitu

    Vrací:
        stats:  slovník se statistikami (nebo None při chybě)
    """
    fig.clear()

    clean = values[~np.isnan(values)] if values is not None else np.array([])
    n = len(clean)

    if n == 0:
        ax = fig.add_subplot(111)
        ax.set_facecolor(COLOR_PLOT_BG)
        ax.text(0.5, 0.5, "Žádná platná data",
                transform=ax.transAxes, ha="center", va="center",
                fontsize=16, color=COLOR_TEXT_SECONDARY)
        ax.set_xticks([])
        ax.set_yticks([])
        for spine in ax.spines.values():
            spine.set_visible(False)
        return None

    # Výpočty
    ecdf_x, ecdf_y = compute_empirical_cdf(clean)

    # Gumbel fit – pouze pokud máme dostatek dat
    mu, beta, is_min = None, None, False
    has_gumbel = False
    if n >= min_sweeps:
        mu, beta, is_min = fit_gumbel(clean, mode)
        if mu is not None and beta is not None:
            has_gumbel = True

    # Statistiky
    stats = compute_statistics(clean, mu, beta, is_min, ecdf_x, ecdf_y)

    # --- Horní graf: CDF ---
    ax1 = fig.add_subplot(211)
    ax1.set_facecolor(COLOR_PLOT_BG)

    # Empirická CDF – schodová křivka
    ax1.step(ecdf_x, ecdf_y, where="post", color=COLOR_ECDF,
             linewidth=1.8, label="Empirická CDF", alpha=0.9)
    ax1.scatter(ecdf_x, ecdf_y, color=COLOR_ECDF, s=12, alpha=0.5,
                zorder=3, edgecolors="none")

    # Gumbel CDF overlay
    if has_gumbel:
        x_range = np.linspace(ecdf_x[0] - 0.5 * (ecdf_x[-1] - ecdf_x[0]),
                              ecdf_x[-1] + 0.5 * (ecdf_x[-1] - ecdf_x[0]),
                              500)
        gumbel_y = gumbel_cdf_values(x_range, mu, beta, is_min)
        ax1.plot(x_range, gumbel_y, color=COLOR_GUMBEL, linewidth=2.0,
                 linestyle="--", label=f"Gumbel CDF (μ={mu:.2f}, β={beta:.2f})",
                 alpha=0.9)

    # Styling
    title = f"CDF – {mode_label}" if mode_label else "Empirická CDF vs Gumbel"
    ax1.set_title(title, fontsize=12, fontweight="bold",
                  color=COLOR_TEXT_PRIMARY, pad=8)
    ax1.set_xlabel("S21 [dB]", fontsize=10, color=COLOR_TEXT_PRIMARY)
    ax1.set_ylabel("Kumulativní pravděpodobnost", fontsize=10,
                   color=COLOR_TEXT_PRIMARY)
    ax1.set_ylim(-0.02, 1.05)
    ax1.legend(fontsize=8, loc="lower right", framealpha=0.3,
               facecolor=COLOR_PLOT_BG, edgecolor=COLOR_PLOT_GRID)
    ax1.grid(True, color=COLOR_PLOT_GRID, alpha=0.5, linewidth=0.5)
    ax1.tick_params(colors=COLOR_TEXT_SECONDARY, labelsize=8)
    for spine in ax1.spines.values():
        spine.set_color(COLOR_PLOT_GRID)

    # --- Dolní graf: Histogram + PDF ---
    ax2 = fig.add_subplot(212)
    ax2.set_facecolor(COLOR_PLOT_BG)

    # Histogram
    n_bins = max(10, min(50, int(np.sqrt(n) * 1.5)))
    ax2.hist(clean, bins=n_bins, density=True, color=COLOR_HIST,
             alpha=0.5, edgecolor=COLOR_PLOT_GRID, linewidth=0.5,
             label="Histogram (normalizovaný)")

    # Gumbel PDF overlay
    if has_gumbel:
        x_pdf = np.linspace(clean.min() - 0.3 * np.ptp(clean),
                            clean.max() + 0.3 * np.ptp(clean), 500)
        pdf_y = gumbel_pdf_values(x_pdf, mu, beta, is_min)
        ax2.plot(x_pdf, pdf_y, color=COLOR_PDF, linewidth=2.0,
                 label=f"Gumbel PDF", alpha=0.9)

    # Styling
    ax2.set_title("Histogram + Gumbel PDF", fontsize=12, fontweight="bold",
                  color=COLOR_TEXT_PRIMARY, pad=8)
    ax2.set_xlabel("S21 [dB]", fontsize=10, color=COLOR_TEXT_PRIMARY)
    ax2.set_ylabel("Hustota pravděpodobnosti", fontsize=10,
                   color=COLOR_TEXT_PRIMARY)
    ax2.legend(fontsize=8, loc="upper right", framealpha=0.3,
               facecolor=COLOR_PLOT_BG, edgecolor=COLOR_PLOT_GRID)
    ax2.grid(True, color=COLOR_PLOT_GRID, alpha=0.5, linewidth=0.5)
    ax2.tick_params(colors=COLOR_TEXT_SECONDARY, labelsize=8)
    for spine in ax2.spines.values():
        spine.set_color(COLOR_PLOT_GRID)

    fig.tight_layout(pad=2.0)

    return stats


def plot_cdf_mini(ax, values: np.ndarray, mode: str = "band_max",
                  min_sweeps: int = 20):
    """
    Kompaktní verze CDF grafu pro live panel v Data Recorderu.
    Vykreslí do jednoho Axes (místo celé Figure).
    """
    ax.clear()
    ax.set_facecolor(COLOR_PLOT_BG)

    clean = values[~np.isnan(values)] if values is not None else np.array([])
    n = len(clean)

    if n < 3:
        ax.text(0.5, 0.5, f"Čekám na data\n({n} sweepů)",
                transform=ax.transAxes, ha="center", va="center",
                fontsize=10, color=COLOR_TEXT_SECONDARY)
        ax.set_xticks([])
        ax.set_yticks([])
        for spine in ax.spines.values():
            spine.set_color(COLOR_PLOT_GRID)
        return

    ecdf_x, ecdf_y = compute_empirical_cdf(clean)

    # Empirická CDF
    ax.step(ecdf_x, ecdf_y, where="post", color=COLOR_ECDF,
            linewidth=1.5, alpha=0.9)

    # Gumbel fit overlay (pokud dost dat)
    if n >= min_sweeps:
        mu, beta, is_min = fit_gumbel(clean, mode)
        if mu is not None and beta is not None:
            x_range = np.linspace(ecdf_x[0], ecdf_x[-1], 200)
            gumbel_y = gumbel_cdf_values(x_range, mu, beta, is_min)
            ax.plot(x_range, gumbel_y, color=COLOR_GUMBEL, linewidth=1.5,
                    linestyle="--", alpha=0.8)

    ax.set_title(f"Live CDF ({n} sw.)", fontsize=9, fontweight="bold",
                 color=COLOR_ACCENT_CYAN, pad=4)
    ax.set_xlabel("dB", fontsize=8, color=COLOR_TEXT_SECONDARY)
    ax.set_ylabel("P", fontsize=8, color=COLOR_TEXT_SECONDARY)
    ax.set_ylim(-0.02, 1.05)
    ax.grid(True, color=COLOR_PLOT_GRID, alpha=0.4, linewidth=0.5)
    ax.tick_params(colors=COLOR_TEXT_SECONDARY, labelsize=7)
    for spine in ax.spines.values():
        spine.set_color(COLOR_PLOT_GRID)


# ---------------------------------------------------------------------------
# Export výsledků
# ---------------------------------------------------------------------------

def export_cdf_results(stats: dict, values: np.ndarray,
                       filepath: str, file_format: str = "csv"):
    """
    Exportuje výsledky CDF/Gumbel analýzy do CSV nebo XLSX.

    Parametry:
        stats:       slovník ze compute_statistics()
        values:      zdrojová 1D řada hodnot
        filepath:    cílová cesta souboru
        file_format: 'csv' nebo 'xlsx'
    """
    import csv as csv_module

    # Příprava dat pro export
    rows = [
        ["Parametr", "Hodnota"],
        ["Počet vzorků", stats["n"]],
        ["Minimum [dB]", f"{stats['min']:.6f}" if stats['min'] is not None else "N/A"],
        ["Maximum [dB]", f"{stats['max']:.6f}" if stats['max'] is not None else "N/A"],
        ["Průměr [dB]", f"{stats['mean']:.6f}" if stats['mean'] is not None else "N/A"],
        ["Směrodatná odchylka [dB]", f"{stats['std']:.6f}" if stats['std'] is not None else "N/A"],
        ["Medián [dB]", f"{stats['median']:.6f}" if stats['median'] is not None else "N/A"],
        ["P90 [dB]", f"{stats['p90']:.6f}" if stats['p90'] is not None else "N/A"],
        ["P95 [dB]", f"{stats['p95']:.6f}" if stats['p95'] is not None else "N/A"],
        ["P99 [dB]", f"{stats['p99']:.6f}" if stats['p99'] is not None else "N/A"],
        [],
        ["Gumbel μ (loc)", f"{stats['gumbel_mu']:.6f}" if stats['gumbel_mu'] is not None else "N/A"],
        ["Gumbel β (scale)", f"{stats['gumbel_beta']:.6f}" if stats['gumbel_beta'] is not None else "N/A"],
        ["KS statistika", f"{stats['ks_statistic']:.6f}" if stats.get('ks_statistic') is not None else "N/A"],
        ["KS p-hodnota", f"{stats['ks_pvalue']:.6f}" if stats.get('ks_pvalue') is not None else "N/A"],
        [],
        ["--- Zdrojová data ---"],
        ["Index", "Hodnota [dB]"],
    ]

    clean = values[~np.isnan(values)] if values is not None else np.array([])
    for i, v in enumerate(clean, start=1):
        rows.append([i, f"{v:.6f}"])

    if file_format == "xlsx":
        try:
            from openpyxl import Workbook
            wb = Workbook()
            ws = wb.active
            ws.title = "CDF_Gumbel"
            for row in rows:
                ws.append(row)
            wb.save(filepath)
        except ImportError:
            # Fallback na CSV pokud openpyxl není dostupný
            filepath = filepath.replace(".xlsx", ".csv")
            file_format = "csv"

    if file_format == "csv":
        with open(filepath, "w", newline="", encoding="utf-8") as f:
            writer = csv_module.writer(f)
            for row in rows:
                writer.writerow(row)
