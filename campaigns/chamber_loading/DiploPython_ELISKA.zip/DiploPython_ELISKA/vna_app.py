"""
VNA Data Recorder – GUI aplikace pro kontinuální sběr dat
z Rohde & Schwarz ZND-2Port VNA.

Spuštění:
    python vna_app.py

Autor: DiploPython projekt
"""

import os
import sys
import csv
import time
import threading
import queue
from datetime import datetime

import numpy as np
import customtkinter as ctk
import matplotlib
matplotlib.use("TkAgg")
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk
from matplotlib.figure import Figure
import tkinter as tk

class ToolTip:
    """Jednoduchý tooltip pro nápovědu při najetí myší."""
    def __init__(self, widget, text, delay=500):
        self.widget = widget
        self.text = text
        self.delay = delay
        self.tooltip_window = None
        self.id = None
        self._bind_recursive(self.widget)

    def _bind_recursive(self, w):
        w.bind("<Enter>", self.enter, add="+")
        w.bind("<Leave>", self.leave, add="+")
        w.bind("<ButtonPress>", self.leave, add="+")
        if hasattr(w, "winfo_children"):
            for child in w.winfo_children():
                self._bind_recursive(child)

    def enter(self, event=None):
        self.schedule()

    def leave(self, event=None):
        self.unschedule()
        self.hide()

    def schedule(self):
        self.unschedule()
        self.id = self.widget.after(self.delay, self.show)

    def unschedule(self):
        id_ = self.id
        self.id = None
        if id_:
            self.widget.after_cancel(id_)

    def show(self):
        self.unschedule()
        if self.tooltip_window:
            return
        x = self.widget.winfo_rootx() + 20
        y = self.widget.winfo_rooty() + self.widget.winfo_height() + 5
        self.tooltip_window = tw = tk.Toplevel(self.widget)
        tw.wm_overrideredirect(True)
        tw.wm_geometry(f"+{x}+{y}")
        tw.attributes("-topmost", True)
        label = tk.Label(tw, text=self.text, justify="left",
                         background="#1a1a2e", foreground="#00d2ff",
                         relief="solid", borderwidth=1,
                         font=("Segoe UI", 9))
        label.pack(ipadx=6, ipady=4)

    def hide(self):
        tw = self.tooltip_window
        self.tooltip_window = None
        if tw:
            tw.destroy()

from vna_driver import (
    VNADriver,
    VNASimulator,
    S_PARAMETERS,
    TRACE_FORMATS,
    TRACE_FORMAT_UNITS,
)

# Import CDF/Gumbel modulu pro live panel
from cdf_gumbel import (
    ANALYSIS_MODES,
    extract_series_for_mode,
    plot_cdf_mini,
)


# ---------------------------------------------------------------------------
# Konstanty
# ---------------------------------------------------------------------------
DEFAULT_VISA_ADDRESS = "TCPIP0::10.56.11.11::inst0::INSTR"
APP_TITLE = "VNA Data Recorder"
APP_VERSION = "1.0"
WINDOW_SIZE = "1280x820"

# Barvy (dark theme)
COLOR_BG_DARK       = "#1a1a2e"
COLOR_BG_CARD       = "#16213e"
COLOR_ACCENT_BLUE   = "#0f3460"
COLOR_ACCENT_CYAN   = "#00d2ff"
COLOR_GREEN         = "#00e676"
COLOR_RED           = "#ff1744"
COLOR_ORANGE        = "#ff9100"
COLOR_TEXT_PRIMARY   = "#e0e0e0"
COLOR_TEXT_SECONDARY = "#9e9e9e"
COLOR_PLOT_BG       = "#0d1117"
COLOR_PLOT_GRID     = "#21262d"
COLOR_PLOT_LINE     = "#58a6ff"
COLOR_PLOT_LINE2    = "#f78166"


# ---------------------------------------------------------------------------
# Hlavní aplikace
# ---------------------------------------------------------------------------
class VNAApp(ctk.CTk):
    """Hlavní okno GUI aplikace pro sběr VNA dat."""

    def __init__(self):
        super().__init__()

        # -- Nastavení okna --
        self.title(f"{APP_TITLE}  v{APP_VERSION}")
        self.geometry(WINDOW_SIZE)
        self.minsize(960, 650)

        # CustomTkinter appearance
        ctk.set_appearance_mode("dark")
        ctk.set_default_color_theme("blue")

        # -- Stav aplikace --
        self._driver = None                # VNADriver | VNASimulator
        self._is_recording = False
        self._sweep_count = 0
        self._data_queue = queue.Queue()   # komunikace worker → GUI
        self._stop_event = threading.Event()
        self._worker_thread = None
        self._csv_writer = None
        self._csv_file = None
        self._csv_filename = ""
        self._freq_axis = None             # numpy pole frekvencí
        self._history = []                 # seznam všech naměřených dat

        # -- Sestavení GUI --
        self._build_ui()

        # -- Periodická aktualizace grafu --
        self._schedule_plot_update()

        # -- Zavření okna --
        self.protocol("WM_DELETE_WINDOW", self._on_close)

    # =====================================================================
    # UI LAYOUT
    # =====================================================================

    def _build_ui(self):
        """Sestaví celé GUI."""
        # Hlavní kontejner
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(1, weight=1)  # graf expanduje

        # -- Header / branding --
        self._build_header()

        # -- Prostřední oblast: levý panel + graf --
        middle_frame = ctk.CTkFrame(self, fg_color="transparent")
        middle_frame.grid(row=1, column=0, sticky="nsew", padx=10, pady=(0, 5))
        middle_frame.grid_columnconfigure(1, weight=1)
        middle_frame.grid_rowconfigure(0, weight=1)

        self._build_left_panel(middle_frame)
        self._build_plot_area(middle_frame)

        # -- Statusbar --
        self._build_statusbar()

    def _build_header(self):
        """Hlavička aplikace s názvem a logem."""
        header = ctk.CTkFrame(self, height=56, corner_radius=0,
                              fg_color=COLOR_ACCENT_BLUE)
        header.grid(row=0, column=0, sticky="ew")
        header.grid_columnconfigure(1, weight=1)

        # Ikona + název
        title_label = ctk.CTkLabel(
            header, text="  🔬  VNA Data Recorder",
            font=ctk.CTkFont(family="Segoe UI", size=20, weight="bold"),
            text_color="#ffffff",
        )
        title_label.grid(row=0, column=0, padx=15, pady=10, sticky="w")

        # Verze
        ver_label = ctk.CTkLabel(
            header, text=f"Rohde & Schwarz ZND  •  v{APP_VERSION}",
            font=ctk.CTkFont(size=12),
            text_color=COLOR_TEXT_SECONDARY,
        )
        ver_label.grid(row=0, column=2, padx=15, pady=10, sticky="e")

    # -- Levý panel ----------------------------------------------------------

    def _build_left_panel(self, parent):
        """Levý panel s nastavením a ovládáním."""
        panel = ctk.CTkFrame(parent, width=310, fg_color=COLOR_BG_CARD,
                             corner_radius=12)
        panel.grid(row=0, column=0, sticky="ns", padx=(0, 8), pady=0)
        panel.grid_propagate(False)

        # ----- Sekce: Připojení -----
        self._build_section_label(panel, "📡  Připojení", row=0)

        # VISA adresa
        ctk.CTkLabel(panel, text="VISA adresa:", font=ctk.CTkFont(size=12),
                     text_color=COLOR_TEXT_SECONDARY).grid(
            row=1, column=0, padx=15, pady=(5, 0), sticky="w")

        self._visa_entry = ctk.CTkEntry(panel, width=270,
                                        placeholder_text=DEFAULT_VISA_ADDRESS)
        self._visa_entry.grid(row=2, column=0, padx=15, pady=(2, 5), sticky="w")
        self._visa_entry.insert(0, DEFAULT_VISA_ADDRESS)
        ToolTip(self._visa_entry, "Adresa VNA analyzátoru (např. TCPIP0::10.56.11.10::inst0::INSTR).")

        # Simulační mód
        self._sim_var = ctk.BooleanVar(value=False)
        self._sim_check = ctk.CTkCheckBox(
            panel, text="Simulační mód (bez VNA)",
            variable=self._sim_var,
            font=ctk.CTkFont(size=12),
            checkbox_width=20, checkbox_height=20,
        )
        self._sim_check.grid(row=3, column=0, padx=15, pady=(0, 5), sticky="w")
        ToolTip(self._sim_check, "Pro testování GUI aplikace nanečisto bez reálného hardwaru.")

        # Tlačítko Connect / Disconnect
        self._connect_btn = ctk.CTkButton(
            panel, text="Připojit", width=270, height=36,
            font=ctk.CTkFont(size=13, weight="bold"),
            fg_color=COLOR_ACCENT_CYAN, text_color="#000000",
            hover_color="#00b8d4",
            command=self._toggle_connection,
        )
        self._connect_btn.grid(row=4, column=0, padx=15, pady=(0, 10), sticky="w")

        # Connection info
        self._conn_info = ctk.CTkLabel(
            panel, text="Nepřipojeno",
            font=ctk.CTkFont(size=11), text_color=COLOR_TEXT_SECONDARY,
            wraplength=260, justify="left",
        )
        self._conn_info.grid(row=5, column=0, padx=15, pady=(0, 5), sticky="w")

        # Separátor
        sep1 = ctk.CTkFrame(panel, height=2, fg_color=COLOR_ACCENT_BLUE)
        sep1.grid(row=6, column=0, sticky="ew", padx=15, pady=8)

        # ----- Sekce: Měření -----
        self._build_section_label(panel, "⚙️  Nastavení měření", row=7)

        # Frekvence
        freq_frame = ctk.CTkFrame(panel, fg_color="transparent")
        freq_frame.grid(row=8, column=0, padx=15, pady=(5, 0), sticky="ew")
        
        ctk.CTkLabel(freq_frame, text="Start [GHz]:", font=ctk.CTkFont(size=11), text_color=COLOR_TEXT_SECONDARY).grid(row=0, column=0, padx=(0, 5), sticky="w")
        self._vna_start_entry = ctk.CTkEntry(freq_frame, width=60)
        self._vna_start_entry.grid(row=0, column=1, padx=(0, 5), sticky="w")
        self._vna_start_entry.insert(0, "0.1")
        ToolTip(self._vna_start_entry, "Počáteční frekvence (min GHz).\nUžší pásmo zrychluje sweep.")

        ctk.CTkLabel(freq_frame, text="Stop [GHz]:", font=ctk.CTkFont(size=11), text_color=COLOR_TEXT_SECONDARY).grid(row=0, column=2, padx=(5, 5), sticky="w")
        self._vna_stop_entry = ctk.CTkEntry(freq_frame, width=60)
        self._vna_stop_entry.grid(row=0, column=3, padx=(0, 0), sticky="w")
        self._vna_stop_entry.insert(0, "4.5")
        ToolTip(self._vna_stop_entry, "Koncová frekvence (max GHz).\nUžší pásmo zrychluje sweep.")

        # S-parametr
        ctk.CTkLabel(panel, text="S-parametr:", font=ctk.CTkFont(size=12),
                     text_color=COLOR_TEXT_SECONDARY).grid(
            row=9, column=0, padx=15, pady=(5, 0), sticky="w")

        self._sparam_var = ctk.StringVar(value="S11")
        self._sparam_menu = ctk.CTkOptionMenu(
            panel, values=S_PARAMETERS, variable=self._sparam_var,
            width=270, height=32,
            fg_color=COLOR_ACCENT_BLUE, button_color=COLOR_ACCENT_CYAN,
            button_hover_color="#00b8d4",
        )
        self._sparam_menu.grid(row=10, column=0, padx=15, pady=(2, 5), sticky="w")
        ToolTip(self._sparam_menu, "Měřený S-parametr.\nS11/S22 = Odraz (přizpůsobení)\nS21/S12 = Přenos (útlum/zisk).")

        # Formát (Checklist)
        ctk.CTkLabel(panel, text="Formát (lze vybrat více):", font=ctk.CTkFont(size=12),
                     text_color=COLOR_TEXT_SECONDARY).grid(
            row=11, column=0, padx=15, pady=(5, 0), sticky="w")

        format_frame = ctk.CTkFrame(panel, fg_color="transparent")
        format_frame.grid(row=12, column=0, padx=15, pady=(2, 5), sticky="w")

        self._format_vars = {}
        self._format_checkboxes = {}

        formats = list(TRACE_FORMATS.keys())
        for i, fmt in enumerate(formats):
            var = ctk.BooleanVar(value=(fmt == "dB Mag"))
            cb = ctk.CTkCheckBox(
                format_frame,
                text=fmt,
                variable=var,
                font=ctk.CTkFont(size=11),
                checkbox_width=18,
                checkbox_height=18,
                border_width=2,
            )
            r = i // 2
            c = i % 2
            cb.grid(row=r, column=c, padx=(0, 15), pady=2, sticky="w")
            self._format_vars[fmt] = var
            self._format_checkboxes[fmt] = cb

        ToolTip(format_frame, "Vyberte požadované formáty zobrazení dat pro CSV export.")

        # Interval
        ctk.CTkLabel(panel, text="Interval mezi sweepy:", font=ctk.CTkFont(size=12),
                     text_color=COLOR_TEXT_SECONDARY).grid(
            row=13, column=0, padx=15, pady=(5, 0), sticky="w")

        self._interval_var = ctk.StringVar(value="Bez pauzy")
        self._interval_menu = ctk.CTkOptionMenu(
            panel, values=["Bez pauzy", "0.5 s", "1 s", "2 s", "5 s", "10 s"],
            variable=self._interval_var,
            width=270, height=32,
            fg_color=COLOR_ACCENT_BLUE, button_color=COLOR_ACCENT_CYAN,
            button_hover_color="#00b8d4",
        )
        self._interval_menu.grid(row=14, column=0, padx=15, pady=(2, 5), sticky="w")
        ToolTip(self._interval_menu, "Čekání mezi dokončením sweepu a startem dalšího.")

        # Max. sweepů
        ctk.CTkLabel(panel, text="Max. sweepů:", font=ctk.CTkFont(size=12),
                     text_color=COLOR_TEXT_SECONDARY).grid(
            row=15, column=0, padx=15, pady=(5, 0), sticky="w")

        sweep_limit_frame = ctk.CTkFrame(panel, fg_color="transparent")
        sweep_limit_frame.grid(row=16, column=0, padx=15, pady=(2, 0), sticky="w")

        self._sweep_limit_entry = ctk.CTkEntry(
            sweep_limit_frame, width=120, height=32,
            placeholder_text="100",
        )
        self._sweep_limit_entry.grid(row=0, column=0, padx=(0, 10), sticky="w")
        self._sweep_limit_entry.insert(0, "100")
        ToolTip(self._sweep_limit_entry, "Po kolika sweepech se měření samo zastaví.")

        self._unlimited_var = ctk.BooleanVar(value=False)
        self._unlimited_check = ctk.CTkCheckBox(
            sweep_limit_frame, text="∞ bez limitu",
            variable=self._unlimited_var,
            font=ctk.CTkFont(size=12),
            checkbox_width=20, checkbox_height=20,
            command=self._toggle_sweep_limit,
        )
        self._unlimited_check.grid(row=0, column=1, sticky="w")
        ToolTip(self._unlimited_check, "Nekonečné měření. Zastavíte ho až ručně kliknutím.")

        # Výchozí stav: s limitem -> entry normal
        self._sweep_limit_entry.configure(state="normal")

        def _on_entry_active(event=None):
            if self._unlimited_var.get():
                self._unlimited_var.set(False)

        self._sweep_limit_entry.bind("<FocusIn>", _on_entry_active)
        self._sweep_limit_entry.bind("<KeyRelease>", _on_entry_active)
        if hasattr(self._sweep_limit_entry, "_entry"):
            self._sweep_limit_entry._entry.bind("<FocusIn>", _on_entry_active)
            self._sweep_limit_entry._entry.bind("<KeyRelease>", _on_entry_active)
            self._sweep_limit_entry._entry.bind("<Button-1>", _on_entry_active)

        # Separátor
        sep2 = ctk.CTkFrame(panel, height=2, fg_color=COLOR_ACCENT_BLUE)
        sep2.grid(row=17, column=0, sticky="ew", padx=15, pady=8)

        # ----- Sekce: Ovládání -----
        self._build_section_label(panel, "▶  Ovládání", row=18)

        # Start/Stop tlačítko
        self._start_btn = ctk.CTkButton(
            panel, text="▶  SPUSTIT SNÍMÁNÍ", width=270, height=44,
            font=ctk.CTkFont(size=14, weight="bold"),
            fg_color=COLOR_GREEN, text_color="#000000",
            hover_color="#00c853",
            command=self._toggle_recording,
            state="disabled",
        )
        self._start_btn.grid(row=19, column=0, padx=15, pady=(5, 5), sticky="w")

        # Tlačítko pro měření všech S-parametrů
        self._batch_sparam_btn = ctk.CTkButton(
            panel, text="⚡  MĚŘIT VŠECHNY S-PARAMETRY", width=270, height=38,
            font=ctk.CTkFont(size=12, weight="bold"),
            fg_color=COLOR_ACCENT_BLUE, hover_color="#1a4a8a",
            command=self._toggle_batch_recording,
            state="disabled",
        )
        self._batch_sparam_btn.grid(row=20, column=0, padx=15, pady=(0, 5), sticky="w")
        ToolTip(self._batch_sparam_btn, "Spustí sekvenční měření pro všechny S-parametry (S11, S12, S21, S22)\na uloží data do samostatných CSV souborů s příponami _S11.csv až _S22.csv.")

        # Zvukové upozornění po dokončení
        self._beep_var = ctk.BooleanVar(value=True)
        self._beep_check = ctk.CTkCheckBox(
            panel, text="🔔 Zvukové pípnutí po dokončení",
            variable=self._beep_var,
            font=ctk.CTkFont(size=11),
            checkbox_width=18, checkbox_height=18,
        )
        self._beep_check.grid(row=21, column=0, padx=15, pady=(0, 5), sticky="w")
        ToolTip(self._beep_check, "Přehrát hlasitá pípnutí po dokončení měření (např. všech S-parametrů).")

        # Export CSV tlačítko
        self._export_btn = ctk.CTkButton(
            panel, text="💾  Exportovat CSV", width=270, height=36,
            font=ctk.CTkFont(size=12, weight="bold"),
            fg_color=COLOR_ACCENT_BLUE, hover_color="#1a4a8a",
            command=self._export_csv,
            state="disabled",
        )
        self._export_btn.grid(row=22, column=0, padx=15, pady=(0, 5), sticky="w")

        # Počet sweepů
        self._sweep_label = ctk.CTkLabel(
            panel, text="Sweepů: 0",
            font=ctk.CTkFont(size=12, weight="bold"),
            text_color=COLOR_ACCENT_CYAN,
        )
        self._sweep_label.grid(row=23, column=0, padx=15, pady=(0, 2), sticky="w")

        # Progress bar pro sweep limit
        self._sweep_progress = ctk.CTkProgressBar(
            panel, width=270, height=8,
            progress_color=COLOR_ACCENT_CYAN,
            fg_color=COLOR_ACCENT_BLUE,
        )
        self._sweep_progress.grid(row=24, column=0, padx=15, pady=(0, 10), sticky="w")
        self._sweep_progress.set(0)

        # Separátor
        sep3 = ctk.CTkFrame(panel, height=2, fg_color=COLOR_ACCENT_BLUE)
        sep3.grid(row=25, column=0, sticky="ew", padx=15, pady=8)

        # ----- Sekce: Live CDF -----
        self._build_section_label(panel, "📊  Live CDF", row=26)

        # Režim CDF
        ctk.CTkLabel(panel, text="Režim:", font=ctk.CTkFont(size=11),
                     text_color=COLOR_TEXT_SECONDARY).grid(
            row=24, column=0, padx=15, pady=(5, 0), sticky="w")

        cdf_mode_keys = list(ANALYSIS_MODES.keys())
        self._live_cdf_mode_var = ctk.StringVar(value=cdf_mode_keys[1])  # B: Maximum
        self._live_cdf_mode_menu = ctk.CTkOptionMenu(
            panel, values=cdf_mode_keys, variable=self._live_cdf_mode_var,
            width=270, height=28,
            fg_color=COLOR_ACCENT_BLUE, button_color=COLOR_ACCENT_CYAN,
            button_hover_color="#00b8d4",
            font=ctk.CTkFont(size=11),
        )
        self._live_cdf_mode_menu.grid(row=25, column=0, padx=15, pady=(2, 3), sticky="w")

        # Frekvence / pásmo
        freq_band_frame = ctk.CTkFrame(panel, fg_color="transparent")
        freq_band_frame.grid(row=26, column=0, padx=15, pady=(0, 3), sticky="w")

        ctk.CTkLabel(freq_band_frame, text="f [GHz]:",
                     font=ctk.CTkFont(size=10),
                     text_color=COLOR_TEXT_SECONDARY).grid(
            row=0, column=0, padx=(0, 4), sticky="w")

        self._live_cdf_freq_entry = ctk.CTkEntry(
            freq_band_frame, width=65, height=24,
            placeholder_text="2.45", font=ctk.CTkFont(size=10))
        self._live_cdf_freq_entry.grid(row=0, column=1, padx=(0, 6), sticky="w")
        self._live_cdf_freq_entry.insert(0, "2.45")

        ctk.CTkLabel(freq_band_frame, text="–",
                     font=ctk.CTkFont(size=10),
                     text_color=COLOR_TEXT_SECONDARY).grid(
            row=0, column=2, padx=2, sticky="w")

        self._live_cdf_freq_end_entry = ctk.CTkEntry(
            freq_band_frame, width=65, height=24,
            placeholder_text="4.12", font=ctk.CTkFont(size=10))
        self._live_cdf_freq_end_entry.grid(row=0, column=3, padx=(0, 4), sticky="w")
        self._live_cdf_freq_end_entry.insert(0, "4.12")

        # Min sweepů
        min_sw_frame = ctk.CTkFrame(panel, fg_color="transparent")
        min_sw_frame.grid(row=27, column=0, padx=15, pady=(0, 5), sticky="w")

        ctk.CTkLabel(min_sw_frame, text="Min. sweepů:",
                     font=ctk.CTkFont(size=10),
                     text_color=COLOR_TEXT_SECONDARY).grid(
            row=0, column=0, padx=(0, 4), sticky="w")

        self._live_cdf_min_sweeps_entry = ctk.CTkEntry(
            min_sw_frame, width=50, height=24,
            font=ctk.CTkFont(size=10))
        self._live_cdf_min_sweeps_entry.grid(row=0, column=1, sticky="w")
        self._live_cdf_min_sweeps_entry.insert(0, "20")

    # -- Plot area -----------------------------------------------------------

    def _build_plot_area(self, parent):
        """Oblast s matplotlib grafem + live CDF mini-panel."""
        plot_frame = ctk.CTkFrame(parent, fg_color=COLOR_BG_CARD,
                                  corner_radius=12)
        plot_frame.grid(row=0, column=1, sticky="nsew", padx=0, pady=0)
        plot_frame.grid_columnconfigure(0, weight=1)
        plot_frame.grid_rowconfigure(0, weight=3)   # hlavní graf
        plot_frame.grid_rowconfigure(2, weight=1)   # CDF mini-graf

        # Matplotlib dark theme
        plt.style.use("dark_background")

        self._fig = Figure(figsize=(8, 5), dpi=100, facecolor=COLOR_PLOT_BG)
        self._ax = self._fig.add_subplot(111)
        self._configure_axes()

        # Čára pro data
        self._line, = self._ax.plot([], [], color=COLOR_PLOT_LINE,
                                    linewidth=1.5, antialiased=True)
        # Druhá čára pro min/max envelope (volitelná)
        self._line_min, = self._ax.plot([], [], color=COLOR_PLOT_LINE2,
                                        linewidth=0.8, alpha=0.4,
                                        linestyle="--", label="Min")
        self._line_max, = self._ax.plot([], [], color=COLOR_GREEN,
                                        linewidth=0.8, alpha=0.4,
                                        linestyle="--", label="Max")

        # Canvas
        self._canvas = FigureCanvasTkAgg(self._fig, master=plot_frame)
        self._canvas.draw()
        canvas_widget = self._canvas.get_tk_widget()
        canvas_widget.grid(row=0, column=0, sticky="nsew", padx=8, pady=(8, 0))

        # Toolbar
        toolbar_frame = ctk.CTkFrame(plot_frame, fg_color="transparent", height=36)
        toolbar_frame.grid(row=1, column=0, sticky="ew", padx=8, pady=(0, 4))
        self._toolbar = NavigationToolbar2Tk(self._canvas, toolbar_frame)
        self._toolbar.update()

        # -- Live CDF mini-graf --
        self._cdf_fig = Figure(figsize=(8, 2), dpi=100, facecolor=COLOR_PLOT_BG)
        self._cdf_ax = self._cdf_fig.add_subplot(111)
        self._cdf_ax.set_facecolor(COLOR_PLOT_BG)
        self._cdf_ax.text(0.5, 0.5, "Live CDF – čekám na data...",
                          transform=self._cdf_ax.transAxes, ha="center",
                          va="center", fontsize=10, color=COLOR_TEXT_SECONDARY)
        self._cdf_ax.set_xticks([])
        self._cdf_ax.set_yticks([])
        for spine in self._cdf_ax.spines.values():
            spine.set_color(COLOR_PLOT_GRID)
        self._cdf_fig.tight_layout(pad=1.0)

        self._cdf_canvas = FigureCanvasTkAgg(self._cdf_fig, master=plot_frame)
        self._cdf_canvas.draw()
        self._cdf_canvas.get_tk_widget().grid(row=2, column=0, sticky="nsew",
                                              padx=8, pady=(0, 8))

    def _configure_axes(self):
        """Nastaví vzhled os grafu."""
        ax = self._ax
        ax.set_facecolor(COLOR_PLOT_BG)
        ax.set_xlabel("Frekvence [Hz]", color=COLOR_TEXT_PRIMARY,
                       fontsize=11, fontfamily="Segoe UI")
        ax.set_ylabel("Hodnota [dB]", color=COLOR_TEXT_PRIMARY,
                       fontsize=11, fontfamily="Segoe UI")
        ax.set_title("Čekám na data…", color=COLOR_ACCENT_CYAN,
                     fontsize=13, fontweight="bold", fontfamily="Segoe UI",
                     pad=10)
        ax.tick_params(colors=COLOR_TEXT_SECONDARY, labelsize=9)
        ax.grid(True, color=COLOR_PLOT_GRID, alpha=0.5, linewidth=0.5)

        for spine in ax.spines.values():
            spine.set_color(COLOR_PLOT_GRID)

        self._fig.tight_layout(pad=1.5)

    # -- Statusbar -----------------------------------------------------------

    def _build_statusbar(self):
        """Stavový řádek ve spodní části okna."""
        statusbar = ctk.CTkFrame(self, height=30, corner_radius=0,
                                 fg_color=COLOR_ACCENT_BLUE)
        statusbar.grid(row=2, column=0, sticky="ew")
        statusbar.grid_columnconfigure(1, weight=1)

        self._status_label = ctk.CTkLabel(
            statusbar, text="  Připraveno",
            font=ctk.CTkFont(size=11),
            text_color=COLOR_TEXT_PRIMARY,
        )
        self._status_label.grid(row=0, column=0, padx=10, pady=3, sticky="w")

        self._clock_label = ctk.CTkLabel(
            statusbar, text="",
            font=ctk.CTkFont(size=11),
            text_color=COLOR_TEXT_SECONDARY,
        )
        self._clock_label.grid(row=0, column=2, padx=10, pady=3, sticky="e")

        self._update_clock()

    # =====================================================================
    # HELPERS
    # =====================================================================

    def _build_section_label(self, parent, text, row):
        label = ctk.CTkLabel(
            parent, text=text,
            font=ctk.CTkFont(size=14, weight="bold"),
            text_color=COLOR_TEXT_PRIMARY,
        )
        label.grid(row=row, column=0, padx=15, pady=(10, 0), sticky="w")

    def _set_status(self, text: str, color: str = COLOR_TEXT_PRIMARY):
        self._status_label.configure(text=f"  {text}", text_color=color)

    def _update_clock(self):
        now = datetime.now().strftime("%H:%M:%S")
        self._clock_label.configure(text=now)
        self.after(1000, self._update_clock)

    def _get_interval_seconds(self) -> float:
        """Vrátí nastavenou pauzu v sekundách."""
        val = self._interval_var.get()
        if val == "Bez pauzy":
            return 0.0
        return float(val.replace(" s", ""))

    def _get_sweep_limit(self) -> int:
        """Vrátí max. počet sweepů. 0 = bez limitu."""
        if self._unlimited_var.get():
            return 0
        try:
            val = int(self._sweep_limit_entry.get().strip())
            return max(val, 1)
        except (ValueError, AttributeError):
            return 0

    def _toggle_sweep_limit(self):
        """Přepíná aktivaci pole pro max. sweepů."""
        if not self._unlimited_var.get():
            self._sweep_limit_entry.focus()

    # =====================================================================
    # CONNECTION LOGIC
    # =====================================================================

    def _toggle_connection(self):
        """Přepíná připojení / odpojení VNA."""
        if self._driver and self._driver.is_connected:
            self._disconnect()
        else:
            self._do_connect()

    def _do_connect(self):
        """Připojí se k VNA (nebo spustí simulátor)."""
        visa_addr = self._visa_entry.get().strip()
        if not visa_addr:
            visa_addr = DEFAULT_VISA_ADDRESS

        use_sim = self._sim_var.get()

        try:
            if use_sim:
                self._driver = VNASimulator()
            else:
                self._driver = VNADriver()

            idn = self._driver.connect(visa_addr)
            sim_tag = " [SIMULACE]" if use_sim else ""

            self._conn_info.configure(
                text=f"✅ {idn}",
                text_color=COLOR_GREEN,
            )
            self._connect_btn.configure(
                text="Odpojit", fg_color=COLOR_RED, hover_color="#d50000"
            )
            self._start_btn.configure(state="normal")
            self._batch_sparam_btn.configure(state="normal")
            self._set_status(f"Připojeno{sim_tag} k {visa_addr}", COLOR_GREEN)

            # Zablokovat změnu adresy a simulačního režimu
            self._visa_entry.configure(state="disabled")
            self._sim_check.configure(state="disabled")

        except Exception as e:
            self._conn_info.configure(
                text=f"❌ {e}", text_color=COLOR_RED
            )
            self._set_status(f"Chyba připojení", COLOR_RED)
            self._driver = None

    def _disconnect(self):
        """Odpojí VNA."""
        # Nejprve zastavit snímání, pokud běží
        if self._is_recording:
            self._stop_recording()

        if self._driver:
            self._driver.disconnect()
            self._driver = None

        self._conn_info.configure(text="Nepřipojeno",
                                  text_color=COLOR_TEXT_SECONDARY)
        self._connect_btn.configure(
            text="Připojit", fg_color=COLOR_ACCENT_CYAN, hover_color="#00b8d4"
        )
        self._start_btn.configure(state="disabled")
        self._batch_sparam_btn.configure(state="disabled")
        self._visa_entry.configure(state="normal")
        self._sim_check.configure(state="normal")
        self._set_status("Odpojeno", COLOR_TEXT_SECONDARY)

    # =====================================================================
    # RECORDING LOGIC
    # =====================================================================

    def _toggle_recording(self):
        """Přepíná start / stop snímání."""
        if self._is_recording:
            self._stop_recording()
        else:
            self._start_recording()

    def _toggle_batch_recording(self):
        """Přepíná start / stop sekvenčního měření všech S-parametrů."""
        if self._is_recording:
            self._stop_recording()
        else:
            self._start_batch_sparam_recording()

    def _get_selected_formats(self) -> list[str]:
        """Vrátí seznam všech vybraných formátů z checklistu."""
        return [fmt for fmt, var in self._format_vars.items() if var.get()]

    def _start_batch_sparam_recording(self):
        """Spustí sekvenční sběr dat pro všechny S-parametry (S11, S12, S21, S22)."""
        if not self._driver or not self._driver.is_connected:
            self._set_status("VNA není připojeno!", COLOR_RED)
            return

        selected_formats = self._get_selected_formats()
        if not selected_formats:
            self._set_status("Vyberte alespoň jeden formát!", COLOR_RED)
            return

        try:
            f_start_ghz = float(self._vna_start_entry.get().strip())
            f_stop_ghz = float(self._vna_stop_entry.get().strip())
        except ValueError:
            self._set_status("Neplatná frekvence!", COLOR_RED)
            return

        from tkinter import filedialog
        filepath = filedialog.asksaveasfilename(
            defaultextension=".csv",
            filetypes=[("CSV soubory", "*.csv"), ("Všechny soubory", "*.*")],
            initialfile=f"vna_all_sparams_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
            title="Vyberte cílový název pro CSV export (přípona _Sxx.csv bude doplněna automaticky)",
        )
        if not filepath:
            return

        if filepath.lower().endswith(".csv"):
            base_path = filepath[:-4]
        else:
            base_path = filepath

        self._sweep_limit = self._get_sweep_limit()
        self._selected_formats = selected_formats
        self._is_recording = True
        self._is_batch_recording = True
        self._batch_base_path = base_path
        self._stop_event.clear()
        self._sweep_count = 0
        self._history.clear()
        self._data_queue = queue.Queue()

        # UI
        self._start_btn.configure(state="disabled")
        self._batch_sparam_btn.configure(
            text="⏹  ZASTAVIT MĚŘENÍ",
            fg_color=COLOR_RED, hover_color="#d50000",
        )
        self._sparam_menu.configure(state="disabled")
        for cb in self._format_checkboxes.values():
            cb.configure(state="disabled")
        self._interval_menu.configure(state="disabled")
        self._sweep_limit_entry.configure(state="disabled")
        self._unlimited_check.configure(state="disabled")
        self._connect_btn.configure(state="disabled")

        self._sweep_progress.set(0)
        self._set_status("Zahajuji sekvenční měření všech S-parametrů...", COLOR_GREEN)

        self._worker_thread = threading.Thread(
            target=self._worker_batch_loop,
            args=(base_path, selected_formats, f_start_ghz * 1e9, f_stop_ghz * 1e9, self._sweep_limit),
            daemon=True,
        )
        self._worker_thread.start()

    def _worker_batch_loop(self, base_path: str, selected_formats: list[str],
                          f_start_hz: float, f_stop_hz: float, sweep_limit_per_param: int):
        """Worker smyčka pro sekvenční měření všech S-parametrů."""
        sparams = ["S11", "S12", "S21", "S22"]
        interval = self._get_interval_seconds()
        target_sweeps = sweep_limit_per_param if sweep_limit_per_param > 0 else 1
        total_steps = len(sparams) * target_sweeps
        current_step = 0

        for sp_idx, sp in enumerate(sparams):
            if self._stop_event.is_set():
                break

            csv_filename = f"{base_path}_{sp}.csv"

            try:
                self._driver.configure_measurement(sp, selected_formats)
                self._driver.set_frequency_range(f_start_hz, f_stop_hz)
                freq_axis = self._driver.get_frequency_axis()

                with open(csv_filename, "w", newline="", encoding="utf-8") as csv_file:
                    csv_writer = csv.writer(csv_file)
                    freq_headers = [f"{f:.0f}" for f in freq_axis]
                    csv_writer.writerow(["Timestamp", "Sweep_Nr", "Format"] + freq_headers)

                    for sw in range(1, target_sweeps + 1):
                        if self._stop_event.is_set():
                            break

                        data_dict = self._driver.single_sweep(selected_formats)
                        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]

                        for fmt in selected_formats:
                            if fmt in data_dict:
                                row = [timestamp, sw, fmt] + [f"{v:.6f}" for v in data_dict[fmt]]
                                csv_writer.writerow(row)
                        csv_file.flush()

                        current_step += 1

                        self._data_queue.put((
                            "BATCH_DATA",
                            {
                                "sparam": sp,
                                "sp_idx": sp_idx + 1,
                                "total_sp": len(sparams),
                                "sweep_nr": sw,
                                "target_sweeps": target_sweeps,
                                "timestamp": timestamp,
                                "data_dict": data_dict,
                                "freq_axis": freq_axis,
                                "csv_filename": csv_filename,
                                "progress": current_step / total_steps,
                            }
                        ))

                        if interval > 0 and not self._stop_event.is_set() and sw < target_sweeps:
                            self._stop_event.wait(timeout=interval)

            except Exception as e:
                self._data_queue.put(("ERROR", str(e), None))
                return

        if not self._stop_event.is_set():
            self._data_queue.put(("BATCH_COMPLETE", base_path, None))

    def _start_recording(self):
        """Spustí kontinuální sběr dat."""
        if not self._driver or not self._driver.is_connected:
            self._set_status("VNA není připojeno!", COLOR_RED)
            return

        s_param = self._sparam_var.get()
        selected_formats = self._get_selected_formats()
        if not selected_formats:
            self._set_status("Vyberte alespoň jeden formát!", COLOR_RED)
            return

        self._selected_formats = selected_formats
        self._is_batch_recording = False
        primary_fmt = selected_formats[0]
        unit = TRACE_FORMAT_UNITS.get(primary_fmt, "")
        
        try:
            f_start_ghz = float(self._vna_start_entry.get().strip())
            f_stop_ghz = float(self._vna_stop_entry.get().strip())
        except ValueError:
            self._set_status("Neplatná frekvence!", COLOR_RED)
            return

        # Načtení limitu sweepů
        self._sweep_limit = self._get_sweep_limit()

        try:
            # Konfigurace měření
            self._driver.configure_measurement(s_param, selected_formats)
            self._driver.set_frequency_range(f_start_ghz * 1e9, f_stop_ghz * 1e9)

            # Vyčtení frekvenční osy
            self._freq_axis = self._driver.get_frequency_axis()

            # Reset
            self._sweep_count = 0
            self._history.clear()
            self._data_queue = queue.Queue()
            self._stop_event.clear()

            # Aktualizace grafu – osy
            self._ax.set_xlim(self._freq_axis[0], self._freq_axis[-1])
            ylabel = f"{s_param} ({primary_fmt}) [{unit}]" if unit else f"{s_param} ({primary_fmt})"
            self._ax.set_ylabel(ylabel, color=COLOR_TEXT_PRIMARY,
                                fontsize=11, fontfamily="Segoe UI")

            # Otevření CSV souboru
            self._csv_filename = f"vna_data_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
            self._csv_file = open(self._csv_filename, "w", newline="",
                                  encoding="utf-8")
            self._csv_writer = csv.writer(self._csv_file)

            # Hlavička CSV
            freq_headers = [f"{f:.0f}" for f in self._freq_axis]
            self._csv_writer.writerow(["Timestamp", "Sweep_Nr", "Format"] + freq_headers)

            # UI
            self._is_recording = True
            self._start_btn.configure(
                text="⏹  ZASTAVIT SNÍMÁNÍ",
                fg_color=COLOR_RED, hover_color="#d50000",
            )
            self._batch_sparam_btn.configure(state="disabled")
            self._sparam_menu.configure(state="disabled")
            for cb in self._format_checkboxes.values():
                cb.configure(state="disabled")
            self._interval_menu.configure(state="disabled")
            self._sweep_limit_entry.configure(state="disabled")
            self._unlimited_check.configure(state="disabled")
            self._connect_btn.configure(state="disabled")

            # Status s info o limitu
            fmt_str = ", ".join(selected_formats)
            limit_info = f" (limit: {self._sweep_limit})" if self._sweep_limit > 0 else " (bez limitu)"
            self._set_status(
                f"Snímání {s_param} [{fmt_str}]{limit_info} – {self._csv_filename}",
                COLOR_GREEN,
            )

            # Reset progress baru
            self._sweep_progress.set(0)

            # Spuštění worker vlákna
            self._worker_thread = threading.Thread(
                target=self._worker_loop, daemon=True
            )
            self._worker_thread.start()

        except Exception as e:
            self._set_status(f"Chyba při startu: {e}", COLOR_RED)

    def _play_completion_beeps(self):
        """Přehrá sérii hlasitých pípnutí pro upozornění na dokončení měření."""
        def _beep_routine():
            try:
                import winsound
                # 3 nápadná a hlasitá pípnutí s rostoucí frekvencí
                for freq, duration in [(1800, 250), (2400, 250), (3000, 450)]:
                    winsound.Beep(freq, duration)
                    time.sleep(0.06)
            except Exception:
                pass

        threading.Thread(target=_beep_routine, daemon=True).start()

    def _stop_recording(self, auto_stopped: bool = False, is_error: bool = False):
        """Zastaví sběr dat."""
        self._stop_event.set()
        is_batch = getattr(self, '_is_batch_recording', False)
        base_p = getattr(self, '_batch_base_path', 'vna')
        self._is_recording = False
        self._is_batch_recording = False

        # Počkáme na dokončení worker vlákna (max 5s)
        if self._worker_thread and self._worker_thread.is_alive():
            self._worker_thread.join(timeout=5.0)

        # Zavření CSV
        if self._csv_file:
            self._csv_file.close()
            self._csv_file = None
            self._csv_writer = None

        # UI reset
        is_conn = bool(self._driver and self._driver.is_connected)
        self._start_btn.configure(
            text="▶  SPUSTIT SNÍMÁNÍ",
            fg_color=COLOR_GREEN, hover_color="#00c853",
            state="normal" if is_conn else "disabled",
        )
        self._batch_sparam_btn.configure(
            text="⚡  MĚŘIT VŠECHNY S-PARAMETRY",
            fg_color=COLOR_ACCENT_BLUE, hover_color="#1a4a8a",
            state="normal" if is_conn else "disabled",
        )
        self._sparam_menu.configure(state="normal")
        for cb in self._format_checkboxes.values():
            cb.configure(state="normal")
        self._interval_menu.configure(state="normal")
        self._connect_btn.configure(state="normal")
        self._sweep_limit_entry.configure(state="normal")
        self._unlimited_check.configure(state="normal")

        if self._sweep_count > 0:
            self._export_btn.configure(state="normal")

        if is_error:
            pass # Chybu už vypsalo hlavní vlákno
        elif is_batch and auto_stopped:
            self._set_status(
                f"✅ Dokončeno měření všech S-parametrů (S11, S12, S21, S22)! Uloženo: {base_p}_Sxx.csv",
                COLOR_GREEN,
            )
            if getattr(self, '_beep_var', None) and self._beep_var.get():
                self._play_completion_beeps()
        elif auto_stopped:
            self._set_status(
                f"✅ Dokončeno! {self._sweep_count}/{self._sweep_limit} sweepů. "
                f"Data: {self._csv_filename}",
                COLOR_GREEN,
            )
            if getattr(self, '_beep_var', None) and self._beep_var.get():
                self._play_completion_beeps()
        else:
            self._set_status(
                f"Měření zastaveno.",
                COLOR_ORANGE,
            )

    # =====================================================================
    # WORKER THREAD (měřicí smyčka)
    # =====================================================================

    def _worker_loop(self):
        """Běží v samostatném vlákně – provádí sweepy a posílá data do GUI."""
        interval = self._get_interval_seconds()
        sweep_limit = self._sweep_limit  # 0 = bez limitu

        while not self._stop_event.is_set():
            try:
                # Měření pro všechny vybrané formáty
                data_dict = self._driver.single_sweep(self._selected_formats)
                self._sweep_count += 1
                timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]

                # Zápis do CSV
                if self._csv_writer:
                    for fmt in self._selected_formats:
                        if fmt in data_dict:
                            row = [timestamp, self._sweep_count, fmt] + [f"{v:.6f}" for v in data_dict[fmt]]
                            self._csv_writer.writerow(row)
                    if self._csv_file:
                        self._csv_file.flush()

                # Odeslání dat do GUI
                self._data_queue.put((self._sweep_count, timestamp, data_dict))

                # Kontrola limitu sweepů
                if sweep_limit > 0 and self._sweep_count >= sweep_limit:
                    self._data_queue.put(("AUTO_STOP", None, None))
                    break

                # Pauza
                if interval > 0 and not self._stop_event.is_set():
                    self._stop_event.wait(timeout=interval)

            except Exception as e:
                self._data_queue.put(("ERROR", str(e), None))
                break

    # =====================================================================
    # PLOT UPDATE (hlavní vlákno)
    # =====================================================================

    def _schedule_plot_update(self):
        """Periodicky kontroluje frontu a aktualizuje graf."""
        updated = False

        # Zpracujeme všechna data ve frontě
        auto_stop = False
        while not self._data_queue.empty():
            try:
                item = self._data_queue.get_nowait()
                msg_type = item[0]

                if msg_type == "ERROR":
                    self._set_status(f"Chyba měření: {item[1]}", COLOR_RED)
                    self._stop_recording(is_error=True)
                    break

                if msg_type in ("AUTO_STOP", "BATCH_COMPLETE"):
                    auto_stop = True
                    continue

                if msg_type == "BATCH_DATA":
                    info = item[1]
                    sp = info["sparam"]
                    self._sparam_var.set(sp)
                    self._freq_axis = info["freq_axis"]
                    data_dict = info["data_dict"]

                    if not hasattr(self, '_current_batch_sparam') or self._current_batch_sparam != sp:
                        self._current_batch_sparam = sp
                        self._history.clear()

                    self._history.append({"sweep_nr": info["sweep_nr"], "timestamp": info["timestamp"], "data": data_dict})
                    self._sweep_count = info["sweep_nr"]
                    updated = True

                    # Ax limits & ylabel
                    self._ax.set_xlim(self._freq_axis[0], self._freq_axis[-1])
                    primary_fmt = self._selected_formats[0]
                    unit = TRACE_FORMAT_UNITS.get(primary_fmt, "")
                    ylabel = f"{sp} ({primary_fmt}) [{unit}]" if unit else f"{sp} ({primary_fmt})"
                    self._ax.set_ylabel(ylabel, color=COLOR_TEXT_PRIMARY, fontsize=11, fontfamily="Segoe UI")

                    # Labels & Progress
                    self._sweep_label.configure(
                        text=f"Měření: {sp} ({info['sp_idx']}/{info['total_sp']}) – Sweep #{info['sweep_nr']}/{info['target_sweeps']}"
                    )
                    self._sweep_progress.set(info["progress"])
                    self._set_status(
                        f"Snímání {sp} ({info['sp_idx']}/4) – Ukládám do: {info['csv_filename']}",
                        COLOR_GREEN
                    )

                else:
                    # Standard single measurement sweep
                    sweep_nr, timestamp, data_dict = item
                    self._history.append({"sweep_nr": sweep_nr, "timestamp": timestamp, "data": data_dict})
                    updated = True

            except queue.Empty:
                break

        if updated and self._freq_axis is not None and len(self._history) > 0:
            primary_fmt = getattr(self, '_selected_formats', ['dB Mag'])[0]
            latest = self._history[-1]["data"][primary_fmt]
            freqs = self._freq_axis

            # Aktualizace hlavní čáry
            self._line.set_data(freqs, latest)

            # Min/Max envelope (pokud máme více sweepů)
            if len(self._history) > 1:
                all_data = np.array([h["data"][primary_fmt] for h in self._history])
                mins = np.min(all_data, axis=0)
                maxs = np.max(all_data, axis=0)
                self._line_min.set_data(freqs, mins)
                self._line_max.set_data(freqs, maxs)

            # Autoscale Y
            all_vals = latest
            margin = max(abs(np.ptp(all_vals)) * 0.1, 1.0)
            self._ax.set_ylim(np.min(all_vals) - margin,
                              np.max(all_vals) + margin)

            # Titulek
            s_param = self._sparam_var.get()
            self._ax.set_title(
                f"{s_param} ({primary_fmt})  –  Sweep #{self._sweep_count}",
                color=COLOR_ACCENT_CYAN, fontsize=13,
                fontweight="bold", fontfamily="Segoe UI", pad=10,
            )

            self._canvas.draw_idle()

            if not getattr(self, '_is_batch_recording', False):
                sweep_limit = getattr(self, '_sweep_limit', 0)
                if sweep_limit > 0:
                    self._sweep_label.configure(
                        text=f"Sweepů: {self._sweep_count} / {sweep_limit}"
                    )
                    progress = min(self._sweep_count / sweep_limit, 1.0)
                    self._sweep_progress.set(progress)
                else:
                    self._sweep_label.configure(
                        text=f"Sweepů: {self._sweep_count}"
                    )
                    self._sweep_progress.set(0)

            # Live CDF aktualizace (neblokující)
            self._update_live_cdf()

        # Auto-stop po dosažení limitu
        if auto_stop and self._is_recording:
            self._stop_recording(auto_stopped=True)

        # Znovu naplánovat (100ms interval)
        self.after(100, self._schedule_plot_update)

    # =====================================================================
    # LIVE CDF MINI-PANEL
    # =====================================================================

    def _update_live_cdf(self):
        """Aktualizuje live CDF mini-graf. Volá se z hlavního vlákna."""
        if self._freq_axis is None or len(self._history) < 3:
            return

        try:
            # Minimální počet sweepů
            try:
                min_sw = int(self._live_cdf_min_sweeps_entry.get().strip())
            except (ValueError, AttributeError):
                min_sw = 20

            # Získání režimu a parametrů
            mode_label = self._live_cdf_mode_var.get()
            mode_key = ANALYSIS_MODES.get(mode_label, "band_max")

            # Parametry frekvence/pásma
            try:
                freq_ghz = float(self._live_cdf_freq_entry.get().strip())
            except (ValueError, AttributeError):
                freq_ghz = 2.45

            try:
                freq_end_ghz = float(self._live_cdf_freq_end_entry.get().strip())
            except (ValueError, AttributeError):
                freq_end_ghz = 4.12

            # Sestavení matice dat z historie pro primární formát
            primary_fmt = getattr(self, '_selected_formats', ['dB Mag'])[0]
            data_matrix = np.array([h["data"][primary_fmt] for h in self._history])

            # Extrakce řady
            if mode_key == "single_freq":
                series = extract_series_for_mode(
                    data_matrix, self._freq_axis, mode_key,
                    freq_value_hz=freq_ghz * 1e9)
            else:
                series = extract_series_for_mode(
                    data_matrix, self._freq_axis, mode_key,
                    band_start_hz=freq_ghz * 1e9,
                    band_stop_hz=freq_end_ghz * 1e9)

            # Vykreslení mini CDF
            plot_cdf_mini(self._cdf_ax, series, mode=mode_key,
                          min_sweeps=min_sw)
            self._cdf_canvas.draw_idle()

        except Exception:
            # Při chybě tiše ignorujeme – nesmí zamrznout GUI
            pass

    # =====================================================================
    # CSV EXPORT
    # =====================================================================

    def _export_csv(self):
        """Otevře dialog pro uložení CSV kopie (pokud chce uživatel jiný soubor)."""
        if not self._history or self._freq_axis is None:
            self._set_status("Žádná data k exportu.", COLOR_ORANGE)
            return

        try:
            from tkinter import filedialog
            filepath = filedialog.asksaveasfilename(
                defaultextension=".csv",
                filetypes=[("CSV soubory", "*.csv"), ("Všechny soubory", "*.*")],
                initialfile=f"vna_export_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
            )
            if not filepath:
                return

            with open(filepath, "w", newline="", encoding="utf-8") as f:
                writer = csv.writer(f)
                freq_headers = [f"{freq:.0f}" for freq in self._freq_axis]
                writer.writerow(["Timestamp", "Sweep_Nr", "Format"] + freq_headers)

                selected_fmts = getattr(self, '_selected_formats', list(TRACE_FORMATS.keys()))
                for h in self._history:
                    for fmt in selected_fmts:
                        if fmt in h["data"]:
                            writer.writerow([h["timestamp"], h["sweep_nr"], fmt] + [f"{v:.6f}" for v in h["data"][fmt]])

            self._set_status(f"Export uložen: {filepath}", COLOR_GREEN)

        except Exception as e:
            self._set_status(f"Chyba exportu: {e}", COLOR_RED)

    # =====================================================================
    # CLEANUP
    # =====================================================================

    def _on_close(self):
        """Korektní ukončení aplikace."""
        if self._is_recording:
            self._stop_recording()

        if self._driver and self._driver.is_connected:
            self._driver.disconnect()

        self.quit()
        self.destroy()


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------
def main():
    app = VNAApp()
    app.mainloop()


if __name__ == "__main__":
    main()
