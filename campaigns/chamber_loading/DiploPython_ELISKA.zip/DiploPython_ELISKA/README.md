# VNA Data Recorder

Python GUI aplikace pro kontinuální sběr a vizualizaci dat z **Rohde & Schwarz ZND-2Port** VNA.

## Instalace

```bash
# Nainstaluj závislosti
pip install -r requirements.txt
```

### Požadavky
- Python 3.9+
- Síťové připojení k VNA (pro reálné měření)
- Žádný reálný VNA není potřeba pro testování – aplikace obsahuje simulační mód

## Spuštění

```bash
python vna_app.py
```

## Ovládání

1. **Připojení**: Zadejte VISA adresu VNA a klikněte na "Připojit"
   - Výchozí adresa: `TCPIP0::10.56.11.11::inst0::INSTR`
   - Pro testování bez VNA zaškrtněte "Simulační mód"

2. **Nastavení měření**:
   - Vyberte S-parametr (S11, S12, S21, S22)
   - Vyberte formát zobrazení (dB Mag, Phase, Lin Mag, ...)
   - Nastavte interval mezi sweepy

3. **Snímání**:
   - Klikněte "SPUSTIT SNÍMÁNÍ" – data se začnou zaznamenávat do CSV
   - Klikněte "ZASTAVIT SNÍMÁNÍ" pro ukončení
   - Data se automaticky ukládají do souboru `vna_data_YYYYMMDD_HHMMSS.csv`

4. **Export**: Tlačítko "Exportovat CSV" umožní uložit kopii dat na jiné místo

## Struktura projektu

| Soubor | Popis |
|---|---|
| `vna_app.py` | Hlavní GUI aplikace |
| `vna_driver.py` | Komunikace s VNA (SCPI příkazy) + simulátor |
| `requirements.txt` | Python závislosti |

## Výstupní CSV formát

```csv
Timestamp,Sweep_Nr,100000,22500000,...,4500000000
2026-04-09 12:00:01.123,1,-5.200000,-8.100000,...,-12.300000
2026-04-09 12:00:02.456,2,-5.100000,-8.000000,...,-12.400000
```

- Sloupce odpovídají frekvencím v Hz (z nastavení VNA)
- Každý řádek je jedno kompletní měření (sweep)
